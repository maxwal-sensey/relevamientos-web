/**
 * @file apiClient.ts
 * @description Cliente API ligero que decide entre uso de mocks (mockApi) o llamadas HTTP reales.
 *
 * - Evita duplicar llamadas en el frontend y permite cambiar fácilmente al backend real
 *   mediante la variable VITE_USE_MOCKS o estableciendo VITE_API_BASE.
 */

import { API_BASE, USE_MOCKS } from '@/config/serverConfig'
import * as mockApi from './mockApi'

/**
 * @description Tiempo por defecto para health-check (ms).
 */
const HEALTH_TIMEOUT = 3000

/**
 * @function healthCheck
 * @description Consulta el endpoint /health del backend (si no hay backend, rechaza).
 *              Usa timeout corto para detectar rápidamente estado en una Pi.
 * @returns Promise<boolean> true si backend responde 200 en tiempo.
 */
export async function healthCheck(): Promise<boolean> {
  if (USE_MOCKS) return Promise.resolve(true)
  try {
    const controller = new AbortController()
    const id = setTimeout(() => controller.abort(), HEALTH_TIMEOUT)
    const res = await fetch(`${API_BASE.replace(/\/$/, '')}/health`, { method: 'GET', signal: controller.signal })
    clearTimeout(id)
    return res.ok
  } catch (err) {
    return false
  }
}

/**
 * @function listMessages
 * @description Lista mensajes, delega al mock o al endpoint real.
 */
export async function listMessages() {
  if (USE_MOCKS) {
    // mockApi.listMessages devuelve Promise<MockMessage[]>
    return mockApi.listMessages()
  }
  const res = await fetch(`${API_BASE.replace(/\/$/, '')}/messages`)
  if (!res.ok) throw new Error('Error listando mensajes')
  return res.json()
}

/**
 * @function sendMessage
 * @description Envía un mensaje. Si se usa backend real, espera JSON; con mock usa mockApi.sendMessage.
 * @param payload FormData o datos objeto (cuando USE_MOCKS true usa objeto compatible con mockApi.SendMessageInput).
 */
export async function sendMessage(payload: FormData | any) {
  if (USE_MOCKS) {
    const input = {
      from: payload.get ? String(payload.get('from') ?? '') : payload.from,
      to: payload.get ? String(payload.get('to') ?? '') : payload.to,
      subject: payload.get ? String(payload.get('subject') ?? '') : payload.subject,
      body: payload.get ? String(payload.get('body') ?? '') : payload.body,
      attachments: [], // mockApi expects metadata; real uploads not simulated here
      solicitudId: payload.get ? String(payload.get('solicitudId') ?? '') : payload.solicitudId,
    }
    return mockApi.sendMessage(input)
  }

  // Backend real: enviar multipart/form-data
  const res = await fetch(`${API_BASE.replace(/\/$/, '')}/messages`, {
    method: 'POST',
    body: payload,
  })
  if (!res.ok) {
    const text = await res.text().catch(() => '')
    throw new Error(`Error enviando mensaje: ${res.status} ${text}`)
  }
  return res.json()
}

/**
 * @function getAttachmentsForSolicitud
 * @description Obtiene attachments para una solicitud (delegado).
 * @param solicitudId string|number
 */
export async function getAttachmentsForSolicitud(solicitudId: string | number) {
  if (USE_MOCKS) {
    return mockApi.getAttachmentsForSolicitud(solicitudId)
  }
  const res = await fetch(`${API_BASE.replace(/\/$/, '')}/attachments/solicitud/${encodeURIComponent(String(solicitudId))}`)
  if (!res.ok) throw new Error('Error al obtener attachments')
  return res.json()
}

/**
 * @function getAttachmentBlob
 * @description Descarga un attachment (delegado a mock o endpoint real).
 * @param messageId number
 * @param attachmentIndex number
 * @returns Promise<Blob>
 */
export async function getAttachmentBlob(messageId: number, attachmentIndex: number): Promise<Blob> {
  if (USE_MOCKS) {
    return mockApi.getAttachmentBlob(messageId, attachmentIndex)
  }
  const res = await fetch(`${API_BASE.replace(/\/$/, '')}/attachments/${messageId}/${attachmentIndex}`)
  if (!res.ok) throw new Error('No se pudo descargar adjunto')
  return res.blob()
}