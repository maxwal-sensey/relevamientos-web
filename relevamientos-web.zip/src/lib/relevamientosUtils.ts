/**
 * @file relevamientosUtils.ts
 * @description Utilidades y helpers para el formulario de relevamientos.
 */

/**
 * @function generateRelevamientoNumber
 * @description Genera un identificador simulado para el relevamiento.
 */
export function generateRelevamientoNumber(date: Date): string {
  const year = date.getFullYear()
  const month = `${date.getMonth() + 1}`.padStart(2, '0')
  const day = `${date.getDate()}`.padStart(2, '0')
  const sequential = '0001'
  return `REL-${year}${month}${day}-${sequential}`
}

/**
 * @function buildObservacionesVecino
 * @description Genera texto automático de observaciones según flags del vecino.
 */
export function buildObservacionesVecino(entry: {
  presencio: boolean
  conocimiento: boolean
  observaciones: string
}): string {
  // Si ya hay observaciones manuales, se respetan.
  if (entry.observaciones.trim().length > 0) {
    return entry.observaciones
  }

  if (!entry.presencio && !entry.conocimiento) {
    return 'No presenció ni tiene conocimiento del hecho.'
  }

  if (!entry.presencio && entry.conocimiento) {
    return 'No presenció el hecho, pero tiene conocimiento del mismo.'
  }

  if (entry.presencio && !entry.conocimiento) {
    return 'Presenció el hecho, pero no posee mayor conocimiento adicional.'
  }

  // Caso en el que presenció y tiene conocimiento.
  return 'Presenció el hecho y tiene conocimiento directo sobre el mismo.'
}

/**
 * @function mapAccionCamaraToTexto
 * @description Mapea el código de acción de cámara a un texto legible para el informe.
 */
export function mapAccionCamaraToTexto(accion: string): string {
  switch (accion) {
    case 'solicito_grabacion':
      return 'Se solicitó grabación.'
    case 'no_graba':
      return 'No graba / sin registros disponibles.'
    case 'no_apunta':
      return 'La cámara no apunta al lugar del hecho.'
    case 'negativa':
      return 'Negativa a entregar grabaciones.'
    case 'entrega_material':
      return 'Entrega material fílmico en el lugar.'
    case 'otro':
    default:
      return 'Otra situación relevada con la cámara.'
  }
}

/**
 * @function buildInfoCamarasVecino
 * @description Construye texto sobre el estado de cámaras del vecino en base a los flags.
 */
export function buildInfoCamarasVecino(entry: {
  sinCamaras: boolean
  camarasNoGraban: boolean
  camarasNoDanLugar: boolean
}): string | undefined {
  const partes: string[] = []

  if (entry.sinCamaras) {
    partes.push('No posee cámaras de seguridad.')
  }
  if (entry.camarasNoGraban) {
    partes.push('Las cámaras no graban o no conservan registros útiles.')
  }
  if (entry.camarasNoDanLugar) {
    partes.push('Las cámaras no dan al lugar específico del hecho.')
  }

  if (partes.length === 0) {
    return undefined
  }

  return partes.join(' ')
}