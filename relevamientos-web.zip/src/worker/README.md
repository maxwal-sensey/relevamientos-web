# Worker README

Este directorio contiene un Cloudflare Worker (Hono) con endpoints mínimos para recibir mensajes con adjuntos, subir a R2 y persistir metadatos en D1.

Bindings esperados (wrangler.toml):
- R2_BUCKET: binding hacia tu bucket R2
- SGR_DB: binding hacia tu base D1

Ejemplo wrangler.toml (fragmento):
```
name = "sgr-worker"
compatibility_date = "2026-01-01"

[[r2_buckets]]
binding = "R2_BUCKET"
bucket_name = "your-r2-bucket-name"

[env.production]
d1_databases = [{ binding = "SGR_DB", database_name = "sgr_db" }]
```

Pasos recomendados:
1. Crear las tablas `messages` y `attachments` en D1 con el esquema del encabezado de src/worker/index.ts.
2. Desplegar el Worker con `wrangler deploy` (ajustar configuración de wrangler).
3. Probar POST /api/messages enviando multipart/form-data:
   - campos: from, to, subject, body, solicitudId (opcional)
   - files: incluir uno o más ficheros con name="files" (o cualquier name; el worker detecta File entries)
4. Consultar GET /api/messages para ver los registros y metadatos almacenados.

Limitaciones y seguridad:
- Este ejemplo no implementa autenticación; en producción debes validar token/session y comprobar permisos (por ejemplo: que el usuario pueda relacionar mensajes con una solicitud de su dependencia).
- Se usan nombres de archivo "safes" reemplazando caracteres; ajustar política de nombres según conveniencia.
- Implementar límites adicionales (tamaño total, tipo de mime, escaneo antivirus) antes de usar en producción.
