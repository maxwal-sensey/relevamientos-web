/**
 * @file src/worker/index.ts
 * @description Cloudflare Worker (Hono) que expone API para persistir mensajes con adjuntos.
 *              - Recibe multipart/form-data en POST /api/messages
 *              - Sube archivos a R2 (binding: R2_BUCKET)
 *              - Persiste metadatos en D1 (binding: SGR_DB)
 *
 * Bindings esperados en wrangler.toml:
 *   - binding R2_BUCKET -> tu bucket R2
 *   - binding SGR_DB -> tu base D1
 *
 * Esquema SQL de ejemplo (ejecutar en D1 antes de usar):
 *
 * CREATE TABLE IF NOT EXISTS messages (
 *   id INTEGER PRIMARY KEY AUTOINCREMENT,
 *   "from" TEXT NOT NULL,
 *   "to" TEXT NOT NULL,
 *   subject TEXT,
 *   body TEXT,
 *   solicitud_id TEXT,
 *   created_at TEXT DEFAULT (datetime('now'))
 * );
 *
 * CREATE TABLE IF NOT EXISTS attachments (
 *   id INTEGER PRIMARY KEY AUTOINCREMENT,
 *   message_id INTEGER NOT NULL,
 *   r2_key TEXT NOT NULL,
 *   filename TEXT NOT NULL,
 *   content_type TEXT,
 *   size INTEGER,
 *   created_at TEXT DEFAULT (datetime('now')),
 *   FOREIGN KEY (message_id) REFERENCES messages(id) ON DELETE CASCADE
 * );
 *
 * Nota: adaptar nombres de bindings y políticas CORS según tu entorno.
 */

import { Hono } from 'hono'
import { type Context } from 'hono'
import { z } from 'zod'

/**
 * @file src/worker/index.ts
 * @description Cloudflare Worker (Hono) que expone API para persistir mensajes con adjuntos.
 *              Incluye un adaptador de DB para desarrollo local usando un archivo SQLite
 *              (./data/sgr.sqlite) vía sqlite3 CLI cuando no exista la binding D1.
 *
 * Notas de funcionamiento:
 * - En Cloudflare (bindings presentes) usa c.env.SGR_DB (D1) y c.env.R2_BUCKET (R2).
 * - En desarrollo local (sin bindings) intenta usar SQLITE_PATH (env) o ./data/sgr.sqlite
 *   ejecutando la cli `sqlite3 -json` para ejecutar queries. Esto evita añadir paquetes.
 */

/**
 * Env
 * @description Typings de bindings que el Worker espera recibir.
 */
interface Env {
  R2_BUCKET: R2Bucket
  SGR_DB: D1Database
}

/**
 * @description Crea un cliente DB compatible con las llamadas que usa el Worker.
 *              Si el binding D1 (c.env.SGR_DB) existe, se retorna directamente.
 *              En otro caso se crea un adaptador que ejecuta sqlite3 CLI contra un archivo local.
 *
 * @param c Context del handler
 * @returns objeto con método prepare(sql) -> { bind(...params).all() | run() }
 */
function getDb(c: Context<{ Bindings: Env }>) {
  // Si existe binding D1 -> usarlo (Cloudflare)
  try {
    const maybe = (c.env as any)?.SGR_DB
    if (maybe && typeof maybe.prepare === 'function') {
      return maybe
    }
  } catch {
    // continuar a adapter local
  }

  // Local adapter usando sqlite3 CLI
  const path = (process && (process.env.SGR_SQLITE_PATH as string)) || 'data/sgr.sqlite'

  /**
   * @description Escapa y formatea un parámetro para inyectarlo de forma simple en SQL.
   *              NOTA: solo para desarrollo local. En producción usa binding D1.
   */
  function quoteParam(p: any): string {
    if (p === null || typeof p === 'undefined') return 'NULL'
    if (typeof p === 'number' || (typeof p === 'string' && /^\d+(\.\d+)?$/.test(p))) return String(p)
    const s = String(p).replace(/'/g, "''")
    return `'${s}'`
  }

  /**
   * @description Reemplaza de forma secuencial cada ? por el parámetro correspondiente.
   */
  function sqlWithParams(sql: string, params: any[] = []) {
    let i = 0
    return sql.replace(/\?/g, () => {
      const p = params[i++]
      return quoteParam(p)
    })
  }

  /**
   * @description Ejecuta SQL usando sqlite3 CLI y retorna el stdout.
   */
  function execSqlRaw(finalSql: string) {
    try {
      // require dinámico para evitar errores en entorno Worker
      // eslint-disable-next-line @typescript-eslint/no-var-requires
      const child = require('child_process')
      // Usar opción -json si está disponible (sqlite3 >= 3.38). Si no, intentar ejecutar igualmente.
      const args = [path, '-json', finalSql]
      const proc = child.spawnSync('sqlite3', args, { encoding: 'utf8' })
      if (proc.error) {
        throw proc.error
      }
      // stdout puede venir vacío
      return proc.stdout || ''
    } catch (err) {
      // Lanzar para que el handler lo capture y muestre
      throw err
    }
  }

  return {
    /**
     * @description Prepara una sentencia SQL.
     * @param sql string
     */
    prepare(sql: string) {
      return {
        /**
         * @description Bind de parámetros. Devuelve objeto con all() y run().
         */
        bind(...params: any[]) {
          return {
            /**
             * @description Ejecuta query y retorna { results: [...] } para compatibilidad.
             */
            async all() {
              const q = sqlWithParams(sql, params)
              const out = execSqlRaw(q)
              try {
                const parsed = out ? JSON.parse(out) : []
                return { results: parsed }
              } catch (e) {
                // Si no viene JSON, intentar envolver en array vacío
                return { results: [] }
              }
            },
            /**
             * @description Ejecuta statement tipo INSERT/UPDATE/DELETE.
             */
            async run() {
              const q = sqlWithParams(sql, params)
              const out = execSqlRaw(q)
              try {
                const parsed = out ? JSON.parse(out) : []
                // Simular API D1: devolver { results: parsed }
                return { results: parsed }
              } catch {
                return { results: [] }
              }
            },
          }
        },
      }
    },
  }
}

/**
 * app
 * @description Instancia Hono con las rutas de la API.
 */
const app = new Hono<{ Bindings: Env }>()

/**
 * jsonResponse
 * @description Helper para respuestas JSON con CORS básico.
 */
function jsonResponse(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: {
      'content-type': 'application/json;charset=utf-8',
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET,POST,OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type',
    },
  })
}

/**
 * POST /api/messages
 * @description Recibe multipart/form-data:
 *              - from (string) required
 *              - to (string) required
 *              - subject (string) optional
 *              - body (string) optional
 *              - solicitudId (string) optional
 *              - files[] (file) optional (multiples)
 *
 * Proceso:
 * 1) Valida campos
 * 2) Inserta registro en D1 (messages) con RETURNING id
 * 3) Sube cada file a R2 y guarda metadatos en attachments
 */
app.post('/api/messages', async (c: Context<{ Bindings: Env }>) => {
  try {
    const req = c.req
    const contentType = req.headers.get('content-type') || ''
    if (!contentType.includes('multipart/form-data')) {
      return jsonResponse({ error: 'Content-Type debe ser multipart/form-data' }, 400)
    }

    const form = await req.formData()

    const from = (form.get('from') as string) || ''
    const to = (form.get('to') as string) || ''
    const subject = (form.get('subject') as string) || ''
    const body = (form.get('body') as string) || ''
    const solicitudIdRaw = form.get('solicitudId')
    const solicitudId = typeof solicitudIdRaw === 'string' ? solicitudIdRaw : null

    // Validación mínima
    if (!from.trim() || !to.trim()) {
      return jsonResponse({ error: 'Los campos "from" y "to" son obligatorios.' }, 400)
    }

    // Persistir mensaje en D1 y obtener id (usando RETURNING)
    const insertSql = `
      INSERT INTO messages ("from","to",subject,body,solicitud_id)
      VALUES (?, ?, ?, ?, ?)
      RETURNING id, created_at
    `
    const db = getDb(c)
    const insertStmt = db.prepare(insertSql)
    const insertResult = await insertStmt.bind(from, to, subject, body, solicitudId).all()

    // insertResult.results es un arreglo con fila retornada (según API de D1)
    const insertedRow = (insertResult.results && insertResult.results[0]) || null
    const messageId = insertedRow?.id ?? null
    const createdAt = insertedRow?.created_at ?? new Date().toISOString()

    if (!messageId) {
      return jsonResponse({ error: 'No se pudo crear el mensaje en la DB.' }, 500)
    }

    // Procesar archivos (si hay)
    const attachmentsMeta: Array<{
      filename: string
      r2Key: string
      contentType?: string | null
      size?: number | null
    }> = []

    // Iterar sobre formData entries y procesar campos tipo File
    for (const pair of form.entries()) {
      const [key, value] = pair
      // Aceptamos input name "files" o "attachments" o cualquier File entries
      if (value instanceof File) {
        const file = value as File
        const arrayBuffer = await file.arrayBuffer()
        const size = arrayBuffer.byteLength
        const originalName = file.name || 'file.bin'
        const contentTypeFile = file.type || 'application/octet-stream'
        const uuid = crypto.randomUUID()
        const safeName = originalName.replace(/[^a-zA-Z0-9._-]/g, '_')
        const r2Key = `messages/${messageId}/${uuid}-${safeName}`

        // Subir a R2
        try {
          if ((c.env as any)?.R2_BUCKET && typeof (c.env as any).R2_BUCKET.put === 'function') {
            await c.env.R2_BUCKET.put(r2Key, arrayBuffer, {
              httpMetadata: { contentType: contentTypeFile },
              customMetadata: { originalName },
            })
          } else {
            // Desarrollo local: persistir archivo en ./data/r2/ como fallback (solo para dev)
            try {
              // require dinámico para fs acceso en Node
              // eslint-disable-next-line @typescript-eslint/no-var-requires
              const fs = require('fs')
              const pathMod = require('path')
              const outDir = pathMod.join(process.cwd(), 'data', 'r2')
              fs.mkdirSync(outDir, { recursive: true })
              const outPath = pathMod.join(outDir, r2Key.replace(/\//g, '__'))
              fs.writeFileSync(outPath, Buffer.from(arrayBuffer))
            } catch (fsErr) {
              console.error('local r2 write error:', fsErr)
            }
          }
        } catch (err) {
          console.error('R2 put error:', err)
          // intentar continuar con otros archivos, pero anotar error
          continue
        }

        // Guardar metadatos de adjunto en D1
        const attachSql = `
          INSERT INTO attachments (message_id, r2_key, filename, content_type, size)
          VALUES (?, ?, ?, ?, ?)
        `
        try {
          await db.prepare(attachSql).bind(messageId, r2Key, originalName, contentTypeFile, size).run()
        } catch (err) {
          console.error('DB insert attachment error:', err)
        }

        attachmentsMeta.push({
          filename: originalName,
          r2Key,
          contentType: contentTypeFile,
          size,
        })
      }
    }

    return jsonResponse({
      ok: true,
      message: {
        id: messageId,
        from,
        to,
        subject,
        body,
        solicitudId,
        createdAt,
        attachments: attachmentsMeta,
      },
    })
  } catch (err) {
    console.error('POST /api/messages error:', err)
    return jsonResponse({ error: 'Error interno en el worker', details: String(err) }, 500)
  }
})

/**
 * GET /api/messages
 * @description Lista mensajes (limit opcional) con metadatos de attachments.
 *              Nota: implementar paginación/filtrado según necesidad.
 */
app.get('/api/messages', async (c: Context<{ Bindings: Env }>) => {
  try {
    const limitRaw = c.req.query('limit') || '50'
    const limit = Math.min(Math.max(Number(limitRaw) || 50, 1), 200)

    const db = c.env.SGR_DB
    const messagesRes = await db.prepare(
      `SELECT id, "from", "to", subject, body, solicitud_id, created_at FROM messages ORDER BY created_at DESC LIMIT ?`
    ).bind(limit).all()

    const messages = (messagesRes.results || []).map((r: any) => ({
      id: r.id,
      from: r.from,
      to: r.to,
      subject: r.subject,
      body: r.body,
      solicitudId: r.solicitud_id,
      createdAt: r.created_at,
      attachments: [] as any[],
    }))

    // Cargar attachments por mensaje
    if (messages.length > 0) {
      const ids = messages.map((m) => m.id)
      // Construir placeholder ?,... para binding
      const placeholders = ids.map(() => '?').join(',')
      const attachSql = `SELECT id, message_id, r2_key, filename, content_type, size, created_at FROM attachments WHERE message_id IN (${placeholders})`
      const attachRes = await db.prepare(attachSql).bind(...ids).all()
      const attachments = attachRes.results || []
      const byMessage: Record<number, any[]> = {}
      attachments.forEach((a: any) => {
        byMessage[a.message_id] = byMessage[a.message_id] || []
        byMessage[a.message_id].push({
          id: a.id,
          r2Key: a.r2_key,
          filename: a.filename,
          contentType: a.content_type,
          size: a.size,
          createdAt: a.created_at,
        })
      })
      messages.forEach((m) => {
        m.attachments = byMessage[m.id] || []
      })
    }

    return jsonResponse({ ok: true, messages })
  } catch (err) {
    console.error('GET /api/messages error:', err)
    return jsonResponse({ error: 'Error interno listando mensajes', details: String(err) }, 500)
  }
})

/**
 * OPTIONS handler (CORS preflight)
 */
app.options('/api/*', (c) => {
  return new Response(null, {
    status: 204,
    headers: {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET,POST,OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type',
    },
  })
})

export default app.handle