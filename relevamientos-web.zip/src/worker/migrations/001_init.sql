-- 
-- 001_init.sql
-- Migración inicial para Cloudflare D1 (SQLite).
-- Crea tablas principales necesarias por el Worker y la aplicación SGR.
-- Compatible con D1 (SQLite). Ejecutar en la base D1 antes de usar el Worker.
--

PRAGMA foreign_keys = ON;

-- Dependencias (unidades organizacionales)
CREATE TABLE IF NOT EXISTS dependencias (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  nombre TEXT NOT NULL UNIQUE,
  descripcion TEXT,
  created_at DATETIME DEFAULT (CURRENT_TIMESTAMP),
  updated_at DATETIME DEFAULT (CURRENT_TIMESTAMP)
);

-- Jerarquías policiales
CREATE TABLE IF NOT EXISTS jerarquias (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  nombre TEXT NOT NULL UNIQUE,
  orden INTEGER DEFAULT 0,
  created_at DATETIME DEFAULT (CURRENT_TIMESTAMP),
  updated_at DATETIME DEFAULT (CURRENT_TIMESTAMP)
);

-- Usuarios
CREATE TABLE IF NOT EXISTS usuarios (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  google_user_id TEXT UNIQUE,
  numero_legajo TEXT NOT NULL UNIQUE,
  nombre TEXT NOT NULL,
  apellido TEXT NOT NULL,
  jerarquia TEXT,
  tipo_usuario TEXT NOT NULL, -- 'secretario', 'relevador', 'administrador'
  telefono TEXT,
  email TEXT,
  dependencia_id INTEGER,
  is_active INTEGER DEFAULT 1,
  password_hash TEXT,
  created_at DATETIME DEFAULT (CURRENT_TIMESTAMP),
  updated_at DATETIME DEFAULT (CURRENT_TIMESTAMP),
  FOREIGN KEY (dependencia_id) REFERENCES dependencias(id) ON DELETE SET NULL
);

CREATE INDEX IF NOT EXISTS idx_usuarios_dependencia ON usuarios(dependencia_id);

-- Solicitudes
CREATE TABLE IF NOT EXISTS solicitudes (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  numero_registro TEXT NOT NULL UNIQUE, -- p.e. SGR-YYYYMMDD-XXXX
  fecha TEXT NOT NULL, -- YYYY-MM-DD
  ipp TEXT NOT NULL,
  fiscalia TEXT NOT NULL,
  lugar TEXT NOT NULL,
  caratula TEXT NOT NULL,
  estado TEXT NOT NULL DEFAULT 'pendiente', -- 'pendiente' | 'finalizada'
  creador TEXT,
  creador_id INTEGER,
  has_adjuntos INTEGER DEFAULT 0,
  dependencia_id INTEGER,
  lugar_latitud REAL,
  lugar_longitud REAL,
  created_at DATETIME DEFAULT (CURRENT_TIMESTAMP),
  updated_at DATETIME DEFAULT (CURRENT_TIMESTAMP),
  FOREIGN KEY (dependencia_id) REFERENCES dependencias(id) ON DELETE SET NULL,
  FOREIGN KEY (creador_id) REFERENCES usuarios(id) ON DELETE SET NULL
);

CREATE INDEX IF NOT EXISTS idx_solicitudes_estado ON solicitudes(estado);
CREATE INDEX IF NOT EXISTS idx_solicitudes_dependencia ON solicitudes(dependencia_id);
CREATE INDEX IF NOT EXISTS idx_solicitudes_ipp ON solicitudes(ipp);

-- Relevamientos
CREATE TABLE IF NOT EXISTS relevamientos (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  solicitud_id INTEGER NOT NULL,
  relevador_id INTEGER,
  observaciones TEXT,
  is_finalizado INTEGER DEFAULT 0,
  finalizado_at DATETIME,
  created_at DATETIME DEFAULT (CURRENT_TIMESTAMP),
  updated_at DATETIME DEFAULT (CURRENT_TIMESTAMP),
  FOREIGN KEY (solicitud_id) REFERENCES solicitudes(id) ON DELETE CASCADE,
  FOREIGN KEY (relevador_id) REFERENCES usuarios(id) ON DELETE SET NULL
);

CREATE INDEX IF NOT EXISTS idx_relevamientos_solicitud ON relevamientos(solicitud_id);

-- Cámaras relevadas
CREATE TABLE IF NOT EXISTS camaras_relevadas (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  relevamiento_id INTEGER NOT NULL,
  lugar TEXT NOT NULL,
  lugar_latitud REAL,
  lugar_longitud REAL,
  tipo_camara TEXT NOT NULL, -- 'privada' | 'cm' (camara municipal)
  accion TEXT NOT NULL,
  entrevistado_nombre TEXT,
  entrevistado_apellido TEXT,
  entrevistado_dni TEXT,
  entrevistado_edad INTEGER,
  entrevistado_domicilio TEXT,
  entrevistado_telefono TEXT,
  observaciones TEXT,
  created_at DATETIME DEFAULT (CURRENT_TIMESTAMP),
  updated_at DATETIME DEFAULT (CURRENT_TIMESTAMP),
  FOREIGN KEY (relevamiento_id) REFERENCES relevamientos(id) ON DELETE CASCADE
);

-- Vecinos entrevistados
CREATE TABLE IF NOT EXISTS vecinos_entrevistados (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  relevamiento_id INTEGER NOT NULL,
  lugar TEXT NOT NULL,
  entrevistado_nombre TEXT,
  entrevistado_apellido TEXT,
  entrevistado_dni TEXT,
  entrevistado_edad INTEGER,
  entrevistado_domicilio TEXT,
  entrevistado_telefono TEXT,
  is_presencio INTEGER DEFAULT 0,
  descripcion_presencia TEXT,
  is_conocimiento INTEGER DEFAULT 0,
  descripcion_conocimiento TEXT,
  is_camaras_no_graban INTEGER DEFAULT 0,
  is_no_posee_camaras INTEGER DEFAULT 0,
  is_camaras_no_dan_lugar INTEGER DEFAULT 0,
  observaciones TEXT,
  created_at DATETIME DEFAULT (CURRENT_TIMESTAMP),
  updated_at DATETIME DEFAULT (CURRENT_TIMESTAMP),
  FOREIGN KEY (relevamiento_id) REFERENCES relevamientos(id) ON DELETE CASCADE
);

-- Mensajes (utilizado por el Worker)
-- NOTA: las columnas "from" y "to" se definen entre comillas porque son palabras reservadas.
CREATE TABLE IF NOT EXISTS messages (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  "from" TEXT NOT NULL,
  "to" TEXT NOT NULL,
  subject TEXT,
  body TEXT,
  solicitud_id TEXT, -- puede ser número_registro o id según integración; Worker guarda lo que recibe
  created_at DATETIME DEFAULT (CURRENT_TIMESTAMP)
);

CREATE INDEX IF NOT EXISTS idx_messages_created_at ON messages(created_at);

-- Attachments (metadatos persistidos en DB; los binarios se almacenan en R2)
CREATE TABLE IF NOT EXISTS attachments (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  message_id INTEGER NOT NULL,
  r2_key TEXT NOT NULL,
  filename TEXT NOT NULL,
  content_type TEXT,
  size INTEGER,
  created_at DATETIME DEFAULT (CURRENT_TIMESTAMP),
  FOREIGN KEY (message_id) REFERENCES messages(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_attachments_message ON attachments(message_id);

-- Archivos adjuntos (alternativa con expiración específica para la lógica de UI)
CREATE TABLE IF NOT EXISTS archivos_adjuntos (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  mensaje_id INTEGER NOT NULL,
  nombre_archivo TEXT NOT NULL,
  r2_key TEXT NOT NULL,
  tamano INTEGER,
  tipo_mime TEXT,
  expira_at DATETIME, -- calcular desde aplicación: datetime('now', '+15 days')
  created_at DATETIME DEFAULT (CURRENT_TIMESTAMP),
  updated_at DATETIME DEFAULT (CURRENT_TIMESTAMP),
  FOREIGN KEY (mensaje_id) REFERENCES messages(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_archivos_expira ON archivos_adjuntos(expira_at);

-- Sesiones locales
CREATE TABLE IF NOT EXISTS sesiones_locales (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  usuario_id INTEGER NOT NULL,
  token TEXT NOT NULL UNIQUE,
  expires_at DATETIME NOT NULL,
  created_at DATETIME DEFAULT (CURRENT_TIMESTAMP),
  updated_at DATETIME DEFAULT (CURRENT_TIMESTAMP),
  FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_sesiones_usuario ON sesiones_locales(usuario_id);

-- Triggers para mantener updated_at automáticamente
CREATE TRIGGER IF NOT EXISTS trigger_dependencias_updated_at
AFTER UPDATE ON dependencias
BEGIN
  UPDATE dependencias SET updated_at = CURRENT_TIMESTAMP WHERE id = NEW.id;
END;

CREATE TRIGGER IF NOT EXISTS trigger_usuarios_updated_at
AFTER UPDATE ON usuarios
BEGIN
  UPDATE usuarios SET updated_at = CURRENT_TIMESTAMP WHERE id = NEW.id;
END;

CREATE TRIGGER IF NOT EXISTS trigger_solicitudes_updated_at
AFTER UPDATE ON solicitudes
BEGIN
  UPDATE solicitudes SET updated_at = CURRENT_TIMESTAMP WHERE id = NEW.id;
END;

CREATE TRIGGER IF NOT EXISTS trigger_relevamientos_updated_at
AFTER UPDATE ON relevamientos
BEGIN
  UPDATE relevamientos SET updated_at = CURRENT_TIMESTAMP WHERE id = NEW.id;
END;

-- Fin de la migración inicial
