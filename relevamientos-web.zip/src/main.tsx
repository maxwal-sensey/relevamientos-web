/**
 * @file main.tsx
 * @description Punto de entrada de la aplicación. Envuelve la App con DeviceProvider
 *              para exponer la detección de dispositivo (móvil / tablet / desktop).
 */

import React from 'react'
import { createRoot } from 'react-dom/client'
import './shadcn.css'
/**
 * @note Importamos el polyfill de entorno lo antes posible para garantizar que
 *       window.__ENV__ esté disponible antes que cualquier otro módulo que lo use.
 */
import './runtime/envPolyfill'
import App from './App'
import { DeviceProvider } from './context/DeviceContext'

/**
 * Renderiza la aplicación envolviendo en providers globales.
 */
const root = createRoot(document.getElementById('app')!)
root.render(
  <React.StrictMode>
    <DeviceProvider>
      <App />
    </DeviceProvider>
  </React.StrictMode>
)