/**
 * @file serverConfig.ts
 * @description Configuración runtime para la aplicación. Lectura defensiva de variables
 *              de entorno en distintos entornos de ejecución para evitar errores de "cannot read property".
 */

/**
 * @description Intenta obtener una variable de configuración desde varios orígenes en runtime.
 *              Prioridad:
 *                1) globalThis.__ENV__ (inyectado en runtime)
 *                2) globalThis.process.env (cuando existe)
 *                3) import.meta.env (si está disponible)
 *
 * @param key Nombre de la variable (p. ej. 'VITE_API_BASE')
 * @returns Valor en string o undefined si no está disponible
 */
function getRuntimeEnv(key: string): string | undefined {
  // Obtener referencia segura al objeto global
  const g: any = typeof globalThis !== 'undefined' ? globalThis : (typeof window !== 'undefined' ? window : (typeof global !== 'undefined' ? global : {}))

  try {
    // 1) globalThis.__ENV__
    if (g && g.__ENV__ && typeof g.__ENV__[key] !== 'undefined') {
      return String(g.__ENV__[key])
    }

    // 2) process.env (cuando está presente)
    if (g && g.process && g.process.env && typeof g.process.env[key] !== 'undefined') {
      return String(g.process.env[key])
    }

    // 3) import.meta.env (protegido con try/catch por compatibilidad)
    try {
      const meta: any = typeof import.meta !== 'undefined' ? (import.meta as any) : undefined
      if (meta && meta.env && typeof meta.env[key] !== 'undefined') {
        return String(meta.env[key])
      }
    } catch (e) {
      // ignorar, no disponible en este entorno
    }
  } catch (e) {
    // No interrumpir la ejecución por fallo al leer globals
    // tslint:disable-next-line:no-console
    console && typeof console.warn === 'function' && console.warn('[serverConfig] getRuntimeEnv error', e)
  }

  return undefined
}

/**
 * @description Indica la URL base del API. Usa varios orígenes y un fallback '/api'.
 */
export const API_BASE: string = getRuntimeEnv('VITE_API_BASE') || '/api'

/**
 * @description Si se activa (1 o "true"), la app usará los mocks locales (mockApi) en vez del backend real.
 */
export const USE_MOCKS: boolean = ((): boolean => {
  const val = getRuntimeEnv('VITE_USE_MOCKS')
  if (!val) return false
  const s = String(val).toLowerCase()
  return s === '1' || s === 'true'
})()

/**
 * @description Límite de subida recomendado en MB (para Pi se sugiere un número moderado).
 */
export const UPLOAD_LIMIT_MB: number = Number(getRuntimeEnv('VITE_UPLOAD_LIMIT_MB') ?? 20)

/**
 * @description Consejo de configuración de Node al desplegar en Pi 3 (no es una variable que se use en el bundle).
 */
export const NODE_MEMORY_HINT_MB = 384

/**
 * @description Recomendación de swap/zram a considerar en la Pi (informativa).
 */
export const RECOMMENDED_SWAP_MB = 512