/**
 * @file relevamientosStore.ts
 * @description Almacenamiento en memoria para relevamientos e informes imprimibles (solo demo frontend).
 */

export type EstadoRelevamiento = 'en_curso' | 'finalizado'

/**
 * @interface RelevamientoItem
 * @description Representa un relevamiento en el listado general.
 */
export interface RelevamientoItem {
  id: number
  numeroRegistro: string
  fecha: string
  ipp: string
  caratula: string
  lugar: string
  relevador: string
  estado: EstadoRelevamiento
  /** Identificador de dependencia asociada al relevamiento (para simulación de visibilidad). */
  dependenciaId?: number | null
}

/**
 * @interface CameraReport
 * @description Datos de una cámara relevada dentro del informe.
 */
export interface CameraReport {
  id: number
  lugar: string
  tipo: 'Privada' | 'COM'
  accion: string
  entrevistado?: string
  observaciones?: string
}

/**
 * @interface VecinoReport
 * @description Datos de un vecino entrevistado dentro del informe.
 */
export interface VecinoReport {
  id: number
  nombreCompleto: string
  dni?: string
  lugarEntrevista: string
  presencio: boolean
  detallePresencio?: string
  conocimiento: boolean
  detalleConocimiento?: string
  infoCamaras?: string
  observaciones?: string
}

/**
 * @interface InformeRelevamientoData
 * @description Estructura principal del informe de relevamiento imprimible.
 */
export interface InformeRelevamientoData {
  id: number
  numeroRegistro: string
  ipp: string
  fiscalia: string
  fecha: string
  caratula: string
  lugar: string
  resumenHecho: string
  observacionesGenerales: string
  relevadorNombre: string
  secretariaNombre: string
  dependenciaNombre: string
  camaras: CameraReport[]
  vecinos: VecinoReport[]
}

/**
 * @description Datos iniciales de relevamientos para el listado (mock).
 */
let relevamientos: RelevamientoItem[] = [
  {
    id: 1,
    numeroRegistro: 'SGR-20250217-0002',
    fecha: '2025-02-18',
    ipp: 'PP-56789-2025',
    caratula: 'Homicidio culposo',
    lugar: 'Av. Siempre Viva 742, La Plata',
    relevador: 'García, Mario (Relev.)',
    estado: 'finalizado',
    dependenciaId: 10,
  },
  {
    id: 2,
    numeroRegistro: 'SGR-20250218-0001',
    fecha: '2025-02-18',
    ipp: 'PP-12345-2025',
    caratula: 'Robo agravado',
    lugar: 'Calle Falsa 123, La Plata',
    relevador: 'López, Carla (Relev.)',
    estado: 'en_curso',
    dependenciaId: 10,
  },
  {
    id: 3,
    numeroRegistro: 'SGR-20250210-0003',
    fecha: '2025-02-10',
    ipp: 'PP-22222-2025',
    caratula: 'Lesiones leves',
    lugar: 'Calle 50 y 7, La Plata',
    relevador: 'Admin, Demo',
    estado: 'finalizado',
    dependenciaId: 20,
  },
]

/**
 * @description Datos iniciales de informes imprimibles (mock).
 */
let informes: InformeRelevamientoData[] = [
  {
    id: 1,
    numeroRegistro: 'SGR-20250217-0002',
    ipp: 'PP-56789-2025',
    fiscalia: 'UFIJ N° 7',
    fecha: '2025-02-18',
    caratula: 'Homicidio culposo',
    lugar: 'Av. Siempre Viva 742, La Plata',
    resumenHecho:
      'Según lo informado por la UFIJ interviniente, en fecha 17/02/2025, en horas de la noche, se produjo un siniestro vial con resultado de víctima fatal sobre Av. Siempre Viva 742, en circunstancias que se investigan.',
    observacionesGenerales:
      'Se relevaron cámaras municipales y privadas en un radio aproximado de 200 metros a la redonda del lugar del hecho, así como vecinos frentistas y comercios de la zona.',
    relevadorNombre: 'García, Mario (Relevador)',
    secretariaNombre: 'Pérez, Juan (Secretario)',
    dependenciaNombre: 'Comisaría 1ra. La Plata',
    camaras: [
      {
        id: 1,
        lugar: 'Av. Siempre Viva 742 - Frente al lugar del hecho',
        tipo: 'COM',
        accion: 'Se solicitó grabación al Centro de Monitoreo Municipal.',
        entrevistado: 'Operador de COM',
        observaciones:
          'Recibe nota de solicitud de imágenes por el período 17/02/2025 19:00 a 23:59 hs.',
      },
      {
        id: 2,
        lugar: 'Esquina Av. Siempre Viva y Calle 10 - Verdulería',
        tipo: 'Privada',
        accion: 'No apunta directamente al lugar del hecho.',
        entrevistado: 'Dueño del comercio',
        observaciones: 'Cámara orientada hacia el interior del local.',
      },
    ],
    vecinos: [
      {
        id: 1,
        nombreCompleto: 'Gómez, Ana',
        dni: '30.123.456',
        lugarEntrevista: 'Av. Siempre Viva 738 – Domicilio particular',
        presencio: true,
        detallePresencio:
          'Refiere haber escuchado un fuerte impacto y observar posteriormente presencia policial y ambulancia.',
        conocimiento: true,
        detalleConocimiento:
          'Manifiesta que el vehículo se trasladaba a alta velocidad y que la calzada se encontraba húmeda.',
        infoCamaras: 'No posee cámaras de seguridad en el frente de su domicilio.',
        observaciones: 'Aporta número de teléfono para eventuales ampliaciones.',
      },
      {
        id: 2,
        nombreCompleto: 'López, Carlos',
        dni: '28.987.654',
        lugarEntrevista: 'Av. Siempre Viva 750 – Comercio “Kiosco 24hs”',
        presencio: false,
        detallePresencio: 'No presenció el hecho.',
        conocimiento: true,
        detalleConocimiento:
          'Toma conocimiento por comentarios de vecinos y noticias locales.',
        infoCamaras:
          'Posee cámaras pero no graban hacia el lugar específico del hecho.',
        observaciones: 'Se deja constancia de predisposición a colaborar.',
      },
    ],
  },
  {
    id: 2,
    numeroRegistro: 'SGR-20250218-0001',
    ipp: 'PP-12345-2025',
    fiscalia: 'UFIJ N° 3',
    fecha: '2025-02-18',
    caratula: 'Robo agravado',
    lugar: 'Calle Falsa 123, La Plata',
    resumenHecho:
      'Hecho de robo agravado ocurrido en comercio de rubro minimercado, donde autores ignorados sustraen dinero en efectivo y mercaderías.',
    observacionesGenerales:
      'Se relevaron cámaras de comercios linderos y se entrevistó a vecinos frentistas. No se obtuvieron testigos directos del hecho.',
    relevadorNombre: 'López, Carla (Relevadora)',
    secretariaNombre: 'Gómez, Ana (Secretaria)',
    dependenciaNombre: 'Comisaría 2da. La Plata',
    camaras: [
      {
        id: 1,
        lugar: 'Calle Falsa 121 – Comercio “Panadería Central”',
        tipo: 'Privada',
        accion: 'Se solicitó grabación.',
        entrevistado: 'Encargado del comercio',
        observaciones:
          'Recibe nota de solicitud de imágenes, manifiesta que conservará registros por 7 días.',
      },
    ],
    vecinos: [
      {
        id: 1,
        nombreCompleto: 'Pérez, Roberto',
        dni: '25.456.789',
        lugarEntrevista: 'Calle Falsa 125 – Domicilio particular',
        presencio: false,
        detallePresencio: 'No presenció el hecho.',
        conocimiento: true,
        detalleConocimiento:
          'Dice conocer comentarios sobre asaltos previos en la zona.',
        infoCamaras: 'No posee cámaras de seguridad.',
        observaciones: 'Sin más datos de interés.',
      },
    ],
  },
  {
    id: 3,
    numeroRegistro: 'SGR-20250210-0003',
    ipp: 'PP-22222-2025',
    fiscalia: 'UFIJ N° 1',
    fecha: '2025-02-10',
    caratula: 'Lesiones leves',
    lugar: 'Calle 50 y 7, La Plata',
    resumenHecho:
      'Lesiones leves en la vía pública producto de una discusión entre dos personas, con intervención de personal policial y traslado al centro asistencial.',
    observacionesGenerales:
      'Se relevaron cámaras públicas cercanas y se entrevistó a frentistas directos. Sin aportes de relevancia en cuanto a la mecánica previa al hecho.',
    relevadorNombre: 'Admin, Demo (Relevador)',
    secretariaNombre: 'Admin, Demo (Secretario)',
    dependenciaNombre: 'Dependencia de prueba',
    camaras: [
      {
        id: 1,
        lugar: 'Calle 50 y 7 – Cámara municipal esquina noreste',
        tipo: 'COM',
        accion: 'No registra correctamente el lugar del hecho.',
        entrevistado: 'Operador de COM',
        observaciones:
          'Campo visual parcial; no se visualiza el sector preciso donde ocurre la discusión.',
      },
    ],
    vecinos: [
      {
        id: 1,
        nombreCompleto: 'Testigo reservado 1',
        lugarEntrevista: 'Cercanías de Calle 50 y 7',
        presencio: true,
        detallePresencio:
          'Refiere observar altercado verbal previo a la agresión física.',
        conocimiento: true,
        detalleConocimiento:
          'Conoce a uno de los involucrados por ser vecino de la zona.',
        infoCamaras: 'No posee cámaras propias.',
        observaciones: 'Solicita reserva de identidad.',
      },
    ],
  },
]

/**
 * @function getRelevamientos
 * @description Devuelve el listado actual de relevamientos mock.
 */
export function getRelevamientos(): RelevamientoItem[] {
  return relevamientos
}

/**
 * @function getInformeById
 * @description Busca un informe por su identificador interno.
 */
export function getInformeById(
  id: number
): InformeRelevamientoData | undefined {
  return informes.find((item) => item.id === id)
}

/**
 * @interface RegisterNuevoRelevamientoParams
 * @description Parámetros necesarios para registrar un nuevo relevamiento en el store.
 */
export interface RegisterNuevoRelevamientoParams {
  solicitudNumeroRegistro: string
  solicitudIPP: string
  fiscalia: string
  caratula: string
  lugar: string
  resumenHecho: string
  observacionesGenerales: string
  camaras: CameraReport[]
  vecinos: VecinoReport[]
  relevadorNombre: string
  secretariaNombre: string
  dependenciaNombre: string
  /** Identificador de dependencia asociada al relevamiento (para filtrado por acceso). */
  dependenciaId?: number | null
}

/**
 * @function registerNuevoRelevamientoFromForm
 * @description Inserta un nuevo relevamiento y su informe asociado basados en el formulario de alta. Devuelve el id interno generado.
 */
export function registerNuevoRelevamientoFromForm(
  params: RegisterNuevoRelevamientoParams
): number {
  const maxId = Math.max(
    0,
    ...relevamientos.map((r) => r.id),
    ...informes.map((i) => i.id)
  )

  const nextId = maxId + 1
  const today = new Date()
  const fechaIso = today.toISOString().slice(0, 10)

  const nuevoRelevamiento: RelevamientoItem = {
    id: nextId,
    numeroRegistro: params.solicitudNumeroRegistro,
    fecha: fechaIso,
    ipp: params.solicitudIPP,
    caratula: params.caratula,
    lugar: params.lugar,
    relevador: params.relevadorNombre,
    estado: 'en_curso',
    dependenciaId: params.dependenciaId ?? null,
  }

  const nuevoInforme: InformeRelevamientoData = {
    id: nextId,
    numeroRegistro: params.solicitudNumeroRegistro,
    ipp: params.solicitudIPP,
    fiscalia: params.fiscalia,
    fecha: fechaIso,
    caratula: params.caratula,
    lugar: params.lugar,
    resumenHecho: params.resumenHecho,
    observacionesGenerales: params.observacionesGenerales,
    relevadorNombre: params.relevadorNombre,
    secretariaNombre: params.secretariaNombre,
    dependenciaNombre: params.dependenciaNombre,
    camaras: params.camaras,
    vecinos: params.vecinos,
  }

  relevamientos = [...relevamientos, nuevoRelevamiento]
  informes = [...informes, nuevoInforme]

  return nextId
}
