/**
 * @file messagesStore.ts
 * @description Almacenamiento demo en memoria para notificaciones/mensajes (funciones CRUD simples).
 */

 /** Tipos y datos demo para mensajes internos. */
export interface DemoMessage {
  /** Identificador único del mensaje */
  id: number
  /** Nombre legible del remitente */
  remitente: string
  /** Nombre legible del destinatario */
  destinatario: string
  /** Asunto del mensaje */
  asunto: string
  /** Cuerpo del mensaje */
  contenido: string
  /** Fecha ISO de creación */
  createdAt: string
  /** Flag indicando si fue leído por el destinatario */
  isLeido: boolean
  /** Opcional: id de solicitud relacionada (demo) */
  solicitudId?: string
}

/** Mensajes iniciales de ejemplo para la demo. */
let MESSAGES: DemoMessage[] = [
  {
    id: 1,
    remitente: 'Garcia, Lucia',
    destinatario: 'Perez, Juan',
    asunto: 'Solicitud 2025-0001 - detalle',
    contenido: 'Adjunto el detalle inicial de la solicitud. Revisar y confirmar recepción.',
    createdAt: new Date().toISOString(),
    isLeido: false,
    solicitudId: 'SGR-20250218-0001',
  },
  {
    id: 2,
    remitente: 'Perez, Juan',
    destinatario: 'Garcia, Lucia',
    asunto: 'Re: Solicitud 2025-0001 - confirmación',
    contenido: 'Recibido. Procedo con la coordinación del relevamiento.',
    createdAt: new Date(Date.now() - 1000 * 60 * 60 * 24).toISOString(),
    isLeido: true,
    solicitudId: 'SGR-20250218-0001',
  },
  {
    id: 3,
    remitente: 'Lopez, Marta',
    destinatario: 'Perez, Juan',
    asunto: 'Recordatorio reunión',
    contenido: 'Recordatorio: reunión operativa mañana 10:00 hs.',
    createdAt: new Date(Date.now() - 1000 * 60 * 60 * 5).toISOString(),
    isLeido: false,
  },
]

/**
 * getMessagesForRecipient
 * @description Retorna los mensajes recibidos por el nombre del usuario (demo).
 * @param destinatario Nombre del destinatario (por ejemplo "Perez, Juan")
 */
export function getMessagesForRecipient(destinatario: string): DemoMessage[] {
  return MESSAGES.filter((m) => m.destinatario === destinatario).sort(
    (a, b) => +new Date(b.createdAt) - +new Date(a.createdAt)
  )
}

/**
 * getMessagesSentBy
 * @description Retorna los mensajes enviados por el usuario (demo).
 * @param remitente Nombre del remitente
 */
export function getMessagesSentBy(remitente: string): DemoMessage[] {
  return MESSAGES.filter((m) => m.remitente === remitente).sort(
    (a, b) => +new Date(b.createdAt) - +new Date(a.createdAt)
  )
}

/**
 * getUnreadCount
 * @description Cuenta mensajes no leídos para un destinatario.
 * @param destinatario Nombre del destinatario
 */
export function getUnreadCount(destinatario: string): number {
  return MESSAGES.filter((m) => m.destinatario === destinatario && !m.isLeido).length
}

/**
 * sendMessage
 * @description Crea un nuevo mensaje demo y lo agrega al store en memoria.
 * @param remitente Nombre remitente
 * @param destinatario Nombre destinatario
 * @param asunto Asunto del mensaje
 * @param contenido Cuerpo del mensaje
 * @returns El mensaje creado
 */
export function sendMessage(
  remitente: string,
  destinatario: string,
  asunto: string,
  contenido: string
): DemoMessage {
  const nextId = MESSAGES.length ? Math.max(...MESSAGES.map((m) => m.id)) + 1 : 1
  const msg: DemoMessage = {
    id: nextId,
    remitente,
    destinatario,
    asunto,
    contenido,
    createdAt: new Date().toISOString(),
    isLeido: false,
  }
  MESSAGES = [msg, ...MESSAGES]
  return msg
}

/**
 * markAsRead
 * @description Marca un mensaje como leído (si el destinatario coincide).
 * @param id Id del mensaje
 * @param destinatario Nombre del destinatario que marca como leído
 * @returns boolean si se marcó
 */
export function markAsRead(id: number, destinatario: string): boolean {
  const idx = MESSAGES.findIndex((m) => m.id === id && m.destinatario === destinatario)
  if (idx === -1) return false
  MESSAGES[idx] = { ...MESSAGES[idx], isLeido: true }
  return true
}