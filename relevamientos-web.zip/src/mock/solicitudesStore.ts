/**
 * @file solicitudesStore.ts
 * @description Mock store para gestionar solicitudes en memoria y exponer
 *              funciones asíncronas que simulan endpoints para consumo desde
 *              distintas páginas. Incluye validación con Zod para creación.
 */

import { z } from 'zod'
import { CreateSolicitudSchema, CreateSolicitudInput } from '../schemas/solicitudSchema'

/**
 * Solicitud
 * @description Tipo que representa una solicitud en el frontend.
 */
export interface Solicitud {
  id: number
  numeroRegistro: string
  fecha: string
  ipp: string
  fiscalia: string
  lugar: string
  caratula: string
  estado: 'pendiente' | 'finalizada'
  creador: string
  hasAdjuntos: boolean
  dependenciaId: number | null
  lat?: number | null
  lng?: number | null
}

/**
 * MOCK_SOLICITUDES
 * @description Datos de ejemplo en memoria que actúan como fuente del mock-store.
 */
let MOCK_SOLICITUDES: Solicitud[] = [
  {
    id: 1,
    numeroRegistro: 'SGR-20250218-0001',
    fecha: '2025-02-18',
    ipp: 'PP-12345-2025',
    fiscalia: 'UFIJ N° 3',
    lugar: 'Calle Falsa 123, La Plata',
    caratula: 'Robo agravado',
    estado: 'pendiente',
    creador: 'Pérez, Juan (Sec.)',
    hasAdjuntos: true,
    dependenciaId: 10,
    lat: -34.9220,
    lng: -57.9545,
  },
  {
    id: 2,
    numeroRegistro: 'SGR-20250217-0002',
    fecha: '2025-02-17',
    ipp: 'PP-56789-2025',
    fiscalia: 'UFIJ N° 7',
    lugar: 'Av. Siempre Viva 742, La Plata',
    caratula: 'Homicidio culposo',
    estado: 'finalizada',
    creador: 'Gómez, Ana (Sec.)',
    hasAdjuntos: true,
    dependenciaId: 10,
    lat: -34.9205,
    lng: -57.9530,
  },
  {
    id: 3,
    numeroRegistro: 'SGR-20250210-0003',
    fecha: '2025-02-10',
    ipp: 'PP-22222-2025',
    fiscalia: 'UFIJ N° 1',
    lugar: 'Calle 50 y 7, La Plata',
    caratula: 'Lesiones leves',
    estado: 'pendiente',
    creador: 'Admin, Demo',
    hasAdjuntos: false,
    dependenciaId: 10,
    lat: null,
    lng: null,
  },
  {
    id: 4,
    numeroRegistro: 'SGR-20250130-0004',
    fecha: '2025-01-30',
    ipp: 'PP-99999-2025',
    fiscalia: 'UFIJ N° 9',
    lugar: 'Diagonal 80 y 116, La Plata',
    caratula: 'Robo simple',
    estado: 'finalizada',
    creador: 'Admin, Demo',
    hasAdjuntos: true,
    dependenciaId: 20,
    lat: -34.9150,
    lng: -57.9500,
  },
]

/**
 * fetchSolicitudes
 * @description Simula una llamada a un endpoint que devuelve todas las solicitudes.
 * @returns Promise<Solicitud[]>
 */
export function fetchSolicitudes(): Promise<Solicitud[]> {
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve(MOCK_SOLICITUDES.map((s) => ({ ...s })))
    }, 250)
  })
}

/**
 * getSolicitudById
 * @description Recupera una solicitud por id (simula endpoint).
 * @param id Identificador numérico de la solicitud
 * @returns Promise<Solicitud | null>
 */
export function getSolicitudById(id: number): Promise<Solicitud | null> {
  return new Promise((resolve) => {
    setTimeout(() => {
      const found = MOCK_SOLICITUDES.find((s) => s.id === id)
      resolve(found ? { ...found } : null)
    }, 200)
  })
}

/**
 * searchSolicitudes
 * @description Función auxiliar para buscar solicitudes por término (simulada).
 * @param term Texto de búsqueda
 * @returns Promise<Solicitud[]>
 */
export function searchSolicitudes(term: string): Promise<Solicitud[]> {
  return new Promise((resolve) => {
    setTimeout(() => {
      const t = term.trim().toLowerCase()
      if (!t) {
        resolve(MOCK_SOLICITUDES.map((s) => ({ ...s })))
        return
      }
      const filtered = MOCK_SOLICITUDES.filter((s) => {
        return (
          s.numeroRegistro.toLowerCase().includes(t) ||
          s.ipp.toLowerCase().includes(t) ||
          s.fiscalia.toLowerCase().includes(t) ||
          s.caratula.toLowerCase().includes(t) ||
          s.lugar.toLowerCase().includes(t)
        )
      })
      resolve(filtered.map((s) => ({ ...s })))
    }, 200)
  })
}

/**
 * updateSolicitud
 * @description Simula el endpoint de actualización de una solicitud en el mock-store.
 *              Modifica el objeto en memoria y devuelve la versión actualizada.
 * @param id Identificador de la solicitud a actualizar
 * @param patch Campos a actualizar
 * @returns Promise<Solicitud | null>
 */
export function updateSolicitud(
  id: number,
  patch: Partial<Omit<Solicitud, 'id' | 'numeroRegistro' | 'fecha'>>
): Promise<Solicitud | null> {
  return new Promise((resolve) => {
    setTimeout(() => {
      const idx = MOCK_SOLICITUDES.findIndex((s) => s.id === id)
      if (idx === -1) {
        resolve(null)
        return
      }
      const updated: Solicitud = { ...MOCK_SOLICITUDES[idx], ...patch }
      MOCK_SOLICITUDES[idx] = updated
      resolve({ ...updated })
    }, 250)
  })
}

/**
 * buildNumeroRegistro
 * @description Genera el numeroRegistro en formato SGR-YYYYMMDD-XXXX con secuencial por día.
 * @param date Fecha en formato YYYY-MM-DD
 * @returns string
 */
function buildNumeroRegistro(date: string) {
  const datePart = date.replace(/-/g, '')
  const sameDay = MOCK_SOLICITUDES.filter((s) => s.fecha === date)
  const seq = (sameDay.length + 1).toString().padStart(4, '0')
  return `SGR-${datePart}-${seq}`
}

/**
 * createSolicitud
 * @description Valida con Zod y crea una nueva solicitud en el mock-store.
 * @param input Datos de creación (validados con CreateSolicitudSchema)
 * @param creador Nombre del creador (opcional, mock)
 * @returns Promise<Solicitud>
 */
export function createSolicitud(input: CreateSolicitudInput, creador = 'Usuario Demo'): Promise<Solicitud> {
  return new Promise((resolve, reject) => {
    // Validar entrada con Zod
    const parsed = CreateSolicitudSchema.safeParse(input)
    if (!parsed.success) {
      // Devolver errores de validación de forma estructurada
      const issues = parsed.error.issues.map((i) => ({ path: i.path, message: i.message }))
      reject({ validation: true, issues })
      return
    }

    setTimeout(() => {
      const today = new Date()
      const fecha = today.toISOString().slice(0, 10) // YYYY-MM-DD
      const newId = MOCK_SOLICITUDES.reduce((max, s) => Math.max(max, s.id), 0) + 1
      const numeroRegistro = buildNumeroRegistro(fecha)

      const nuevo: Solicitud = {
        id: newId,
        numeroRegistro,
        fecha,
        ipp: parsed.data.ipp,
        fiscalia: parsed.data.fiscalia,
        lugar: parsed.data.lugar,
        caratula: parsed.data.caratula,
        estado: 'pendiente',
        creador,
        hasAdjuntos: !!parsed.data.hasAdjuntos,
        dependenciaId: parsed.data.dependenciaId ?? null,
        lat: parsed.data.lat ?? null,
        lng: parsed.data.lng ?? null,
      }

      MOCK_SOLICITUDES.push(nuevo)
      resolve({ ...nuevo })
    }, 250)
  })
}