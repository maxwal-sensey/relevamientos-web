/**
 * @file AppLayout.tsx
 * @description Layout principal de la aplicación que envuelve páginas con sidebar y header.
 */

import React from 'react'
import Sidebar from './Sidebar'
import { LogOut } from 'lucide-react'

/**
 * AppLayoutProps
 * @description Props del componente AppLayout.
 */
interface AppLayoutProps {
  title?: string
  children: React.ReactNode
}

/**
 * AppLayout
 * @description Componente de layout que muestra la Sidebar y un header minimal.
 */
export default function AppLayout({ title, children }: AppLayoutProps) {
  return (
    <div className="min-h-screen flex bg-sky-50">
      <Sidebar />

      <div className="flex-1 flex flex-col">
        <header className="h-14 bg-white border-b border-sky-100 flex items-center justify-between px-6">
          <div className="flex items-center gap-4">
            <h1 className="text-lg font-semibold text-slate-700">{title ?? 'Panel'}</h1>
          </div>

          <div className="flex items-center gap-3">
            <button
              type="button"
              className="flex items-center gap-2 text-sm text-slate-600 hover:text-slate-800 px-3 py-1 rounded"
            >
              <LogOut size={16} />
              <span>Cerrar sesión</span>
            </button>
          </div>
        </header>

        <main className="p-6 overflow-auto">{children}</main>
      </div>
    </div>
  )
}
