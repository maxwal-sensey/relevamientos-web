/**
 * @file RelevamientosList.tsx
 * @description Componente que renderiza un listado/tablas de relevamientos (filas) con acciones
 *              (resumen rápido, ver informe). Diseñado como unidad reutilizable y tipado en TS.
 */

import React from 'react'
import { FileText, Camera, Users, MapPin } from 'lucide-react'
import { showQuickSummary } from './QuickSummary'
import type { InformeRelevamientoData } from '../../mock/relevamientosStore'

/**
 * RelevamientosListProps
 * @description Props del componente RelevamientosList.
 */
interface RelevamientosListProps {
  /** Lista de informes/relevamientos a mostrar */
  informes: InformeRelevamientoData[]
}

/**
 * RelevamientosList
 * @description Renderiza una tabla responsiva con una fila por relevamiento.
 *              Provee acciones rápidas: Resumen (modal) y navegación a informe completo.
 */
export default function RelevamientosList({ informes }: RelevamientosListProps) {
  /**
   * handleShowSummary
   * @description Invoca el modal de resumen rápido para el id indicado.
   */
  function handleShowSummary(id: number) {
    showQuickSummary(id)
  }

  return (
    <section className="overflow-hidden rounded-lg border border-slate-800 bg-slate-900/70">
      <div className="overflow-x-auto">
        <table className="min-w-full text-sm">
          <thead className="bg-slate-900/90 text-slate-300">
            <tr>
              <th className="px-4 py-3 text-left font-semibold">N° Registro</th>
              <th className="px-4 py-3 text-left font-semibold">Fecha</th>
              <th className="px-4 py-3 text-left font-semibold">Carátula</th>
              <th className="px-4 py-3 text-left font-semibold">Lugar</th>
              <th className="px-4 py-3 text-center font-semibold">Cámaras</th>
              <th className="px-4 py-3 text-center font-semibold">Vecinos</th>
              <th className="px-4 py-3 text-right font-semibold">Acciones</th>
            </tr>
          </thead>
          <tbody>
            {informes.map((inf) => {
              const camerasCount = inf.camaras?.length ?? 0
              const vecinosCount = inf.vecinos?.length ?? 0
              return (
                <tr key={inf.id} className="border-t border-slate-800 odd:bg-slate-900/60 even:bg-slate-900/50">
                  <td className="whitespace-nowrap px-4 py-3 font-medium text-slate-50">{inf.numeroRegistro || `SGR-${inf.id}`}</td>
                  <td className="whitespace-nowrap px-4 py-3 text-slate-200">{inf.fecha}</td>
                  <td className="px-4 py-3 text-slate-200 max-w-xs truncate">{inf.caratula}</td>
                  <td className="px-4 py-3 text-slate-200 max-w-sm truncate flex items-center gap-2">
                    <MapPin className="h-4 w-4 text-slate-400" />
                    <span className="truncate">{inf.lugar}</span>
                  </td>
                  <td className="px-4 py-3 text-center text-slate-200">
                    <span className="inline-flex items-center gap-2 rounded-full bg-slate-800/40 px-2 py-0.5 text-xs">
                      <Camera className="h-3.5 w-3.5 text-sky-300" />
                      <strong className="text-slate-100">{camerasCount}</strong>
                    </span>
                  </td>
                  <td className="px-4 py-3 text-center text-slate-200">
                    <span className="inline-flex items-center gap-2 rounded-full bg-slate-800/40 px-2 py-0.5 text-xs">
                      <Users className="h-3.5 w-3.5 text-violet-300" />
                      <strong className="text-slate-100">{vecinosCount}</strong>
                    </span>
                  </td>
                  <td className="px-4 py-3 text-right">
                    <div className="flex justify-end gap-2">
                      <button
                        type="button"
                        onClick={() => handleShowSummary(inf.id)}
                        className="inline-flex items-center gap-2 rounded bg-sky-600 px-3 py-1 text-xs font-medium text-white hover:bg-sky-500"
                      >
                        Resumen
                      </button>

                      <a
                        href={`#/relevamientos/${inf.id}/informe`}
                        className="inline-flex items-center gap-2 rounded border border-slate-700 bg-transparent px-3 py-1 text-xs font-medium text-slate-200 hover:bg-slate-800"
                      >
                        Ver
                      </a>
                    </div>
                  </td>
                </tr>
              )
            })}
          </tbody>
        </table>
      </div>
    </section>
  )
}