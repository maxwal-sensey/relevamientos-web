/**
 * @file CameraEntryCard.tsx
 * @description Tarjeta reutilizable para editar una cámara relevada.
 */

import React from 'react'
import { Trash2 } from 'lucide-react'
import type { CameraEntry } from '../../types/relevamiento'

/**
 * @interface Props
 * @description Props para CameraEntryCard.
 */
interface Props {
  cam: CameraEntry
  onUpdate: (id: number, patch: Partial<CameraEntry>) => void
  onRemove: (id: number) => void
}

/**
 * @component CameraEntryCard
 * @description Muestra los campos editables de una cámara y botones de acción.
 */
export default function CameraEntryCard({ cam, onUpdate, onRemove }: Props) {
  return (
    <div key={cam.id} className="space-y-2 rounded-lg border border-slate-800 bg-slate-950 px-3 py-3">
      <div className="flex items-center justify-between gap-2">
        <p className="text-[11px] font-semibold text-slate-100">Cámara</p>
        <button
          type="button"
          onClick={() => onRemove(cam.id)}
          className="inline-flex items-center gap-1 rounded-md border border-red-700/70 px-2 py-0.5 text-[10px] font-medium text-red-200 hover:bg-red-900/60"
        >
          <Trash2 className="h-3 w-3" />
          Quitar
        </button>
      </div>

      <div className="grid gap-2 sm:grid-cols-2">
        <div>
          <label className="mb-1 block text-[11px] font-medium text-slate-200">Lugar / Dirección</label>
          <input
            type="text"
            value={cam.lugar}
            onChange={(e) => onUpdate(cam.id, { lugar: e.target.value })}
            placeholder='Ej: Local "El Sol", esquina 7 y 50'
            className="block w-full rounded-md border border-slate-700 bg-slate-950 px-2 py-1 text-[11px] text-slate-100 placeholder:text-slate-500 focus:border-sky-500 focus:outline-none focus:ring-1 focus:ring-sky-500"
          />
        </div>
        <div className="grid grid-cols-2 gap-2">
          <div>
            <label className="mb-1 block text-[11px] font-medium text-slate-200">Tipo de cámara</label>
            <select
              value={cam.tipoCamara}
              onChange={(e) => onUpdate(cam.id, { tipoCamara: e.target.value as CameraEntry['tipoCamara'] })}
              className="block w-full rounded-md border border-slate-700 bg-slate-950 px-2 py-1 text-[11px] text-slate-100 focus:border-sky-500 focus:outline-none focus:ring-1 focus:ring-sky-500"
            >
              <option value="privada">Privada</option>
              <option value="com">COM / Municipal</option>
            </select>
          </div>
          <div>
            <label className="mb-1 block text-[11px] font-medium text-slate-200">Acción realizada</label>
            <select
              value={cam.accion}
              onChange={(e) => onUpdate(cam.id, { accion: e.target.value as CameraEntry['accion'] })}
              className="block w-full rounded-md border border-slate-700 bg-slate-950 px-2 py-1 text-[11px] text-slate-100 focus:border-sky-500 focus:outline-none focus:ring-1 focus:ring-sky-500"
            >
              <option value="solicito_grabacion">Se solicitó grabación</option>
              <option value="no_graba">No graba / Sin registros</option>
              <option value="no_apunta">No apunta al lugar del hecho</option>
              <option value="negativa">Negativa a entregar grabaciones</option>
              <option value="entrega_material">Entrega material fílmico en el lugar</option>
              <option value="otro">Otro</option>
            </select>
          </div>
        </div>
      </div>

      <div className="grid gap-2 sm:grid-cols-2">
        <div>
          <label className="mb-1 block text-[11px] font-medium text-slate-200">Nombre entrevistado</label>
          <input
            type="text"
            value={cam.entrevistadoNombre}
            onChange={(e) => onUpdate(cam.id, { entrevistadoNombre: e.target.value })}
            className="block w-full rounded-md border border-slate-700 bg-slate-950 px-2 py-1 text-[11px] text-slate-100 placeholder:text-slate-500 focus:border-sky-500 focus:outline-none focus:ring-1 focus:ring-sky-500"
            placeholder="Nombre"
          />
        </div>
        <div>
          <label className="mb-1 block text-[11px] font-medium text-slate-200">Apellido entrevistado</label>
          <input
            type="text"
            value={cam.entrevistadoApellido}
            onChange={(e) => onUpdate(cam.id, { entrevistadoApellido: e.target.value })}
            className="block w-full rounded-md border border-slate-700 bg-slate-950 px-2 py-1 text-[11px] text-slate-100 placeholder:text-slate-500 focus:border-sky-500 focus:outline-none focus:ring-1 focus:ring-sky-500"
            placeholder="Apellido"
          />
        </div>
      </div>

      <div>
        <label className="mb-1 block text-[11px] font-medium text-slate-200">Observaciones</label>
        <textarea
          rows={2}
          value={cam.observaciones}
          onChange={(e) => onUpdate(cam.id, { observaciones: e.target.value })}
          className="block w-full rounded-md border border-slate-700 bg-slate-950 px-2 py-1 text-[11px] text-slate-100 placeholder:text-slate-500 focus:border-sky-500 focus:outline-none focus:ring-1 focus:ring-sky-500"
          placeholder="Describa brevemente el resultado de la gestión con el entrevistado y particularidades de la cámara."
        />
      </div>
    </div>
  )
}