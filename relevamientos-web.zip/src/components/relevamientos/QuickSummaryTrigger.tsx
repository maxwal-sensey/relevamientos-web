/**
 * @file QuickSummaryTrigger.tsx
 * @description Botón reutilizable que abre el modal de resumen rápido de un relevamiento.
 */

import React from 'react'
import { FileText } from 'lucide-react'
import { showQuickSummary } from './QuickSummary'

/**
 * QuickSummaryTriggerProps
 * @description Props del componente QuickSummaryTrigger.
 */
interface QuickSummaryTriggerProps {
  /** Identificador interno del informe/relevamiento a mostrar */
  id: number
  /** Texto opcional del botón */
  label?: string
  /** Clase adicional para personalizar estilos */
  className?: string
}

/**
 * QuickSummaryTrigger
 * @description Componente que renderiza un botón pequeño que al pulsarlo monta el modal
 *              de resumen rápido mediante la función showQuickSummary(id).
 */
export default function QuickSummaryTrigger({
  id,
  label = 'Resumen',
  className = '',
}: QuickSummaryTriggerProps) {
  /**
   * handleClick
   * @description Invoca la función que monta el modal y lo muestra.
   */
  function handleClick() {
    showQuickSummary(id)
  }

  return (
    <button
      type="button"
      onClick={handleClick}
      className={`inline-flex items-center gap-2 rounded-md bg-sky-600 px-2 py-1 text-xs font-medium text-white hover:bg-sky-500 focus:outline-none focus:ring-2 focus:ring-sky-400 ${className}`}
      aria-label={`Resumen rápido del relevamiento ${id}`}
    >
      <FileText className="h-4 w-4" />
      <span>{label}</span>
    </button>
  )
}