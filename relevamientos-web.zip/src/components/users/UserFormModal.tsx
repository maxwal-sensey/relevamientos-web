/**
 * @file UserFormModal.tsx
 * @description Modal de formulario para alta/edición de usuarios en la vista demo de administración.
 */

import { useEffect, useState } from 'react'
import type { SystemUserRole } from '../../context/SystemUserContext'
import type { DemoUser } from '../../mock/demoUsers'

/**
 * UserFormMode
 * @description Modo de funcionamiento del formulario (alta o edición).
 */
export type UserFormMode = 'create' | 'edit'

/**
 * UserFormValues
 * @description Valores que se gestionan en el formulario de usuarios.
 */
export interface UserFormValues {
  legajo: string
  nombre: string
  apellido: string
  jerarquia: string
  rol: SystemUserRole
  dependenciaNombre: string
  telefono?: string
  email?: string
  isActive: boolean
}

/**
 * UserFormModalProps
 * @description Propiedades del modal de alta/edición de usuario.
 */
interface UserFormModalProps {
  /** Indica si el modal está visible. */
  open: boolean
  /** Modo del formulario: creación o edición. */
  mode: UserFormMode
  /** Usuario inicial para modo edición (opcional). */
  initialUser?: DemoUser
  /** Callback al cerrar el modal (sin enviar). */
  onClose: () => void
  /** Callback al enviar el formulario con datos válidos. */
  onSubmit: (values: UserFormValues) => void
}

/**
 * FormErrors
 * @description Estructura de errores de validación básica para el formulario.
 */
interface FormErrors {
  legajo?: string
  nombre?: string
  apellido?: string
  rol?: string
  dependenciaNombre?: string
}

/** Opciones de jerarquías de ejemplo (simulan datos de catálogos). */
const JERARQUIAS_OPTIONS: string[] = [
  'Crio. Mayor',
  'Crio.',
  'Crio. Insp.',
  'Of. Ppal.',
  'Sgto.',
  'Cb. 1°',
  'Cb.',
]

/** Opciones de dependencias de ejemplo (simulan datos de catálogos). */
const DEPENDENCIAS_OPTIONS: string[] = [
  'Dependencia central',
  'Comisaría 1ra. La Plata',
  'Comisaría 2da. La Plata',
]

/** Opciones de roles disponibles. */
const ROLES_OPTIONS: { value: SystemUserRole; label: string }[] = [
  { value: 'administrador', label: 'Administrador' },
  { value: 'secretario', label: 'Secretario' },
  { value: 'relevador', label: 'Relevador' },
]

/**
 * buildInitialValues
 * @description Construye los valores iniciales del formulario según el modo y usuario inicial.
 */
function buildInitialValues(
  mode: UserFormMode,
  user?: DemoUser | null
): UserFormValues {
  if (mode === 'edit' && user) {
    return {
      legajo: user.legajo,
      nombre: user.nombre,
      apellido: user.apellido,
      jerarquia: user.jerarquia,
      rol: user.rol,
      dependenciaNombre: user.dependenciaNombre,
      telefono: user.telefono ?? '',
      email: user.email ?? '',
      isActive: user.isActive,
    }
  }

  return {
    legajo: '',
    nombre: '',
    apellido: '',
    jerarquia: 'Of. Ppal.',
    rol: 'secretario',
    dependenciaNombre: 'Comisaría 1ra. La Plata',
    telefono: '',
    email: '',
    isActive: true,
  }
}

/**
 * UserFormModal
 * @description Modal con formulario controlado para crear o editar usuarios (sin persistencia real en esta demo).
 */
export function UserFormModal({
  open,
  mode,
  initialUser,
  onClose,
  onSubmit,
}: UserFormModalProps) {
  const [values, setValues] = useState<UserFormValues>(() =>
    buildInitialValues(mode, initialUser ?? null)
  )
  const [errors, setErrors] = useState<FormErrors>({})

  /**
   * @description Sincroniza valores iniciales cuando se abre el modal, cambia el modo o el usuario inicial.
   */
  useEffect(() => {
    if (open) {
      setValues(buildInitialValues(mode, initialUser ?? null))
      setErrors({})
    }
  }, [open, mode, initialUser])

  /**
   * handleChange
   * @description Actualiza un campo del formulario.
   */
  const handleChange = <K extends keyof UserFormValues>(
    field: K,
    value: UserFormValues[K]
  ) => {
    setValues((prev) => ({
      ...prev,
      [field]: value,
    }))
  }

  /**
   * validate
   * @description Valida campos mínimos requeridos y actualiza el estado de errores.
   */
  const validate = (): boolean => {
    const nextErrors: FormErrors = {}

    if (!values.legajo.trim()) {
      nextErrors.legajo = 'El número de legajo es obligatorio.'
    }
    if (!values.nombre.trim()) {
      nextErrors.nombre = 'El nombre es obligatorio.'
    }
    if (!values.apellido.trim()) {
      nextErrors.apellido = 'El apellido es obligatorio.'
    }
    if (!values.rol) {
      nextErrors.rol = 'El rol es obligatorio.'
    }
    if (!values.dependenciaNombre.trim()) {
      nextErrors.dependenciaNombre = 'La dependencia es obligatoria.'
    }

    setErrors(nextErrors)
    return Object.keys(nextErrors).length === 0
  }

  /**
   * handleSubmit
   * @description Gestiona el envío del formulario, valida y notifica al componente padre.
   */
  const handleSubmit = (event: React.FormEvent) => {
    event.preventDefault()
    if (!validate()) {
      return
    }
    onSubmit(values)
  }

  if (!open) {
    return null
  }

  return (
    <div className="fixed inset-0 z-40 flex items-center justify-center bg-slate-950/60 px-4 py-6">
      <div
        role="dialog"
        aria-modal="true"
        aria-label={
          mode === 'create' ? 'Crear nuevo usuario' : 'Editar usuario existente'
        }
        className="relative w-full max-w-lg rounded-xl border border-slate-700 bg-slate-950 text-slate-50 shadow-xl"
      >
        {/* Cabecera */}
        <header className="flex items-start justify-between border-b border-slate-800 px-5 py-3">
          <div>
            <h2 className="text-sm font-semibold text-slate-50">
              {mode === 'create' ? 'Nuevo usuario' : 'Editar usuario'}
            </h2>
            <p className="mt-0.5 text-xs text-slate-400">
              Este formulario es sólo de demostración: los datos no se guardan
              en la base de datos real.
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="inline-flex h-7 w-7 items-center justify-center rounded-full text-slate-400 hover:bg-slate-800 hover:text-slate-100"
          >
            <span className="text-sm leading-none">&times;</span>
            <span className="sr-only">Cerrar</span>
          </button>
        </header>

        {/* Contenido del formulario */}
        <form onSubmit={handleSubmit} className="px-5 py-4 space-y-4">
          <div className="grid gap-3 md:grid-cols-2">
            {/* Legajo */}
            <div className="md:col-span-1">
              <label className="mb-1 block text-xs font-medium text-slate-300">
                N° Legajo *
              </label>
              <input
                type="text"
                value={values.legajo}
                onChange={(e) => handleChange('legajo', e.target.value)}
                className="block w-full rounded-md border border-slate-700 bg-slate-900 px-2 py-1.5 text-xs text-slate-100 placeholder:text-slate-500 focus:border-sky-500 focus:outline-none focus:ring-1 focus:ring-sky-500"
                placeholder="Ej: 4000"
              />
              {errors.legajo && (
                <p className="mt-1 text-[11px] text-red-400">
                  {errors.legajo}
                </p>
              )}
            </div>

            {/* Jerarquía */}
            <div className="md:col-span-1">
              <label className="mb-1 block text-xs font-medium text-slate-300">
                Jerarquía
              </label>
              <select
                value={values.jerarquia}
                onChange={(e) => handleChange('jerarquia', e.target.value)}
                className="block w-full rounded-md border border-slate-700 bg-slate-900 px-2 py-1.5 text-xs text-slate-100 focus:border-sky-500 focus:outline-none focus:ring-1 focus:ring-sky-500"
              >
                {JERARQUIAS_OPTIONS.map((jerarquia) => (
                  <option key={jerarquia} value={jerarquia}>
                    {jerarquia}
                  </option>
                ))}
              </select>
            </div>

            {/* Nombre */}
            <div>
              <label className="mb-1 block text-xs font-medium text-slate-300">
                Nombre *
              </label>
              <input
                type="text"
                value={values.nombre}
                onChange={(e) => handleChange('nombre', e.target.value)}
                className="block w-full rounded-md border border-slate-700 bg-slate-900 px-2 py-1.5 text-xs text-slate-100 placeholder:text-slate-500 focus:border-sky-500 focus:outline-none focus:ring-1 focus:ring-sky-500"
                placeholder="Nombre"
              />
              {errors.nombre && (
                <p className="mt-1 text-[11px] text-red-400">
                  {errors.nombre}
                </p>
              )}
            </div>

            {/* Apellido */}
            <div>
              <label className="mb-1 block text-xs font-medium text-slate-300">
                Apellido *
              </label>
              <input
                type="text"
                value={values.apellido}
                onChange={(e) => handleChange('apellido', e.target.value)}
                className="block w-full rounded-md border border-slate-700 bg-slate-900 px-2 py-1.5 text-xs text-slate-100 placeholder:text-slate-500 focus:border-sky-500 focus:outline-none focus:ring-1 focus:ring-sky-500"
                placeholder="Apellido"
              />
              {errors.apellido && (
                <p className="mt-1 text-[11px] text-red-400">
                  {errors.apellido}
                </p>
              )}
            </div>

            {/* Rol */}
            <div>
              <label className="mb-1 block text-xs font-medium text-slate-300">
                Tipo de usuario / Rol *
              </label>
              <select
                value={values.rol}
                onChange={(e) =>
                  handleChange('rol', e.target.value as SystemUserRole)
                }
                className="block w-full rounded-md border border-slate-700 bg-slate-900 px-2 py-1.5 text-xs text-slate-100 focus:border-sky-500 focus:outline-none focus:ring-1 focus:ring-sky-500"
              >
                {ROLES_OPTIONS.map((rolOption) => (
                  <option key={rolOption.value} value={rolOption.value}>
                    {rolOption.label}
                  </option>
                ))}
              </select>
              {errors.rol && (
                <p className="mt-1 text-[11px] text-red-400">{errors.rol}</p>
              )}
            </div>

            {/* Dependencia */}
            <div>
              <label className="mb-1 block text-xs font-medium text-slate-300">
                Dependencia *
              </label>
              <select
                value={values.dependenciaNombre}
                onChange={(e) =>
                  handleChange('dependenciaNombre', e.target.value)
                }
                className="block w-full rounded-md border border-slate-700 bg-slate-900 px-2 py-1.5 text-xs text-slate-100 focus:border-sky-500 focus:outline-none focus:ring-1 focus:ring-sky-500"
              >
                <option value="">Seleccionar dependencia...</option>
                {DEPENDENCIAS_OPTIONS.map((dep) => (
                  <option key={dep} value={dep}>
                    {dep}
                  </option>
                ))}
              </select>
              {errors.dependenciaNombre && (
                <p className="mt-1 text-[11px] text-red-400">
                  {errors.dependenciaNombre}
                </p>
              )}
            </div>

            {/* Teléfono */}
            <div>
              <label className="mb-1 block text-xs font-medium text-slate-300">
                Teléfono de contacto
              </label>
              <input
                type="text"
                value={values.telefono ?? ''}
                onChange={(e) => handleChange('telefono', e.target.value)}
                className="block w-full rounded-md border border-slate-700 bg-slate-900 px-2 py-1.5 text-xs text-slate-100 placeholder:text-slate-500 focus:border-sky-500 focus:outline-none focus:ring-1 focus:ring-sky-500"
                placeholder="Ej: 221-000-0000"
              />
            </div>

            {/* Email */}
            <div>
              <label className="mb-1 block text-xs font-medium text-slate-300">
                Email
              </label>
              <input
                type="email"
                value={values.email ?? ''}
                onChange={(e) => handleChange('email', e.target.value)}
                className="block w-full rounded-md border border-slate-700 bg-slate-900 px-2 py-1.5 text-xs text-slate-100 placeholder:text-slate-500 focus:border-sky-500 focus:outline-none focus:ring-1 focus:ring-sky-500"
                placeholder="usuario@sgr.test"
              />
            </div>

            {/* Estado */}
            <div className="md:col-span-2">
              <label className="inline-flex items-center gap-2 text-xs text-slate-200">
                <input
                  type="checkbox"
                  checked={values.isActive}
                  onChange={(e) => handleChange('isActive', e.target.checked)}
                  className="h-3.5 w-3.5 rounded border-slate-600 bg-slate-900 text-sky-500 focus:ring-sky-500"
                />
                <span>Usuario activo</span>
              </label>
              <p className="mt-1 text-[11px] text-slate-500">
                En la versión completa, los usuarios inactivos no podrán iniciar
                sesión ni recibir notificaciones.
              </p>
            </div>
          </div>

          {/* Pie del formulario */}
          <div className="mt-2 flex flex-col gap-2 border-t border-slate-800 pt-3 text-[11px] text-slate-400">
            <p>
              Al guardar, en la versión conectada al backend se crearán o
              actualizarán los registros en la base de datos D1. En esta demo
              solo se muestra la experiencia de usuario.
            </p>
            <div className="flex items-center justify-end gap-2 pt-1">
              <button
                type="button"
                onClick={onClose}
                className="inline-flex items-center justify-center rounded-md border border-slate-700 px-3 py-1.5 text-xs font-medium text-slate-100 hover:bg-slate-800"
              >
                Cancelar
              </button>
              <button
                type="submit"
                className="inline-flex items-center justify-center rounded-md bg-sky-600 px-3 py-1.5 text-xs font-semibold text-white shadow-sm hover:bg-sky-700"
              >
                {mode === 'create' ? 'Crear usuario' : 'Guardar cambios'}
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  )
}
