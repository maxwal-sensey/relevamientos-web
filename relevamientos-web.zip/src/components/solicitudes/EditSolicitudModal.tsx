/**
 * @file EditSolicitudModal.tsx
 * @description Modal para editar una solicitud; validación de formulario con Zod y
 *              persistencia en el mock-store. Muestra toasts de resultado.
 */

import React, { FormEvent, useState } from 'react'
import { X } from 'lucide-react'
import { Solicitud as SolicitudTipo, updateSolicitud } from '../../mock/solicitudesStore'
import { toast } from 'sonner'
import { z } from 'zod'

/**
 * EditSolicitudModalProps
 * @description Props del componente modal de edición.
 */
interface EditSolicitudModalProps {
  solicitud: SolicitudTipo
  onClose: () => void
  onSaved?: (updated: SolicitudTipo) => void
}

/**
 * EditSolicitudSchema
 * @description Esquema Zod que valida los campos editables de la solicitud.
 */
const EditSolicitudSchema = z.object({
  fiscalia: z.string().min(3, 'La fiscalía debe tener al menos 3 caracteres.').nonempty('La fiscalía es obligatoria.'),
  lugar: z.string().min(5, 'La dirección debe ser más descriptiva.').nonempty('El lugar es obligatorio.'),
  caratula: z.string().min(5, 'La carátula debe tener al menos 5 caracteres.').nonempty('La carátula es obligatoria.'),
  estado: z.union([z.literal('pendiente'), z.literal('finalizada')]),
  hasAdjuntos: z.boolean(),
})

/**
 * FieldErrors
 * @description Tipo para errores por campo (mensajes de validación).
 */
type FieldErrors = Partial<Record<keyof z.infer<typeof EditSolicitudSchema>, string>>

/**
 * validateWithZod
 * @description Valida un objeto parcial usando el esquema Zod y devuelve errores por campo.
 * @param values Objeto con valores a validar
 * @returns FieldErrors
 */
function validateWithZod(values: Partial<z.infer<typeof EditSolicitudSchema>>): FieldErrors {
  const result = EditSolicitudSchema.safeParse(values)
  if (result.success) return {}
  const formatted: FieldErrors = {}
  for (const issue of result.error.issues) {
    const key = issue.path[0] as keyof FieldErrors
    // Sólo guardar el primer mensaje por campo
    if (!formatted[key]) formatted[key] = issue.message
  }
  return formatted
}

/**
 * EditSolicitudModal
 * @description Modal que permite editar campos básicos de una solicitud
 *              y persiste la modificación en el mock-store usando Zod para validación.
 */
export default function EditSolicitudModal({ solicitud, onClose, onSaved }: EditSolicitudModalProps) {
  const [fiscalia, setFiscalia] = useState(solicitud.fiscalia)
  const [lugar, setLugar] = useState(solicitud.lugar)
  const [caratula, setCaratula] = useState(solicitud.caratula)
  const [estado, setEstado] = useState<SolicitudTipo['estado']>(solicitud.estado)
  const [hasAdjuntos, setHasAdjuntos] = useState(solicitud.hasAdjuntos)
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [fieldErrors, setFieldErrors] = useState<FieldErrors>({})

  /**
   * handleFieldBlur
   * @description Valida únicamente el campo indicado al perder foco y actualiza errores.
   * @param name Nombre del campo
   * @param value Valor actual
   */
  const handleFieldBlur = (name: keyof FieldErrors, value: any) => {
    const errs = validateWithZod({ fiscalia, lugar, caratula, estado, hasAdjuntos, [name]: value })
    setFieldErrors((prev) => ({ ...prev, [name]: errs[name] }))
  }

  /**
   * handleSubmit
   * @description Valida todo el formulario con Zod y envía la actualización al mock-store.
   */
  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault()
    setError(null)

    const values = { fiscalia: fiscalia.trim(), lugar: lugar.trim(), caratula: caratula.trim(), estado, hasAdjuntos }

    const parseResult = EditSolicitudSchema.safeParse(values)
    if (!parseResult.success) {
      // Mapear errores a campo
      const mapped: FieldErrors = {}
      for (const issue of parseResult.error.issues) {
        const key = issue.path[0] as keyof FieldErrors
        if (!mapped[key]) mapped[key] = issue.message
      }
      setFieldErrors(mapped)
      toast.error('Corrija los campos marcados antes de guardar.')
      return
    }

    setSaving(true)
    try {
      const updated = await updateSolicitud(solicitud.id, {
        fiscalia: values.fiscalia,
        lugar: values.lugar,
        caratula: values.caratula,
        estado: values.estado,
        hasAdjuntos: values.hasAdjuntos,
      })
      if (updated) {
        if (onSaved) {
          onSaved(updated)
        }
        toast.success('Solicitud actualizada correctamente.')
      } else {
        toast.error('No se encontró la solicitud para actualizar.')
      }
      onClose()
    } catch (err) {
      setError('Error al guardar. Intente nuevamente.')
      toast.error('Error al guardar los cambios.')
    } finally {
      setSaving(false)
    }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      <div className="absolute inset-0 bg-black/50" onClick={onClose} />
      <form onSubmit={handleSubmit} className="relative z-10 w-full max-w-xl rounded-lg border border-slate-800 bg-slate-900 p-4 shadow-lg" noValidate>
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-semibold text-slate-100">Editar solicitud</h3>
          <button type="button" onClick={onClose} className="rounded-md p-1 text-slate-300 hover:bg-slate-800" aria-label="Cerrar">
            <X className="h-4 w-4" />
          </button>
        </div>

        {error && <div className="mt-3 rounded-md border border-red-500/60 bg-red-950/60 px-3 py-2 text-xs text-red-100">{error}</div>}

        <div className="mt-3 grid gap-3">
          <div>
            <label className="mb-1 block text-xs font-medium text-slate-300">Fiscalía *</label>
            <input
              value={fiscalia}
              onChange={(e) => setFiscalia(e.target.value)}
              onBlur={() => handleFieldBlur('fiscalia', fiscalia)}
              aria-invalid={!!fieldErrors.fiscalia}
              aria-describedby={fieldErrors.fiscalia ? 'err-fiscalia' : undefined}
              className={`block w-full rounded-md border px-3 py-1.5 text-xs text-slate-100 ${fieldErrors.fiscalia ? 'border-red-500 bg-red-950/20' : 'border-slate-700 bg-slate-950'}`}
            />
            {fieldErrors.fiscalia && <p id="err-fiscalia" className="mt-1 text-[11px] text-red-300">{fieldErrors.fiscalia}</p>}
          </div>

          <div>
            <label className="mb-1 block text-xs font-medium text-slate-300">Lugar *</label>
            <input
              value={lugar}
              onChange={(e) => setLugar(e.target.value)}
              onBlur={() => handleFieldBlur('lugar', lugar)}
              aria-invalid={!!fieldErrors.lugar}
              aria-describedby={fieldErrors.lugar ? 'err-lugar' : undefined}
              className={`block w-full rounded-md border px-3 py-1.5 text-xs text-slate-100 ${fieldErrors.lugar ? 'border-red-500 bg-red-950/20' : 'border-slate-700 bg-slate-950'}`}
            />
            {fieldErrors.lugar && <p id="err-lugar" className="mt-1 text-[11px] text-red-300">{fieldErrors.lugar}</p>}
          </div>

          <div>
            <label className="mb-1 block text-xs font-medium text-slate-300">Carátula *</label>
            <input
              value={caratula}
              onChange={(e) => setCaratula(e.target.value)}
              onBlur={() => handleFieldBlur('caratula', caratula)}
              aria-invalid={!!fieldErrors.caratula}
              aria-describedby={fieldErrors.caratula ? 'err-caratula' : undefined}
              className={`block w-full rounded-md border px-3 py-1.5 text-xs text-slate-100 ${fieldErrors.caratula ? 'border-red-500 bg-red-950/20' : 'border-slate-700 bg-slate-950'}`}
            />
            {fieldErrors.caratula && <p id="err-caratula" className="mt-1 text-[11px] text-red-300">{fieldErrors.caratula}</p>}
          </div>

          <div className="flex items-center gap-3">
            <div>
              <label className="mb-1 block text-xs font-medium text-slate-300">Estado</label>
              <select value={estado} onChange={(e) => setEstado(e.target.value as any)} className="rounded-md border border-slate-700 bg-slate-950 px-2 py-1 text-xs text-slate-100">
                <option value="pendiente">Pendiente</option>
                <option value="finalizada">Finalizada</option>
              </select>
            </div>

            <label className="ml-auto flex items-center gap-2 text-xs text-slate-300">
              <input type="checkbox" checked={hasAdjuntos} onChange={(e) => setHasAdjuntos(e.target.checked)} />
              Tiene adjuntos
            </label>
          </div>
        </div>

        <div className="mt-4 flex justify-end gap-2">
          <button type="button" onClick={onClose} className="rounded-md border border-slate-700 px-3 py-1.5 text-xs text-slate-200 hover:bg-slate-800">Cancelar</button>
          <button type="submit" disabled={saving} className="rounded-md bg-sky-600 px-4 py-1.5 text-xs font-semibold text-white hover:bg-sky-700 disabled:opacity-60">
            {saving ? 'Guardando…' : 'Guardar'}
          </button>
        </div>
      </form>
    </div>
  )
}