/**
 * @file Charts.tsx
 * @description Conjunto de gráficos para la vista de estadísticas (pie, línea y barras) usando Recharts.
 */

import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Legend,
  Line,
  LineChart,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts'

/**
 * StatusDatum
 * @description Tipo para la distribución de estados (pie).
 */
interface StatusDatum {
  name: string
  value: number
}

/**
 * MonthlyDatum
 * @description Tipo para la serie de evolución mensual (línea).
 */
interface MonthlyDatum {
  month: string
  value: number
}

/**
 * TopDatum
 * @description Tipo para el ranking (barras).
 */
interface TopDatum {
  name: string
  value: number
}

/**
 * ChartsProps
 * @description Props que recibe el componente Charts.
 */
interface ChartsProps {
  statusData: StatusDatum[]
  monthlyData: MonthlyDatum[]
  topData: TopDatum[]
}

/**
 * Charts
 * @description Renderiza tres gráficos responsivos: pie (estados), línea (evolución) y barras (ranking).
 */
export default function Charts({ statusData, monthlyData, topData }: ChartsProps) {
  const COLORS = ['#06b6d4', '#60a5fa', '#f59e0b', '#7c3aed', '#ef4444']

  return (
    <div className="grid gap-4 md:grid-cols-3">
      <div className="col-span-1 rounded-xl border border-slate-800 bg-slate-900/60 p-3">
        <h3 className="mb-2 text-sm font-semibold text-slate-100">Distribución por estado</h3>
        <div style={{ height: 220 }}>
          <ResponsiveContainer>
            <PieChart>
              <Pie data={statusData} dataKey="value" nameKey="name" innerRadius={40} outerRadius={70} paddingAngle={4}>
                {statusData.map((_, idx) => (
                  <Cell key={idx} fill={COLORS[idx % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip />
              <Legend wrapperStyle={{ color: '#94a3b8', fontSize: 12 }} />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="col-span-1 rounded-xl border border-slate-800 bg-slate-900/60 p-3">
        <h3 className="mb-2 text-sm font-semibold text-slate-100">Evolución (últimos 6 meses)</h3>
        <div style={{ height: 220 }}>
          <ResponsiveContainer>
            <LineChart data={monthlyData} margin={{ left: 0, right: 10 }}>
              <CartesianGrid stroke="#0f1724" strokeDasharray="3 3" />
              <XAxis dataKey="month" tick={{ fill: '#94a3b8', fontSize: 12 }} />
              <YAxis tick={{ fill: '#94a3b8', fontSize: 12 }} />
              <Tooltip />
              <Line type="monotone" dataKey="value" stroke="#60a5fa" strokeWidth={3} dot={{ r: 3 }} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="col-span-1 rounded-xl border border-slate-800 bg-slate-900/60 p-3">
        <h3 className="mb-2 text-sm font-semibold text-slate-100">Top relevadores (30 días)</h3>
        <div style={{ height: 220 }}>
          <ResponsiveContainer>
            <BarChart data={topData} layout="vertical" margin={{ top: 5, right: 10, left: 10, bottom: 5 }}>
              <CartesianGrid stroke="#0f1724" strokeDasharray="3 3" />
              <XAxis type="number" tick={{ fill: '#94a3b8', fontSize: 12 }} />
              <YAxis type="category" dataKey="name" tick={{ fill: '#94a3b8', fontSize: 12 }} width={120} />
              <Tooltip />
              <Bar dataKey="value" fill="#34d399">
                {topData.map((_, idx) => (
                  <Cell key={idx} fill={COLORS[idx % COLORS.length]} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  )
}