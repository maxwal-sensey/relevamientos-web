/**
 * @file SolicitudAutocomplete.tsx
 * @description Combobox single-select para elegir una solicitud pendiente (filtrado por dependencia).
 */

import { useEffect, useMemo, useRef, useState } from 'react'
import { fetchSolicitudes, type Solicitud } from '../../mock/solicitudesStore'
import { useSystemUser } from '../../context/SystemUserContext'

/**
 * SolicitudAutocompleteProps
 * @description Props para el combobox de solicitudes.
 */
interface SolicitudAutocompleteProps {
  /** Id seleccionado (string) o null */
  selectedId: string | null
  /** Callback al cambiar selección */
  onChange: (id: string | null) => void
  /** Placeholder del input */
  placeholder?: string
}

/**
 * SolicitudAutocomplete
 * @description Combobox con búsqueda por IPP / número de registro para seleccionar una solicitud pendiente.
 */
export default function SolicitudAutocomplete({
  selectedId,
  onChange,
  placeholder = 'Buscar por número de IPP...',
}: SolicitudAutocompleteProps) {
  const { currentUser } = useSystemUser()
  const [items, setItems] = useState<Solicitud[]>([])
  const [query, setQuery] = useState('')
  const [isOpen, setIsOpen] = useState(false)
  const [highlightIndex, setHighlightIndex] = useState(0)
  const containerRef = useRef<HTMLDivElement | null>(null)
  const inputRef = useRef<HTMLInputElement | null>(null)

  useEffect(() => {
    let mounted = true
    fetchSolicitudes().then((list) => {
      if (!mounted) return
      // filtrar solo pendientes y por dependencia (salvo admin)
      const filtered = list.filter((s) => s.estado === 'pendiente')
      const byDependencia = currentUser && currentUser.rol !== 'administrador'
        ? filtered.filter((s) => s.dependenciaId === currentUser.dependenciaId)
        : filtered
      // ordenar por fecha descendente
      byDependencia.sort((a, b) => +new Date(b.fecha) - +new Date(a.fecha))
      setItems(byDependencia)
    })
    return () => { mounted = false }
  }, [currentUser])

  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setIsOpen(false)
      }
    }
    document.addEventListener('click', handleClickOutside)
    return () => document.removeEventListener('click', handleClickOutside)
  }, [])

  useEffect(() => {
    setHighlightIndex(0)
  }, [query, isOpen])

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase()
    if (!q) return items
    return items.filter((s) => {
      return (
        s.ipp.toLowerCase().includes(q) ||
        s.numeroRegistro.toLowerCase().includes(q) ||
        (s.caratula && s.caratula.toLowerCase().includes(q))
      )
    })
  }, [items, query])

  /**
   * selectId
   * @description Selecciona o deselecciona una solicitud.
   */
  function selectId(id: string | null) {
    onChange(id)
    setQuery('')
    setIsOpen(false)
    inputRef.current?.blur()
  }

  /**
   * handleKeyDown
   * @description Navegación por teclado.
   */
  function handleKeyDown(e: React.KeyboardEvent<HTMLInputElement>) {
    if (e.key === 'ArrowDown') {
      e.preventDefault()
      setIsOpen(true)
      setHighlightIndex((i) => Math.min(i + 1, filtered.length - 1))
      return
    }
    if (e.key === 'ArrowUp') {
      e.preventDefault()
      setHighlightIndex((i) => Math.max(i - 1, 0))
      return
    }
    if (e.key === 'Enter') {
      e.preventDefault()
      const item = filtered[highlightIndex]
      if (item) selectId(String(item.id))
      return
    }
    if (e.key === 'Escape') {
      setIsOpen(false)
      return
    }
  }

  const selectedItem = items.find((i) => String(i.id) === String(selectedId))

  return (
    <div ref={containerRef} className="relative">
      <div
        className="flex items-center gap-2 rounded-md border border-slate-700 bg-slate-800 px-2 py-1"
        onClick={() => {
          setIsOpen(true)
          inputRef.current?.focus()
        }}
      >
        {selectedItem ? (
          <div className="flex items-center gap-2">
            <div className="text-xs text-slate-100">{selectedItem.numeroRegistro}</div>
            <button
              type="button"
              className="text-xs text-slate-300 hover:text-white"
              onClick={(e) => {
                e.stopPropagation()
                selectId(null)
              }}
              aria-label="Quitar solicitud seleccionada"
            >
              ✕
            </button>
          </div>
        ) : (
          <input
            ref={inputRef}
            value={query}
            onChange={(e) => {
              setQuery(e.target.value)
              setIsOpen(true)
            }}
            onKeyDown={handleKeyDown}
            placeholder={placeholder}
            className="min-w-[160px] flex-1 bg-transparent text-sm text-slate-100 placeholder:text-slate-400 focus:outline-none"
          />
        )}
      </div>

      {isOpen && (
        <div className="absolute z-50 mt-1 w-full max-h-56 overflow-auto rounded-md bg-slate-900/95 p-1 shadow-lg">
          {filtered.length === 0 ? (
            <div className="p-2 text-sm text-slate-400">No se encontraron solicitudes pendientes.</div>
          ) : (
            <ul>
              {filtered.map((s, idx) => {
                const isHighlighted = idx === highlightIndex
                return (
                  <li
                    key={s.id}
                    onMouseDown={(e) => { e.preventDefault(); selectId(String(s.id)) }}
                    onMouseEnter={() => setHighlightIndex(idx)}
                    className={`cursor-pointer rounded-md px-2 py-2 text-sm ${isHighlighted ? 'bg-slate-800' : ''}`}
                  >
                    <div className="flex items-center justify-between gap-3">
                      <div className="text-sm text-slate-100">{s.numeroRegistro}</div>
                      <div className="text-xs text-slate-400">{s.ipp}</div>
                    </div>
                    <div className="mt-1 text-xs text-slate-400">{s.caratula}</div>
                  </li>
                )
              })}
            </ul>
          )}
        </div>
      )}
    </div>
  )
}