/**
 * @file NotificationsList.tsx
 * @description Componente que muestra la lista de notificaciones (modo demo)
 *              y permite componer un nuevo mensaje usando ComposeModal.
 */

import { useMemo, useState } from 'react'
import ComposeModal from './ComposeModal'
import { useSystemUser } from '../../context/SystemUserContext'

/**
 * NotificationsListProps
 * @description Props del componente NotificationsList.
 */
interface NotificationsListProps {
  /** Nombre legible del usuario actual para mostrar como remitente en el modal */
  currentUserName: string
}

/**
 * NotificationsList
 * @description Lista simple de mensajes demo y botón para abrir modal de composición.
 */
export default function NotificationsList({ currentUserName }: NotificationsListProps) {
  const { currentUser } = useSystemUser()
  const [openCompose, setOpenCompose] = useState(false)

  /**
   * handleSend
   * @description Recibe los datos enviados desde ComposeModal. En modo demo
   *              muestra una notificación simple y cierra el modal.
   * @param to destinatario legible
   * @param subject asunto
   * @param body contenido
   */
  function handleSend(to: string, subject: string, body: string) {
    // En un escenario real aquí se llamaría al store/API para persistir el mensaje.
    // En demo solo mostramos un feedback.
    // eslint-disable-next-line no-alert
    alert(`Mensaje enviado a: ${to}\nAsunto: ${subject}\n\n${body}`)
  }

  const canCompose = useMemo(() => !!currentUser, [currentUser])

  if (!currentUser) {
    return (
      <div className="rounded-md border border-amber-400 bg-amber-50/5 p-4 text-sm text-amber-200">
        Acceso no autorizado. Iniciar sesión para ver notificaciones y enviar mensajes.
      </div>
    )
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-sm font-semibold text-slate-100">Bandeja de Mensajes</h2>

        <div>
          <button
            onClick={() => setOpenCompose(true)}
            disabled={!canCompose}
            className="rounded-md bg-sky-600 px-3 py-1 text-xs font-semibold text-white hover:bg-sky-700 disabled:opacity-50"
          >
            Nuevo Mensaje
          </button>
        </div>
      </div>

      <div className="rounded-md border border-slate-700 bg-slate-900 p-4 text-sm text-slate-200">
        <p className="text-xs text-slate-400">Lista de mensajes (demo)</p>
        <ul className="mt-3 space-y-2">
          <li className="rounded-sm border border-slate-800 bg-slate-800/30 p-2">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-xs font-medium">Asunto de ejemplo</div>
                <div className="text-xs text-slate-400">Remitente: Secretaría</div>
              </div>
              <div className="text-xs text-slate-400">hace 2h</div>
            </div>
          </li>
          <li className="rounded-sm border border-slate-800 bg-slate-800/30 p-2">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-xs font-medium">Mensaje de prueba</div>
                <div className="text-xs text-slate-400">Remitente: Relevador</div>
              </div>
              <div className="text-xs text-slate-400">hace 1d</div>
            </div>
          </li>
        </ul>
      </div>

      <ComposeModal
        open={openCompose}
        remitente={currentUserName}
        onClose={() => setOpenCompose(false)}
        onSend={handleSend}
      />
    </div>
  )
}