/**
 * @file ComposeModal.tsx
 * @description Modal para componer y enviar mensajes (modo demo) con selección de destinatarios,
 *              adjuntos (límite por archivo y total) y posibilidad de relacionar el mensaje con una solicitud pendiente.
 */

import { useEffect, useMemo, useRef, useState } from 'react'
import { DEMO_USERS, type DemoUser } from '../../mock/demoUsers'
import { useSystemUser } from '../../context/SystemUserContext'
import RecipientAutocomplete from './RecipientAutocomplete'
import SolicitudAutocomplete from './SolicitudAutocomplete'
import { Paperclip, X as XIcon } from 'lucide-react'
import { sendMessage as mockSendMessage } from '../../lib/mockApi'

/**
 * ComposeModalProps
 * @description Propiedades del modal de composición.
 */
interface ComposeModalProps {
  /** Indica si el modal está abierto */
  open: boolean
  /** Nombre (legible) del remitente (para prellenar) */
  remitente: string
  /** Valor inicial del destinatario (opcional, formato libre, puede ser legajo o nombre o coma-separado) */
  initialTo?: string
  /** Callback de cierre */
  onClose: () => void
  /**
   * Callback al enviar
   * @param to destinatario(s) (nombre legible o lista separada por comas)
   * @param subject asunto
   * @param body contenido
   */
  onSend: (to: string, subject: string, body: string) => void
}

/**
 * AttachmentItem
 * @description Representa un archivo adjunto en memoria (modo demo).
 */
interface AttachmentItem {
  id: string
  file: File
}

/**
 * MAX_FILE_SIZE_BYTES
 * @description Límite por archivo (100 MB).
 */
const MAX_FILE_SIZE_BYTES = 100 * 1024 * 1024

/**
 * MAX_TOTAL_SIZE_BYTES
 * @description Límite global por mensaje (200 MB).
 */
const MAX_TOTAL_SIZE_BYTES = 200 * 1024 * 1024

/**
 * formatBytes
 * @description Formatea bytes a MB con 2 decimales.
 */
function formatBytes(bytes: number) {
  return `${(bytes / 1024 / 1024).toFixed(2)} MB`
}

/**
 * ComposeModal
 * @description Componente modal controlado para enviar mensajes en demo.
 *              Usa RecipientAutocomplete para búsqueda y selección múltiple, SolicitudAutocomplete
 *              para relacionar con una solicitud pendiente y mockApi para persistencia simulada.
 */
export default function ComposeModal({
  open,
  remitente,
  initialTo,
  onClose,
  onSend,
}: ComposeModalProps) {
  const { currentUser } = useSystemUser()
  const [selectedUserIds, setSelectedUserIds] = useState<string[]>([])
  const [subject, setSubject] = useState('')
  const [body, setBody] = useState('')

  /* Adjuntos en memoria (demo) */
  const [attachments, setAttachments] = useState<AttachmentItem[]>([])
  const fileInputRef = useRef<HTMLInputElement | null>(null)
  const [isSending, setIsSending] = useState(false)

  /** Solicitud relacionada (id string) */
  const [selectedSolicitudId, setSelectedSolicitudId] = useState<string | null>(null)

  /**
   * formatDisplayName
   * @description Devuelve la representación legible de un usuario demo.
   * @param user DemoUser
   */
  function formatDisplayName(user: DemoUser) {
    return `${user.apellido}, ${user.nombre} (${user.legajo})`
  }

  /**
   * recipients
   * @description Lista de usuarios que pueden ser destinatarios.
   *              - Si el usuario actual es administrador, puede ver a todos.
   *              - Si no, sólo usuarios con la misma dependencia (dependenciaId).
   */
  const recipients = useMemo(() => {
    if (!currentUser) return []
    if (currentUser.rol === 'administrador') {
      return DEMO_USERS.filter((u) => u.isActive)
    }
    // Filtrado por dependencia: usuarios activos con misma dependencia
    return DEMO_USERS.filter(
      (u) => u.isActive && u.dependenciaId === currentUser.dependenciaId
    )
  }, [currentUser])

  /**
   * initializeSelectedFromInitialTo
   * @description Intenta preseleccionar destinatarios a partir de initialTo.
   *              initialTo puede ser legajo, nombre legible o lista coma-separada.
   */
  useEffect(() => {
    if (!initialTo) {
      setSelectedUserIds([])
      return
    }
    const parts = initialTo
      .split(',')
      .map((p) => p.trim())
      .filter(Boolean)

    const matches = parts
      .map((part) =>
        recipients.find(
          (u) =>
            u.legajo === part ||
            formatDisplayName(u).toLowerCase() === part.toLowerCase() ||
            `${u.nombre} ${u.apellido}`.toLowerCase() === part.toLowerCase()
        )
      )
      .filter(Boolean) as DemoUser[]

    setSelectedUserIds(matches.map((m) => String(m.id)))
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [initialTo, recipients])

  /**
   * totalAttachmentsSize
   * @description Tamaño total en bytes de los adjuntos actuales.
   */
  const totalAttachmentsSize = attachments.reduce((s, a) => s + a.file.size, 0)

  /**
   * handleFileSelect
   * @description Maneja la selección de archivos desde el input.
   *              Valida tamaño por archivo (<= 100MB), evita duplicados por name+size
   *              y evita superar el límite total por mensaje.
   */
  function handleFileSelect(e: React.ChangeEvent<HTMLInputElement>) {
    const files = e.target.files
    if (!files || files.length === 0) return

    const next: AttachmentItem[] = []
    let nextTotal = totalAttachmentsSize

    for (let i = 0; i < files.length; i++) {
      const f = files.item(i)!
      if (f.size > MAX_FILE_SIZE_BYTES) {
        window.alert(`El archivo "${f.name}" supera el límite de 100 MB y fue omitido.`)
        continue
      }
      const exists = attachments.some((a) => a.file.name === f.name && a.file.size === f.size) ||
                     next.some((a) => a.file.name === f.name && a.file.size === f.size)
      if (exists) continue

      if (nextTotal + f.size > MAX_TOTAL_SIZE_BYTES) {
        window.alert(
          `No se puede adjuntar "${f.name}" porque excedería el límite total de ${formatBytes(
            MAX_TOTAL_SIZE_BYTES
          )}.`
        )
        continue
      }

      next.push({
        id: `${Date.now()}-${i}`,
        file: f,
      })
      nextTotal += f.size
    }

    if (next.length > 0) {
      setAttachments((prev) => [...prev, ...next])
    }

    // resetear input para permitir seleccionar mismo archivo nuevamente si se elimina
    if (fileInputRef.current) {
      fileInputRef.current.value = ''
    }
  }

  /**
   * removeAttachment
   * @description Elimina un adjunto por id.
   */
  function removeAttachment(id: string) {
    setAttachments((prev) => prev.filter((a) => a.id !== id))
  }

  /**
   * handleSubmit
   * @description Maneja el envío del formulario llamando a onSend con el nombre legible del destinatario(s).
   *              Integra persistencia simulada con mockApi (localStorage). En un backend real habría upload a R2 y guardado en DB.
   */
  async function handleSubmit(e?: React.FormEvent) {
    e?.preventDefault()
    if (isSending) return
    if (selectedUserIds.length === 0) {
      window.alert('Seleccionar al menos un destinatario (demo).')
      return
    }
    if (!subject.trim() || !body.trim()) {
      window.alert('Completar asunto y mensaje (demo).')
      return
    }
    if (totalAttachmentsSize > MAX_TOTAL_SIZE_BYTES) {
      window.alert(`El total de adjuntos excede el máximo de ${formatBytes(MAX_TOTAL_SIZE_BYTES)}.`)
      return
    }

    const selected = selectedUserIds
      .map((id) => recipients.find((r) => String(r.id) === id))
      .filter(Boolean) as DemoUser[]

    const toName =
      selected.length > 0 ? selected.map((s) => formatDisplayName(s)).join(', ') : selectedUserIds.join(',')

    setIsSending(true)
    try {
      // Persistir mediante mock API (simula subida y guarda metadatos), incluyendo solicitudId si existe
      await mockSendMessage({
        from: remitente,
        to: toName,
        subject: subject.trim(),
        body: body.trim(),
        attachments: attachments.map((a) => ({
          name: a.file.name,
          size: a.file.size,
          type: a.file.type || 'application/octet-stream',
        })),
        solicitudId: selectedSolicitudId,
      })

      // Añadimos una nota en el body para indicar adjuntos en demo (no persistente del file)
      if (attachments.length > 0) {
        const bodyWithAttachNote = `${body}\n\n[Adjuntos demo: ${attachments.map((a) => a.file.name).join(', ')}]`
        onSend(toName, subject.trim(), bodyWithAttachNote.trim())
      } else {
        onSend(toName, subject.trim(), body.trim())
      }

      // limpiar estado
      setSubject('')
      setBody('')
      setSelectedUserIds([])
      setAttachments([])
      setSelectedSolicitudId(null)
      onClose()
      // feedback
      // eslint-disable-next-line no-alert
      alert('Mensaje enviado (persistido localmente en modo demo).')
    } catch (err) {
      console.error('[ComposeModal] error sending message (mock):', err)
      // eslint-disable-next-line no-alert
      alert('Error enviando el mensaje (mock). Revisa la consola.')
    } finally {
      setIsSending(false)
    }
  }

  useEffect(() => {
    // Logs de depuración para ayudar a diagnosticar filtros/selección
    console.log('[ComposeModal] currentUser:', currentUser)
    console.log('[ComposeModal] recipients:', recipients)
    console.log('[ComposeModal] selectedUserIds:', selectedUserIds)
    console.log('[ComposeModal] attachments count:', attachments.length)
    console.log('[ComposeModal] selectedSolicitudId:', selectedSolicitudId)
  }, [currentUser, recipients, selectedUserIds, attachments, selectedSolicitudId])

  if (!open) return null

  const totalExceeded = totalAttachmentsSize > MAX_TOTAL_SIZE_BYTES
  const totalPercent = Math.min(100, Math.round((totalAttachmentsSize / MAX_TOTAL_SIZE_BYTES) * 100))

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      <div
        className="absolute inset-0 bg-black/50"
        onClick={onClose}
        aria-hidden
      />
      <form
        onSubmit={handleSubmit}
        className="relative z-10 w-full max-w-xl rounded-lg bg-slate-900 p-4 shadow-lg"
      >
        <header className="mb-3 flex items-center justify-between">
          <h3 className="text-sm font-semibold text-slate-50">Nuevo mensaje</h3>
          <button
            type="button"
            onClick={onClose}
            className="text-xs text-slate-400 hover:text-slate-200"
          >
            Cerrar
          </button>
        </header>

        <div className="space-y-3">
          <div>
            <label className="mb-1 block text-xs text-slate-300">Remitente</label>
            <input
              readOnly
              value={remitente}
              className="w-full rounded-md border border-slate-700 bg-slate-800 px-2 py-1 text-sm text-slate-100"
            />
          </div>

          <div>
            <label className="mb-1 block text-xs text-slate-300">Para</label>

            {currentUser ? (
              <p className="mb-2 text-xs text-slate-300">
                Tu rol: <span className="font-medium text-slate-100">{currentUser.rol}</span>{' '}
                — Tu dependenciaId:{' '}
                <span className="font-medium text-slate-100">
                  {String(currentUser.dependenciaId)}
                </span>
              </p>
            ) : (
              <p className="mb-2 text-xs text-amber-300">No hay usuario autenticado.</p>
            )}

            <RecipientAutocomplete
              recipients={recipients}
              selectedIds={selectedUserIds}
              onChange={setSelectedUserIds}
              placeholder="Buscar destinatarios..."
            />

            {recipients.length === 0 && (
              <p className="mt-2 text-xs text-amber-300">
                No hay destinatarios disponibles para tu dependencia. Comprueba en la consola del
                navegador (F12) los logs: [ComposeModal] currentUser / recipients.
              </p>
            )}
          </div>

          <div>
            <label className="mb-1 block text-xs text-slate-300">Relacionar con solicitud (opcional)</label>
            <SolicitudAutocomplete
              selectedId={selectedSolicitudId}
              onChange={setSelectedSolicitudId}
              placeholder="Buscar por número de IPP..."
            />
            {selectedSolicitudId && (
              <div className="mt-2 text-xs text-slate-400">La notificación se relacionará con la solicitud seleccionada.</div>
            )}
          </div>

          <div>
            <label className="mb-1 block text-xs text-slate-300">Asunto</label>
            <input
              value={subject}
              onChange={(e) => setSubject(e.target.value)}
              className="w-full rounded-md border border-slate-700 bg-slate-800 px-2 py-1 text-sm text-slate-100"
            />
          </div>

          <div>
            <label className="mb-1 block text-xs text-slate-300">Mensaje</label>
            <textarea
              value={body}
              onChange={(e) => setBody(e.target.value)}
              rows={6}
              className="w-full resize-none rounded-md border border-slate-700 bg-slate-800 px-2 py-1 text-sm text-slate-100"
            />
          </div>

          {/* Sección de adjuntos (modo demo) */}
          <div>
            <label className="mb-1 block text-xs text-slate-300">Adjuntos (demo)</label>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="inline-flex items-center gap-2 rounded-md bg-slate-800 px-3 py-1 text-xs text-slate-200 hover:bg-slate-700"
              >
                <Paperclip className="h-4 w-4 text-slate-200" />
                Adjuntar archivos
              </button>

              <span className="text-xs text-slate-400">Máx por archivo: 100 MB. Máx total por mensaje: {formatBytes(MAX_TOTAL_SIZE_BYTES)}.</span>
            </div>

            <input
              ref={fileInputRef}
              type="file"
              multiple
              onChange={handleFileSelect}
              className="hidden"
            />

            {/* Indicador de tamaño total */}
            <div className="mt-2">
              <div className="h-2 w-full rounded-full bg-slate-800">
                <div
                  className={`h-2 rounded-full ${totalExceeded ? 'bg-rose-500' : 'bg-sky-500'}`}
                  style={{ width: `${totalPercent}%` }}
                />
              </div>
              <div className="mt-1 flex items-center justify-between text-xs text-slate-400">
                <div>{formatBytes(totalAttachmentsSize)} / {formatBytes(MAX_TOTAL_SIZE_BYTES)}</div>
                <div className={`${totalExceeded ? 'text-rose-400' : 'text-slate-400'}`}>
                  {totalExceeded ? 'Límite excedido' : `${totalPercent}%`}
                </div>
              </div>
            </div>

            {attachments.length > 0 && (
              <ul className="mt-2 max-h-36 overflow-auto">
                {attachments.map((a) => (
                  <li key={a.id} className="mb-2 flex items-center justify-between rounded-md bg-slate-800 p-2 text-sm">
                    <div className="flex items-center gap-3">
                      <div className="text-xs text-slate-300">{a.file.name}</div>
                      <div className="text-xs text-slate-400">{formatBytes(a.file.size)}</div>
                    </div>
                    <button
                      type="button"
                      onClick={() => removeAttachment(a.id)}
                      className="rounded p-1 text-slate-300 hover:text-white"
                      aria-label={`Quitar adjunto ${a.file.name}`}
                    >
                      <XIcon className="h-4 w-4" />
                    </button>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </div>

        <footer className="mt-4 flex justify-end gap-2">
          <button
            type="button"
            onClick={onClose}
            className="rounded-md bg-slate-800 px-3 py-1 text-xs text-slate-200 hover:bg-slate-700"
            disabled={isSending}
          >
            Cancelar
          </button>
          <button
            type="submit"
            className="rounded-md bg-sky-600 px-3 py-1 text-xs font-semibold text-white hover:bg-sky-700 disabled:opacity-50"
            disabled={isSending || totalExceeded}
          >
            {isSending ? 'Enviando...' : 'Enviar'}
          </button>
        </footer>
      </form>
    </div>
  )
}