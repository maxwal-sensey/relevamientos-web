/**
 * @file AddressTypeahead.tsx
 * @description Componente de autocompletado de direcciones local (sin fetch).
 *              Alternativa robusta a AddressSearch que evita errores de red
 *              y funciona bien para entradas como "castelli 2024".
 */

import React, { useEffect, useRef, useState } from 'react'

/**
 * AddressResult
 * @description Representa un resultado de búsqueda de dirección.
 */
export interface AddressResult {
  id: string
  text: string
  lat?: number
  lon?: number
}

/**
 * AddressTypeaheadProps
 * @description Props del componente AddressTypeahead.
 */
interface AddressTypeaheadProps {
  placeholder?: string
  /**
   * Callback que recibe el resultado seleccionado.
   */
  onSelect?: (r: AddressResult) => void
  /**
   * Lista local de direcciones para realizar el matching.
   * Si no se provee, se usa un dataset por defecto (expandible).
   */
  localDataset?: AddressResult[]
  /**
   * Máximo número de sugerencias a mostrar.
   */
  maxResults?: number
}

/**
 * AddressTypeahead
 * @description Componente de autocompletado ligero que hace matching local
 *              (case-insensitive, contains) y detecta si el último token es número
 *              (en tal caso lo formatea en la sugerencia: "Calle X 123").
 *
 *              Ventajas:
 *               - No depende de fetch (evita "Failed to fetch")
 *               - Responde instantáneamente y funciona offline
 *               - Fácil de reemplazar donde actualmente uses AddressSearch
 */
export default function AddressTypeahead({
  placeholder = 'Buscar dirección...',
  onSelect,
  localDataset,
  maxResults = 6,
}: AddressTypeaheadProps) {
  const [query, setQuery] = useState('')
  const [suggestions, setSuggestions] = useState<AddressResult[]>([])
  const [open, setOpen] = useState(false)
  const debounceRef = useRef<number | null>(null)
  const mountedRef = useRef(true)

  useEffect(() => {
    mountedRef.current = true
    return () => {
      mountedRef.current = false
      if (debounceRef.current) {
        window.clearTimeout(debounceRef.current)
        debounceRef.current = null
      }
    }
  }, [])

  /**
   * defaultDataset
   * @description Pequeño dataset por defecto; puedes ampliarlo según necesidad.
   */
  const defaultDataset: AddressResult[] = [
    { id: 's-castelli-1', text: 'Castelli' },
    { id: 's-castelli-2', text: 'Av. Castelli' },
    { id: 's-mitre', text: 'Mitre' },
    { id: 's-belgrano', text: 'Belgrano' },
    { id: 's-sarmiento', text: 'Sarmiento' },
    { id: 's-hipolito', text: 'Hipólito Yrigoyen' },
    { id: 's-9-de-julio', text: '9 de Julio' },
    { id: 's-25-de-mayo', text: '25 de Mayo' },
    // agregar más si se requiere
  ]

  const dataset = localDataset && localDataset.length > 0 ? localDataset : defaultDataset

  /**
   * performLocalSearch
   * @description Realiza búsqueda local simple. Si el último token es número lo formatea
   *              en los resultados agregando el número al texto.
   */
  function performLocalSearch(q: string): AddressResult[] {
    const txt = q.trim().toLowerCase()
    if (!txt) return []
    const tokens = txt.split(/\s+/)
    const last = tokens[tokens.length - 1]
    const lastIsNumber = /^\d+$/.test(last)
    const namePart = lastIsNumber ? tokens.slice(0, -1).join(' ') : tokens.join(' ')
    // matching: contiene namePart en el texto (case-insensitive)
    const matched = dataset
      .filter((d) => d.text.toLowerCase().includes(namePart))
      .slice(0, maxResults)
      .map((d, idx) => {
        if (lastIsNumber) {
          return {
            id: `${d.id}-n-${last}-${idx}`,
            text: `${d.text} ${last}`,
            lat: d.lat,
            lon: d.lon,
          }
        }
        return d
      })
    // Si no hay coincidencias se generan sugerencias heurísticas basadas en la entrada
    if (matched.length === 0) {
      // crear 2 sugerencias de fallback que muestren la query tal cual (útil para "castelli 2024")
      return [
        { id: `fb-1-${Date.now()}`, text: q },
        { id: `fb-2-${Date.now()}`, text: `${q} (sin coincidencias)` },
      ]
    }
    return matched
  }

  /**
   * handleInputChange
   * @description Debounce sobre la búsqueda local para mejorar la UX.
   */
  function handleInputChange(next: string) {
    setQuery(next)
    if (debounceRef.current) {
      window.clearTimeout(debounceRef.current)
      debounceRef.current = null
    }
    // debounce pequeño para typing natural
    debounceRef.current = window.setTimeout(() => {
      if (!mountedRef.current) return
      const res = performLocalSearch(next)
      setSuggestions(res)
      setOpen(res.length > 0)
      debounceRef.current = null
    }, 220)
  }

  /**
   * handleSelect
   * @description Selección de sugerencia: notifica al caller y coloca el texto en el input.
   */
  function handleSelect(r: AddressResult) {
    setQuery(r.text)
    setSuggestions([])
    setOpen(false)
    onSelect?.(r)
  }

  return (
    <div className="w-full relative">
      <input
        value={query}
        onChange={(e) => handleInputChange(e.target.value)}
        placeholder={placeholder}
        className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm"
        aria-label="Buscar dirección (local)"
        onFocus={() => {
          if (suggestions.length > 0) setOpen(true)
        }}
        onBlur={() => {
          // pequeño delay para permitir onMouseDown en items
          window.setTimeout(() => {
            if (mountedRef.current) setOpen(false)
          }, 150)
        }}
      />

      {open && suggestions.length > 0 && (
        <ul className="absolute z-20 left-0 right-0 mt-1 max-h-44 overflow-auto rounded border bg-white shadow-md">
          {suggestions.map((s) => (
            <li
              key={s.id}
              className="cursor-pointer px-3 py-2 text-sm hover:bg-slate-100"
              onMouseDown={(e) => {
                // prevenir blur antes de seleccionar
                e.preventDefault()
                handleSelect(s)
              }}
            >
              {s.text}
            </li>
          ))}
        </ul>
      )}
    </div>
  )
}
