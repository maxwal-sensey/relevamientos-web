/**
 * @file UnauthorizedScreen.tsx
 * @description Pantalla reutilizable para informar acceso no autorizado y volver al login.
 */

import { AlertTriangle } from 'lucide-react'
import { useNavigate } from 'react-router'

/**
 * UnauthorizedScreen
 * @description Muestra un mensaje de acceso no autorizado y un botón para volver al inicio de sesión.
 */
export default function UnauthorizedScreen() {
  const navigate = useNavigate()

  return (
    <div className="flex min-h-screen items-center justify-center bg-slate-950 px-4">
      <div className="space-y-4 rounded-xl border border-slate-800 bg-slate-900 px-6 py-6 text-center">
        <AlertTriangle className="mx-auto h-8 w-8 text-amber-400" />
        <h1 className="text-lg font-semibold text-slate-50">
          Acceso no autorizado
        </h1>
        <p className="text-sm text-slate-400">
          Debe iniciar sesión con su número de legajo y contraseña para acceder
          al Sistema de Gestión de Relevamientos.
        </p>
        <button
          type="button"
          onClick={() => navigate('/')}
          className="inline-flex items-center justify-center rounded-md bg-sky-600 px-4 py-2 text-sm font-semibold text-white hover:bg-sky-700"
        >
          Volver al inicio de sesión
        </button>
      </div>
    </div>
  )
}
