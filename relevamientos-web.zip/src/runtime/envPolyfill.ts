/**
 * @file envPolyfill.ts
 * @description Garantiza que window.__ENV__ exista en tiempo de ejecución.
 */

/**
 * bootstrapEnv
 * @description Inicializa window.__ENV__ con un objeto vacío si no existe ya.
 */
if (typeof window !== 'undefined') {
  // Evitar sintaxis avanzada para máxima compatibilidad con el bundler
  if (!(window as any).__ENV__) {
    (window as any).__ENV__ = {}
  }
}

export {}