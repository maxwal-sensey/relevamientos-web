/**
 * @file Home.tsx
 * @description Página de entrada mínima (evita página en blanco en la raíz).
 *
 * Este componente es intencionalmente ligero y sirve como puerta de entrada:
 * - Link a Login y Dashboard
 * - Muestra estado básico (texto) para evitar componentes pesados en la carga inicial
 */

import React from 'react'
import { Link } from 'react-router'

/**
 * HomePage
 * @description Página home sencilla con accesos a las principales secciones.
 */
export default function HomePage() {
  return (
    <main className="min-h-screen flex items-center justify-center bg-slate-50 p-6">
      <div className="w-full max-w-xl bg-white rounded-lg shadow-md p-6">
        <h1 className="text-2xl font-semibold mb-2">SGR - Sistema de Gestión de Relevamientos</h1>
        <p className="text-sm text-slate-600 mb-4">
          Bienvenido. Selecciona una entrada rápida para continuar.
        </p>

        <div className="flex gap-3 flex-wrap">
          <Link to="/login" className="px-4 py-2 bg-blue-600 text-white rounded hover:opacity-90">
            Iniciar sesión
          </Link>
          <Link to="/dashboard" className="px-4 py-2 border border-slate-200 rounded hover:bg-slate-50">
            Ir al Dashboard
          </Link>
          <Link to="/solicitudes" className="px-4 py-2 border border-slate-200 rounded hover:bg-slate-50">
            Solicitudes
          </Link>
          <Link to="/relevamientos" className="px-4 py-2 border border-slate-200 rounded hover:bg-slate-50">
            Relevamientos
          </Link>
        </div>

        <p className="mt-4 text-xs text-slate-500">
          Nota: esta instancia está optimizada para correr en hardware limitado (Raspberry Pi 3). Si el backend no
          está disponible la app puede usar mocks locales para pruebas.
        </p>
      </div>
    </main>
  )
}