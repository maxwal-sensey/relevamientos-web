/**
 * @file InformeRelevamiento.tsx
 * @description Vista de informe formal de relevamiento vecinal y de cámaras, optimizada para impresión.
 */

import { useState } from 'react'
import { useNavigate, useParams } from 'react-router'
import { ArrowLeft, Edit3, Printer } from 'lucide-react'
import AppLayout from '../components/layout/AppLayout'
import { useSystemUser } from '../context/SystemUserContext'
import UnauthorizedScreen from '../components/common/UnauthorizedScreen'
import { getInformeById } from '../mock/relevamientosStore'

/**
 * LEGAL_TEXT
 * @description Texto legal estándar para el informe de relevamiento.
 */
const LEGAL_TEXT =
  'Se hace saber que las personas entrevistadas han sido informadas de las previsiones del Artículo 275 del Código Penal de la Nación y de los Artículos 101 y 240 del Código Procesal Penal de la Provincia de Buenos Aires, en cuanto a la obligación de decir verdad y las consecuencias legales de falsear u omitir información relevante para la investigación.'

/**
 * @interface EditableSectionProps
 * @description Propiedades para un bloque de texto editable previo a la impresión.
 */
interface EditableSectionProps {
  title: string
  text: string
  isEditMode: boolean
}

/**
 * EditableSection
 * @description Muestra un bloque de texto que, en modo edición, se convierte en un área editable no controlada.
 */
function EditableSection({ title, text, isEditMode }: EditableSectionProps) {
  return (
    <section className="space-y-1">
      <h2 className="text-sm font-semibold uppercase tracking-wide text-slate-700">
        {title}
      </h2>
      {isEditMode ? (
        <textarea
          defaultValue={text}
          className="mt-1 w-full rounded border border-amber-300 bg-amber-50 p-2 text-xs leading-relaxed text-slate-900 shadow-inner print:border-none print:bg-transparent"
          rows={5}
        />
      ) : (
        <p className="text-xs leading-relaxed text-slate-800">{text}</p>
      )}
    </section>
  )
}

/**
 * InformeRelevamientoPage
 * @description Página de informe formal de relevamiento, con modo edición temporal y preparación para impresión.
 */
export default function InformeRelevamientoPage() {
  const { currentUser } = useSystemUser()
  const navigate = useNavigate()
  const params = useParams()
  const [isEditMode, setIsEditMode] = useState(false)

  // Restricción de acceso por rol.
  if (
    !currentUser ||
    (currentUser.rol !== 'relevador' && currentUser.rol !== 'administrador')
  ) {
    return <UnauthorizedScreen />
  }

  const id = Number(params.id)
  const informe = getInformeById(id)

  if (!informe) {
    return (
      <AppLayout title="Informe de relevamiento">
        <div className="space-y-4">
          <button
            type="button"
            onClick={() => navigate('/relevamientos')}
            className="inline-flex items-center gap-1.5 rounded-md border border-slate-700 bg-slate-900 px-3 py-1.5 text-xs font-medium text-slate-100 hover:bg-slate-800"
          >
            <ArrowLeft className="h-3.5 w-3.5" />
            Volver a relevamientos
          </button>
          <div className="rounded-lg border border-amber-500/60 bg-amber-500/10 px-4 py-3 text-xs text-amber-100">
            No se encontró el relevamiento solicitado para generar el informe.
          </div>
        </div>
      </AppLayout>
    )
  }

  return (
    <AppLayout title="Informe de relevamiento">
      <div className="space-y-4 print:space-y-0">
        {/* Barra superior de acciones (oculta en impresión) */}
        <div className="flex flex-wrap items-center justify-between gap-2 print:hidden">
          <button
            type="button"
            onClick={() => navigate('/relevamientos')}
            className="inline-flex items-center gap-1.5 rounded-md border border-slate-700 bg-slate-900 px-3 py-1.5 text-xs font-medium text-slate-100 hover:bg-slate-800"
          >
            <ArrowLeft className="h-3.5 w-3.5" />
            Volver al listado
          </button>
          <div className="flex gap-2">
            <button
              type="button"
              onClick={() => setIsEditMode((prev) => !prev)}
              className="inline-flex items-center gap-1.5 rounded-md bg-emerald-600 px-3 py-1.5 text-xs font-semibold text-white shadow-sm hover:bg-emerald-700"
            >
              <Edit3 className="h-3.5 w-3.5" />
              {isEditMode ? 'Ver sin edición' : 'Editar antes de imprimir'}
            </button>
            <button
              type="button"
              onClick={() => window.print()}
              className="inline-flex items-center gap-1.5 rounded-md bg-emerald-600 px-3 py-1.5 text-xs font-semibold text-white shadow-sm hover:bg-emerald-700"
            >
              <Printer className="h-3.5 w-3.5" />
              Imprimir informe
            </button>
          </div>
        </div>

        {/* Hoja imprimible */}
        <section className="mx-auto max-w-4xl rounded-lg border border-slate-300 bg-white p-6 text-slate-900 shadow print:m-0 print:max-w-none print:rounded-none print:border-0 print:p-4 print:shadow-none">
          {/* Encabezado institucional */}
          <header className="flex items-center gap-4 border-b border-slate-300 pb-4">
            <div className="h-14 w-14 flex items-center justify-center rounded-md border border-slate-300 bg-slate-100 p-1">
              <img
                src="https://pub-cdn.sider.ai/u/U024HXLZ36N/web-coder/6996688cf14a3242c2c209dd/resource/1c376e85-0ffe-43f5-b7ff-7c6164f7e1a3.png"
                alt="Escudo institucional"
                className="max-h-full max-w-full object-contain"
              />
            </div>
            <div className="flex-1">
              <p className="text-[11px] font-semibold uppercase tracking-wide text-slate-700">
                Ministerio de Seguridad
              </p>
              <p className="text-[11px] font-medium text-slate-700">
                Provincia de Buenos Aires
              </p>
              <p className="mt-0.5 text-[10px] text-slate-600">
                {informe.dependenciaNombre}
              </p>
            </div>
            <div className="text-right text-[10px] text-slate-600">
              <p className="font-semibold">
                N° Registro: {informe.numeroRegistro}
              </p>
              <p>
                Fecha:{' '}
                {new Date(informe.fecha).toLocaleDateString('es-AR')}
              </p>
            </div>
          </header>

          {/* Título principal */}
          <div className="mt-4 text-center">
            <h1 className="text-sm font-bold uppercase tracking-[0.2em] text-slate-800">
              INFORME DE RELEVAMIENTO VECINAL Y DE CÁMARAS
            </h1>
          </div>

          <div className="mt-4 space-y-4 text-xs">
            {/* Datos del caso */}
            <section>
              <h2 className="mb-1 text-sm font-semibold uppercase tracking-wide text-slate-700">
                Datos del caso
              </h2>
              <div className="grid gap-x-6 gap-y-1 text-[11px] md:grid-cols-2">
                <div>
                  <span className="font-semibold">IPP: </span>
                  <span>{informe.ipp}</span>
                </div>
                <div>
                  <span className="font-semibold">Fiscalía: </span>
                  <span>{informe.fiscalia}</span>
                </div>
                <div>
                  <span className="font-semibold">Carátula: </span>
                  <span>{informe.caratula}</span>
                </div>
                <div>
                  <span className="font-semibold">Lugar del hecho: </span>
                  <span>{informe.lugar}</span>
                </div>
              </div>
            </section>

            {/* Resumen del hecho */}
            <EditableSection
              title="Resumen del hecho"
              text={informe.resumenHecho}
              isEditMode={isEditMode}
            />

            {/* Cámaras relevadas */}
            <section className="space-y-1">
              <h2 className="text-sm font-semibold uppercase tracking-wide text-slate-700">
                Cámaras relevadas
              </h2>
              {informe.camaras.length === 0 ? (
                <p className="text-xs text-slate-700">
                  No se registran cámaras relevadas para el presente informe.
                </p>
              ) : (
                <table className="w-full border-collapse text-[10px]">
                  <thead>
                    <tr className="border-b border-slate-300 bg-slate-100">
                      <th className="px-2 py-1 text-left font-semibold">
                        Lugar / Dirección
                      </th>
                      <th className="px-2 py-1 text-left font-semibold">
                        Tipo
                      </th>
                      <th className="px-2 py-1 text-left font-semibold">
                        Acción realizada
                      </th>
                      <th className="px-2 py-1 text-left font-semibold">
                        Entrevistado
                      </th>
                      <th className="px-2 py-1 text-left font-semibold">
                        Observaciones
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    {informe.camaras.map((cam) => (
                      <tr
                        key={cam.id}
                        className="border-b border-slate-200 align-top"
                      >
                        <td className="px-2 py-1">{cam.lugar}</td>
                        <td className="px-2 py-1">{cam.tipo}</td>
                        <td className="px-2 py-1">{cam.accion}</td>
                        <td className="px-2 py-1">
                          {cam.entrevistado ?? '—'}
                        </td>
                        <td className="px-2 py-1">
                          {cam.observaciones ?? '—'}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}
            </section>

            {/* Vecinos entrevistados */}
            <section className="space-y-1">
              <h2 className="text-sm font-semibold uppercase tracking-wide text-slate-700">
                Vecinos entrevistados
              </h2>
              {informe.vecinos.length === 0 ? (
                <p className="text-xs text-slate-700">
                  No se registran vecinos entrevistados para el presente
                  informe.
                </p>
              ) : (
                <table className="w-full border-collapse text-[10px]">
                  <thead>
                    <tr className="border-b border-slate-300 bg-slate-100">
                      <th className="px-2 py-1 text-left font-semibold">
                        Nombre / DNI
                      </th>
                      <th className="px-2 py-1 text-left font-semibold">
                        Lugar de entrevista
                      </th>
                      <th className="px-2 py-1 text-left font-semibold">
                        Presencia / conocimiento
                      </th>
                      <th className="px-2 py-1 text-left font-semibold">
                        Cámaras y observaciones
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    {informe.vecinos.map((vecino) => (
                      <tr
                        key={vecino.id}
                        className="border-b border-slate-200 align-top"
                      >
                        <td className="px-2 py-1">
                          <div>{vecino.nombreCompleto}</div>
                          {vecino.dni && (
                            <div className="text-[10px] text-slate-600">
                              DNI: {vecino.dni}
                            </div>
                          )}
                        </td>
                        <td className="px-2 py-1">
                          {vecino.lugarEntrevista}
                        </td>
                        <td className="px-2 py-1">
                          <div>
                            <span className="font-semibold">Presencia: </span>
                            {vecino.presencio ? 'Sí' : 'No'}
                          </div>
                          {vecino.detallePresencio && (
                            <div className="mt-0.5 text-[10px] text-slate-700">
                              {vecino.detallePresencio}
                            </div>
                          )}
                          <div className="mt-1">
                            <span className="font-semibold">
                              Conocimiento:{' '}
                            </span>
                            {vecino.conocimiento ? 'Sí' : 'No'}
                          </div>
                          {vecino.detalleConocimiento && (
                            <div className="mt-0.5 text-[10px] text-slate-700">
                              {vecino.detalleConocimiento}
                            </div>
                          )}
                        </td>
                        <td className="px-2 py-1">
                          {vecino.infoCamaras && (
                            <div className="text-[10px] text-slate-700">
                              {vecino.infoCamaras}
                            </div>
                          )}
                          {vecino.observaciones && (
                            <div className="mt-0.5 text-[10px] text-slate-700">
                              {vecino.observaciones}
                            </div>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}
            </section>

            {/* Observaciones generales */}
            <EditableSection
              title="Observaciones generales"
              text={informe.observacionesGenerales}
              isEditMode={isEditMode}
            />

            {/* Texto legal */}
            <EditableSection
              title="Texto legal"
              text={LEGAL_TEXT}
              isEditMode={isEditMode}
            />

            {/* Firmas */}
            <section className="mt-4 grid gap-6 text-[11px] md:grid-cols-3">
              <div className="space-y-2 text-center">
                <div className="h-10" />
                <div className="border-t border-slate-400 pt-1" />
                <p className="font-semibold text-slate-800">
                  {informe.relevadorNombre}
                </p>
                <p className="text-[10px] text-slate-600">
                  Personal Relevador
                </p>
              </div>
              <div className="space-y-2 text-center">
                <div className="h-10" />
                <div className="border-t border-slate-400 pt-1" />
                <p className="font-semibold text-slate-800">
                  {informe.secretariaNombre}
                </p>
                <p className="text-[10px] text-slate-600">
                  Secretaría actuante
                </p>
              </div>
              <div className="space-y-2 text-center">
                <div className="h-10" />
                <div className="border-t border-slate-400 pt-1" />
                <p className="font-semibold text-slate-800">
                  Sello institucional
                </p>
                <p className="text-[10px] text-slate-600">
                  Dependencia policial
                </p>
              </div>
            </section>
          </div>

          {/* Pie de página para impresión */}
          <footer className="mt-6 border-t border-slate-300 pt-2 text-[9px] text-slate-600 print:mt-4">
            <div className="flex items-center justify-between">
              <span>SGR - Sistema de Gestión de Relevamientos</span>
              <span>N° Registro: {informe.numeroRegistro}</span>
            </div>
          </footer>
        </section>
      </div>
    </AppLayout>
  )
}