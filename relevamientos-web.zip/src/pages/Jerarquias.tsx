/**
 * @file Jerarquias.tsx
 * @description Página de gestión de jerarquías (lista, búsqueda, crear/editar/demo).
 */

import { useMemo, useState } from 'react'
import { List, Plus, Pencil, Trash2 } from 'lucide-react'
import AppLayout from '../components/layout/AppLayout'
import UnauthorizedScreen from '../components/common/UnauthorizedScreen'
import { useSystemUser } from '../context/SystemUserContext'
import {
  getJerarquias,
  type DemoJerarquia,
  createJerarquia,
  updateJerarquia,
  deleteJerarquia,
} from '../mock/jerarquiasStore'
import JerarquiaFormModal, { type JerarquiaFormValues, type JerarquiaFormMode } from '../components/jerarquias/JerarquiaFormModal'

/**
 * JerarquiasPage
 * @description Página principal para administrar jerarquías (solo demo, solo admin).
 */
export default function JerarquiasPage() {
  const { currentUser } = useSystemUser()
  const [searchTerm, setSearchTerm] = useState('')
  const [isFormOpen, setIsFormOpen] = useState(false)
  const [formMode, setFormMode] = useState<JerarquiaFormMode>('create')
  const [selected, setSelected] = useState<DemoJerarquia | null>(null)
  const [refreshKey, setRefreshKey] = useState(0)

  // Acceso restringido a administradores
  if (!currentUser || currentUser.rol !== 'administrador') {
    return <UnauthorizedScreen />
  }

  /**
   * filtered
   * @description Filtra jerarquías por nombre según el término de búsqueda.
   */
  const filtered = useMemo(() => {
    const term = searchTerm.trim().toLowerCase()
    const list = getJerarquias()
    if (!term) return list
    return list.filter((j) => j.nombre.toLowerCase().includes(term))
  }, [searchTerm, refreshKey])

  /**
   * handleSubmit
   * @description Maneja submit del modal (create / edit) en modo demo.
   */
  function handleSubmit(values: JerarquiaFormValues) {
    if (formMode === 'create') {
      createJerarquia(values.nombre, values.orden)
      window.alert('Jerarquía creada (demo).')
    } else if (formMode === 'edit' && selected) {
      updateJerarquia(selected.id, { nombre: values.nombre, orden: values.orden })
      window.alert('Jerarquía actualizada (demo).')
    }
    setIsFormOpen(false)
    setSelected(null)
    setRefreshKey((k) => k + 1)
  }

  return (
    <AppLayout title="Jerarquías">
      <div className="space-y-4">
        <div className="flex items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-sky-600/20 text-sky-300">
              <List className="h-4 w-4" />
            </div>
            <div>
              <h2 className="text-sm font-semibold text-slate-100">Jerarquías</h2>
              <p className="text-xs text-slate-400">Gestión de rangos policiales (demo).</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <input
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Buscar por nombre..."
              className="rounded-md border border-slate-700 bg-slate-900 px-2 py-1 text-xs text-slate-100 placeholder:text-slate-500 focus:border-sky-500 focus:outline-none focus:ring-1 focus:ring-sky-500"
            />
            <button
              type="button"
              onClick={() => {
                setFormMode('create')
                setSelected(null)
                setIsFormOpen(true)
              }}
              className="inline-flex items-center gap-1 rounded-md bg-sky-600 px-3 py-1.5 text-xs font-semibold text-white hover:bg-sky-700"
            >
              <Plus className="h-3.5 w-3.5" />
              Nueva
            </button>
          </div>
        </div>

        <div className="rounded-xl border border-slate-800 bg-slate-900/70 p-3">
          <div className="grid gap-2">
            {filtered.map((j) => (
              <div key={j.id} className="flex items-center justify-between gap-3 rounded-md border border-slate-800 bg-slate-900 p-3">
                <div className="flex items-center gap-3">
                  <div className="flex flex-col">
                    <span className="text-sm font-medium text-slate-100">{j.nombre}</span>
                    <span className="text-xs text-slate-400">Orden: <span className="font-mono text-slate-200">{j.orden}</span></span>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      setFormMode('edit')
                      setSelected(j)
                      setIsFormOpen(true)
                    }}
                    className="inline-flex items-center gap-1 rounded-md bg-slate-800 px-2 py-1 text-[11px] font-medium text-slate-100 hover:bg-slate-700"
                  >
                    <Pencil className="h-3.5 w-3.5" />
                    Editar
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      const ok = confirm('Eliminar jerarquía (demo)?')
                      if (!ok) return
                      deleteJerarquia(j.id)
                      setRefreshKey((k) => k + 1)
                    }}
                    className="inline-flex items-center gap-1 rounded-md bg-slate-800 px-2 py-1 text-[11px] font-medium text-red-200 hover:bg-red-700"
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                    Eliminar
                  </button>
                </div>
              </div>
            ))}

            {filtered.length === 0 && (
              <div className="col-span-full rounded-lg border border-dashed border-slate-700 bg-slate-900/60 p-6 text-center text-xs text-slate-400">
                No se encontraron jerarquías con el término ingresado.
              </div>
            )}
          </div>
        </div>
      </div>

      <JerarquiaFormModal
        open={isFormOpen}
        mode={formMode}
        initial={selected ?? undefined}
        onClose={() => {
          setIsFormOpen(false)
          setSelected(null)
        }}
        onSubmit={(vals) => handleSubmit(vals)}
      />
    </AppLayout>
  )
}