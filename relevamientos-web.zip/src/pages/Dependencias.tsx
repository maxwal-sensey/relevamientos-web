/**
 * @file Dependencias.tsx
 * @description Gestión de dependencias (unidades organizacionales) en modo demo, solo para administradores.
 */

import { useMemo, useState } from 'react'
import {
  Building2,
  Plus,
  Search,
  Pencil,
  Trash2,
  Shield,
} from 'lucide-react'
import AppLayout from '../components/layout/AppLayout'
import UnauthorizedScreen from '../components/common/UnauthorizedScreen'
import { useSystemUser } from '../context/SystemUserContext'
import {
  getDependencias,
  type DemoDependencia,
} from '../mock/dependenciasStore'
import {
  DependencyFormModal,
  type DependencyFormMode,
  type DependencyFormValues,
} from '../components/dependencias/DependencyFormModal'

/**
 * DependenciasPage
 * @description Vista de administración básica de dependencias (solo admin, datos demo).
 */
export default function DependenciasPage() {
  const { currentUser } = useSystemUser()

  const [searchTerm, setSearchTerm] = useState('')
  const [isFormOpen, setIsFormOpen] = useState(false)
  const [formMode, setFormMode] = useState<DependencyFormMode>('create')
  const [selectedDependency, setSelectedDependency] =
    useState<DemoDependencia | null>(null)

  // Restricción de acceso por rol: solo administrador.
  if (!currentUser || currentUser.rol !== 'administrador') {
    return <UnauthorizedScreen />
  }

  /**
   * handleSubmitDependencyForm
   * @description Maneja el envío del formulario de alta/edición en modo demo (sin persistencia real).
   * @param values Valores del formulario de dependencia
   */
  const handleSubmitDependencyForm = (values: DependencyFormValues) => {
    const actionLabel = formMode === 'create' ? 'creación' : 'edición'

    window.alert(
      'Formulario de ' +
        actionLabel +
        ' de dependencia enviado.\n\n' +
        'Nombre: ' +
        values.nombre +
        '\n' +
        'Descripción: ' +
        (values.descripcion ? values.descripcion : '(sin descripción)') +
        '\n\n' +
        'En esta versión demo los datos no se guardan en la base de datos; la persistencia real se implementará cuando se conecte el backend (D1).'
    )

    setIsFormOpen(false)
    setSelectedDependency(null)
  }

  /**
   * filteredDependencies
   * @description Aplica filtro de texto (nombre / descripción) sobre el listado demo.
   */
  const filteredDependencies = useMemo(() => {
    const term = searchTerm.trim().toLowerCase()
    const data = getDependencias()

    if (!term) return data

    return data.filter((dep) => {
      const nombre = dep.nombre.toLowerCase()
      const descripcion = (dep.descripcion ?? '').toLowerCase()
      return nombre.includes(term) || descripcion.includes(term)
    })
  }, [searchTerm])

  return (
    <AppLayout title="Dependencias">
      <div className="space-y-4">
        {/* Encabezado y contexto */}
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <p className="text-sm text-slate-200">
              Administración de dependencias (unidades organizacionales) del
              Sistema de Gestión de Relevamientos.
            </p>
            <p className="text-xs text-slate-400">
              En esta versión se muestran dependencias de ejemplo para validar
              la navegación y los permisos de administrador.
            </p>
          </div>
          <div className="flex flex-col items-stretch gap-2 sm:flex-row sm:items-center">
            <button
              type="button"
              onClick={() => {
                setFormMode('create')
                setSelectedDependency(null)
                setIsFormOpen(true)
              }}
              className="inline-flex items-center justify-center gap-1.5 rounded-md bg-sky-600 px-3 py-1.5 text-xs font-semibold text-white shadow-sm hover:bg-sky-700"
            >
              <Plus className="h-3.5 w-3.5" />
              Nueva dependencia
            </button>
            <div className="inline-flex items-center gap-1 rounded-full border border-emerald-500/40 bg-emerald-500/10 px-3 py-1 text-[11px] text-emerald-100">
              <Shield className="h-3.5 w-3.5" />
              <span>Acceso solo administradores</span>
            </div>
          </div>
        </div>

        {/* Filtros */}
        <div className="rounded-xl border border-slate-800 bg-slate-900/70 p-3">
          <label className="mb-1 block text-xs font-medium text-slate-300">
            Búsqueda por nombre o descripción
          </label>
          <div className="relative">
            <Search className="pointer-events-none absolute left-2 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-500" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Ej: Comisaría 1ra, central..."
              className="block w-full rounded-md border border-slate-700 bg-slate-900 pl-8 pr-3 text-xs text-slate-100 placeholder:text-slate-500 focus:border-sky-500 focus:outline-none focus:ring-1 focus:ring-sky-500"
            />
          </div>
        </div>

        {/* Grid de dependencias */}
        <div className="space-y-2">
          <div className="text-xs text-slate-400">
            {filteredDependencies.length} dependencia
            {filteredDependencies.length !== 1 ? 's' : ''} encontrada
            {filteredDependencies.length !== 1 ? 's' : ''}.
          </div>

          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {filteredDependencies.map((dep) => (
              <article
                key={dep.id}
                className="flex flex-col rounded-xl border border-slate-800 bg-slate-900/70 p-3 shadow-sm"
              >
                <div className="mb-2 flex items-start gap-2">
                  <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-sky-600/20 text-sky-300">
                    <Building2 className="h-4 w-4" />
                  </div>
                  <div className="flex-1">
                    <h3 className="text-sm font-semibold text-slate-50">
                      {dep.nombre}
                    </h3>
                    {dep.descripcion && (
                      <p className="mt-0.5 line-clamp-2 text-[11px] text-slate-300">
                        {dep.descripcion}
                      </p>
                    )}
                  </div>
                </div>

                <div className="mt-auto space-y-1 text-[11px] text-slate-400">
                  <p>
                    Usuarios asociados:{' '}
                    <span className="font-semibold text-slate-100">
                      {dep.cantidadUsuarios}
                    </span>
                  </p>
                  <p>
                    Creada el{' '}
                    <span className="font-mono text-slate-200">
                      {new Date(dep.fechaCreacion).toLocaleDateString('es-AR')}
                    </span>
                  </p>
                </div>

                <div className="mt-3 flex items-center justify-between border-t border-slate-800 pt-2">
                  <button
                    type="button"
                    className="inline-flex items-center gap-1 rounded-md bg-slate-800 px-2 py-1 text-[11px] font-medium text-slate-100 hover:bg-slate-700"
                    onClick={() => {
                      setFormMode('edit')
                      setSelectedDependency(dep)
                      setIsFormOpen(true)
                    }}
                  >
                    <Pencil className="h-3.5 w-3.5" />
                    Editar
                  </button>
                  <button
                    type="button"
                    disabled={dep.cantidadUsuarios > 0}
                    className="inline-flex items-center gap-1 rounded-md bg-slate-800 px-2 py-1 text-[11px] font-medium text-red-200 hover:bg-red-700 disabled:cursor-not-allowed disabled:opacity-40"
                    onClick={() => {
                      window.alert(
                        dep.cantidadUsuarios > 0
                          ? 'Solo se podrán eliminar dependencias que no tengan usuarios asociados (validación que se hará contra la base de datos real).'
                          : 'En la versión con backend se confirmará la baja y se borrará la dependencia si no tiene usuarios vinculados.'
                      )
                    }}
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                    Eliminar
                  </button>
                </div>
              </article>
            ))}

            {filteredDependencies.length === 0 && (
              <div className="col-span-full rounded-lg border border-dashed border-slate-700 bg-slate-900/60 p-6 text-center text-xs text-slate-400">
                No se encontraron dependencias con el término de búsqueda
                ingresado.
              </div>
            )}
          </div>
        </div>
      </div>

      <DependencyFormModal
        open={isFormOpen}
        mode={formMode}
        initialDependency={selectedDependency ?? undefined}
        onClose={() => {
          setIsFormOpen(false)
          setSelectedDependency(null)
        }}
        onSubmit={handleSubmitDependencyForm}
      />
    </AppLayout>
  )
}