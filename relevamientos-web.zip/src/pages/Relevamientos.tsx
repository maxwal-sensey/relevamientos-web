/**
 * @file Relevamientos.tsx
 * @description Página de listados de relevamientos. Presenta la información en formato
 *              de tabla/listado compacto y permite abrir el resumen rápido o ver el informe.
 */

import React, { useEffect, useState } from 'react'
import AppLayout from '../components/layout/AppLayout'
import RelevamientosList from '../components/relevamientos/RelevamientosList'
import { getInformeById, InformeRelevamientoData } from '../mock/relevamientosStore'

/**
 * RelevamientosPage
 * @description Carga informes demo desde el store mock y renderiza la lista de relevamientos
 *              en formato tabla utilizando el componente RelevamientosList.
 */
export default function RelevamientosPage(): JSX.Element {
  const [informes, setInformes] = useState<InformeRelevamientoData[]>([])

  /**
   * loadInformes
   * @description Intenta cargar informes desde el mock store probando ids comunes (1..20).
   *              Esto evita depender de una API concreta y permite mostrar contenido en la UI.
   */
  useEffect(() => {
    const items: InformeRelevamientoData[] = []
    for (let i = 1; i <= 20; i++) {
      const inf = getInformeById(i)
      if (inf) items.push(inf)
    }
    setInformes(items)
  }, [])

  return (
    <AppLayout title="Relevamientos">
      <main className="p-6">
        <header className="mb-6 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="rounded-md bg-sky-600/20 p-2 text-sky-400">
              {/* Icono decorativo */}
              <svg className="h-6 w-6" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
                <path d="M3 7v10a2 2 0 0 0 2 2h14" />
                <path d="M16 3v4" />
                <path d="M8 3v4" />
              </svg>
            </div>
            <div>
              <h1 className="text-lg font-semibold text-slate-50">Relevamientos</h1>
              <p className="text-sm text-slate-400">Listado de relevamientos realizados</p>
            </div>
          </div>

          <div>
            <a
              href="#/relevamientos/nuevo"
              className="inline-flex items-center gap-2 rounded bg-sky-600 px-3 py-1 text-sm font-medium hover:bg-sky-500"
            >
              Nuevo relevamiento
            </a>
          </div>
        </header>

        {informes.length === 0 ? (
          <section className="rounded border border-slate-800 bg-slate-900/60 p-6 text-center text-slate-300">
            <p className="mb-3">No hay relevamientos para mostrar.</p>
            <p className="text-sm">Puedes crear uno nuevo desde el botón <strong>Nuevo relevamiento</strong>.</p>
          </section>
        ) : (
          <RelevamientosList informes={informes} />
        )}
      </main>
    </AppLayout>
  )
}