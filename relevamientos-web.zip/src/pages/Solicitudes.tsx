/**
 * @file Solicitudes.tsx
 * @description Página: listado de solicitudes de relevamiento. Consume el mock-store
 *              para obtener datos y permite navegar a la vista de detalle.
 */

import React, { useEffect, useMemo, useState } from 'react'
import {
  Calendar,
  ClipboardList,
  Eye,
  FileText,
  Paperclip,
  Pencil,
  Search,
} from 'lucide-react'
import { useNavigate } from 'react-router'
import AppLayout from '../components/layout/AppLayout'
import { useSystemUser } from '../context/SystemUserContext'
import UnauthorizedScreen from '../components/common/UnauthorizedScreen'
import NewSolicitudButton from '../components/solicitudes/NewSolicitudButton'
import EditSolicitudModal from '../components/solicitudes/EditSolicitudModal'
import SolicitudAttachmentsModal from '../components/solicitudes/SolicitudAttachmentsModal'
import { fetchSolicitudes, Solicitud as SolicitudTipo } from '../mock/solicitudesStore'

/**
 * EstadoSolicitud
 * @description Estados posibles de una solicitud.
 */
type EstadoSolicitud = 'pendiente' | 'finalizada'

/**
 * SolicitudesPage
 * @description Página de listado y filtros de solicitudes.
 *
 * - Consume fetchSolicitudes desde el mock-store.
 * - Navega a /solicitudes/:id pasando la solicitud en location.state para mostrar el detalle.
 * - Abre modal de edición en lugar de alert para editar una solicitud.
 */
export default function SolicitudesPage(): JSX.Element {
  const { currentUser } = useSystemUser()
  const navigate = useNavigate()

  const [solicitudes, setSolicitudes] = useState<SolicitudTipo[]>([])
  const [loading, setLoading] = useState(true)

  const [searchTerm, setSearchTerm] = useState('')
  const [estadoFilter, setEstadoFilter] = useState<'todas' | EstadoSolicitud>('todas')
  const [dateFrom, setDateFrom] = useState('')
  const [dateTo, setDateTo] = useState('')

  const [editingSolicitud, setEditingSolicitud] = useState<SolicitudTipo | null>(null)
  const [attachmentsForSolicitudId, setAttachmentsForSolicitudId] = useState<number | null>(null)

  // Redirección si no hay usuario autenticado.
  if (!currentUser) {
    return <UnauthorizedScreen />
  }

  /**
   * Effect: cargar solicitudes desde el mock-store al montar la página.
   */
  useEffect(() => {
    let mounted = true
    setLoading(true)
    fetchSolicitudes()
      .then((data) => {
        if (!mounted) return
        setSolicitudes(data)
      })
      .finally(() => {
        if (!mounted) return
        setLoading(false)
      })
    return () => {
      mounted = false
    }
  }, [])

  /**
   * filteredSolicitudes
   * @description Aplica filtros de texto, estado, rango de fechas y dependencia a la lista cargada.
   */
  const filteredSolicitudes = useMemo(() => {
    const term = searchTerm.trim().toLowerCase()
    const fromDate = dateFrom ? new Date(dateFrom) : null
    const toDate = dateTo ? new Date(dateTo) : null

    const result = solicitudes.filter((sol) => {
      const matchesSearch =
        !term ||
        sol.numeroRegistro.toLowerCase().includes(term) ||
        sol.ipp.toLowerCase().includes(term) ||
        sol.fiscalia.toLowerCase().includes(term) ||
        sol.caratula.toLowerCase().includes(term) ||
        sol.lugar.toLowerCase().includes(term)

      const matchesEstado = estadoFilter === 'todas' || sol.estado === estadoFilter
      const currentDate = new Date(sol.fecha)
      const matchesFrom = !fromDate || currentDate >= fromDate
      const matchesTo = !toDate || currentDate <= toDate

      // Filtrado por dependencia: usuarios no administradores solo ven solicitudes de su dependencia.
      const matchesDependencia =
        currentUser.rol === 'administrador' ||
        currentUser.dependenciaId == null ||
        sol.dependenciaId === currentUser.dependenciaId

      return matchesSearch && matchesEstado && matchesFrom && matchesTo && matchesDependencia
    })

    // Ordenar descendente por fecha.
    return result.sort((a, b) => new Date(b.fecha).getTime() - new Date(a.fecha).getTime())
  }, [searchTerm, estadoFilter, dateFrom, dateTo, currentUser, solicitudes])

  /**
   * handleOpenDetail
   * @description Navega a la vista de detalle pasando la solicitud como state.
   */
  const handleOpenDetail = (sol: SolicitudTipo) => {
    navigate(`/solicitudes/${sol.id}`, { state: { solicitud: sol } })
  }

  /**
   * handleOpenEdit
   * @description Abre el modal de edición para la solicitud seleccionada.
   */
  const handleOpenEdit = (sol: SolicitudTipo) => {
    setEditingSolicitud(sol)
  }

  /**
   * handleSaved
   * @description Actualiza la lista local con la solicitud modificada.
   */
  const handleSaved = (updated: SolicitudTipo) => {
    setSolicitudes((prev) => prev.map((s) => (s.id === updated.id ? updated : s)))
  }

  /**
   * handleOpenInforme
   * @description Navega a la ruta del informe de relevamiento relacionado con la solicitud.
   *              Asume que el id del informe en el mock coincide con el id de la solicitud
   *              (mapeo común en el dataset de demo). Si en tu data real existe otra relación
   *              (ej. relevamientoId en la solicitud), reemplazar esta lógica por una búsqueda
   *              en el store de relevamientos.
   */
  const handleOpenInforme = (sol: SolicitudTipo) => {
    navigate(`/relevamientos/${sol.id}/informe`)
  }

  return (
    <AppLayout title="Solicitudes de relevamiento">
      <div className="space-y-4">
        {/* Encabezado y botón de nueva solicitud */}
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <p className="text-sm text-slate-200">
              Gestión de solicitudes de relevamiento provenientes de fiscalías.
            </p>
            <p className="text-xs text-slate-400">
              Use los filtros para buscar por número de registro, IPP, fiscalía, carátula, estado o fechas.
            </p>
          </div>
          <div>
            <NewSolicitudButton />
          </div>
        </div>

        {/* Filtros */}
        <div className="grid gap-3 rounded-xl border border-slate-800 bg-slate-900/70 p-3 sm:grid-cols-2 lg:grid-cols-4">
          <div className="sm:col-span-2">
            <label className="mb-1 block text-xs font-medium text-slate-300">Búsqueda</label>
            <div className="relative">
              <Search className="pointer-events-none absolute left-2 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-500" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="N° registro, IPP, fiscalía, carátula, lugar..."
                className="block w-full rounded-md border border-slate-700 bg-slate-900 pl-8 pr-3 text-xs text-slate-100 placeholder:text-slate-500 focus:border-sky-500 focus:outline-none focus:ring-1 focus:ring-sky-500"
              />
            </div>
          </div>

          <div>
            <label className="mb-1 block text-xs font-medium text-slate-300">Estado</label>
            <select
              value={estadoFilter}
              onChange={(e) => setEstadoFilter(e.target.value as 'todas' | EstadoSolicitud)}
              className="block w-full rounded-md border border-slate-700 bg-slate-900 px-2 py-1.5 text-xs text-slate-100 focus:border-sky-500 focus:outline-none focus:ring-1 focus:ring-sky-500"
            >
              <option value="todas">Todas</option>
              <option value="pendiente">Pendiente</option>
              <option value="finalizada">Finalizada</option>
            </select>
          </div>

          <div className="flex gap-2">
            <div className="flex-1">
              <label className="mb-1 block text-xs font-medium text-slate-300">Desde</label>
              <div className="relative">
                <Calendar className="pointer-events-none absolute left-2 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-slate-500" />
                <input
                  type="date"
                  value={dateFrom}
                  onChange={(e) => setDateFrom(e.target.value)}
                  className="block w-full rounded-md border border-slate-700 bg-slate-900 pl-7 pr-2 text-xs text-slate-100 focus:border-sky-500 focus:outline-none focus:ring-1 focus:ring-sky-500"
                />
              </div>
            </div>
            <div className="flex-1">
              <label className="mb-1 block text-xs font-medium text-slate-300">Hasta</label>
              <div className="relative">
                <Calendar className="pointer-events-none absolute left-2 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-slate-500" />
                <input
                  type="date"
                  value={dateTo}
                  onChange={(e) => setDateTo(e.target.value)}
                  className="block w-full rounded-md border border-slate-700 bg-slate-900 pl-7 pr-2 text-xs text-slate-100 focus:border-sky-500 focus:outline-none focus:ring-1 focus:ring-sky-500"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Tabla de resultados */}
        <div className="overflow-hidden rounded-xl border border-slate-800 bg-slate-900/70">
          <div className="border-b border-slate-800 bg-slate-900/80 px-4 py-2 text-xs text-slate-400">
            {loading ? 'Cargando solicitudes...' : `${filteredSolicitudes.length} solicitud${filteredSolicitudes.length !== 1 ? 'es' : ''} encontrada${filteredSolicitudes.length !== 1 ? 's' : ''}.`}
          </div>
          <div className="overflow-x-auto">
            <table className="min-w-full border-separate border-spacing-0 text-xs">
              <thead>
                <tr className="bg-slate-900">
                  <th className="sticky left-0 z-10 border-b border-slate-800 bg-slate-900 px-3 py-2 text-left font-semibold text-slate-300">N° Registro</th>
                  <th className="border-b border-slate-800 px-3 py-2 text-left font-semibold text-slate-300">Fecha</th>
                  <th className="border-b border-slate-800 px-3 py-2 text-left font-semibold text-slate-300">IPP</th>
                  <th className="border-b border-slate-800 px-3 py-2 text-left font-semibold text-slate-300">Fiscalía</th>
                  <th className="border-b border-slate-800 px-3 py-2 text-left font-semibold text-slate-300">Lugar</th>
                  <th className="border-b border-slate-800 px-3 py-2 text-left font-semibold text-slate-300">Carátula</th>
                  <th className="border-b border-slate-800 px-3 py-2 text-left font-semibold text-slate-300">Estado</th>
                  <th className="border-b border-slate-800 px-3 py-2 text-left font-semibold text-slate-300">Creador</th>
                  <th className="border-b border-slate-800 px-3 py-2 text-right font-semibold text-slate-300">Acciones</th>
                </tr>
              </thead>
              <tbody>
                {loading && (
                  <tr>
                    <td colSpan={9} className="px-3 py-6 text-center text-xs text-slate-400">Cargando...</td>
                  </tr>
                )}

                {!loading && filteredSolicitudes.length === 0 && (
                  <tr>
                    <td colSpan={9} className="px-3 py-6 text-center text-xs text-slate-400">
                      No se encontraron solicitudes con los filtros seleccionados.
                    </td>
                  </tr>
                )}

                {!loading &&
                  filteredSolicitudes.map((sol) => (
                    <tr key={sol.id} className="border-t border-slate-800 odd:bg-slate-900/60 even:bg-slate-900/40">
                      <td className="sticky left-0 z-0 whitespace-nowrap border-r border-slate-800 bg-slate-900/60 px-3 py-2 font-medium text-slate-50">
                        {sol.numeroRegistro}
                      </td>
                      <td className="whitespace-nowrap px-3 py-2 text-slate-200">{new Date(sol.fecha).toLocaleDateString('es-AR')}</td>
                      <td className="whitespace-nowrap px-3 py-2 text-slate-200">{sol.ipp}</td>
                      <td className="whitespace-nowrap px-3 py-2 text-slate-200">{sol.fiscalia}</td>
                      <td className="max-w-xs px-3 py-2 text-slate-200"><span className="line-clamp-2">{sol.lugar}</span></td>
                      <td className="max-w-xs px-3 py-2 text-slate-200"><span className="line-clamp-2">{sol.caratula}</span></td>
                      <td className="px-3 py-2">
                        <span className={[
                          'inline-flex items-center rounded-full px-2 py-0.5 text-[11px] font-medium',
                          sol.estado === 'pendiente' ? 'bg-amber-500/15 text-amber-300 ring-1 ring-amber-400/40' : 'bg-emerald-500/15 text-emerald-300 ring-1 ring-emerald-400/40',
                        ].join(' ')}>
                          {sol.estado === 'pendiente' ? 'Pendiente' : 'Finalizada'}
                        </span>
                      </td>
                      <td className="px-3 py-2 text-slate-300"><span className="line-clamp-2">{sol.creador}</span></td>
                      <td className="px-3 py-2">
                        <div className="flex justify-end gap-1.5">
                          {/* Navegar al detalle */}
                          <button
                            type="button"
                            aria-label="Ver detalle"
                            className="inline-flex h-7 w-7 items-center justify-center rounded-md bg-slate-800 text-slate-100 hover:bg-slate-700"
                            onClick={() => handleOpenDetail(sol)}
                          >
                            <Eye className="h-3.5 w-3.5" />
                            <span className="sr-only">Ver detalle</span>
                          </button>

                          <button
                            type="button"
                            disabled={!sol.hasAdjuntos}
                            className="inline-flex h-7 w-7 items-center justify-center rounded-md bg-slate-800 text-slate-100 hover:bg-slate-700 disabled:cursor-not-allowed disabled:opacity-40"
                            onClick={() => {
                              // Abrir modal de attachments relacionados a la solicitud (por id)
                              setAttachmentsForSolicitudId(sol.id)
                            }}
                          >
                            <Paperclip className="h-3.5 w-3.5" />
                            <span className="sr-only">Ver archivos adjuntos</span>
                          </button>

                          <button
                            type="button"
                            disabled={sol.estado !== 'pendiente'}
                            className="inline-flex h-7 w-7 items-center justify-center rounded-md bg-slate-800 text-slate-100 hover:bg-slate-700 disabled:cursor-not-allowed disabled:opacity-40"
                            onClick={() => {
                              window.alert('Formulario de nuevo relevamiento se vinculará aquí.')
                            }}
                          >
                            <ClipboardList className="h-3.5 w-3.5" />
                            <span className="sr-only">Relevar</span>
                          </button>

                          <button
                            type="button"
                            disabled={sol.estado !== 'finalizada'}
                            className="inline-flex h-7 w-7 items-center justify-center rounded-md bg-slate-800 text-slate-100 hover:bg-slate-700 disabled:cursor-not-allowed disabled:opacity-40"
                            onClick={() => {
                              // Navegar a la vista de informe asociado a esta solicitud.
                              // Nota: en el dataset de demo el informe suele mapear por el mismo id de solicitud.
                              // Si en tu implementación real la relación es diferente (ej. relevamientoId),
                              // reemplazar por la búsqueda adecuada en el store de relevamientos.
                              handleOpenInforme(sol)
                            }}
                          >
                            <FileText className="h-3.5 w-3.5" />
                            <span className="sr-only">Ver informe</span>
                          </button>

                          <button
                            type="button"
                            className="inline-flex h-7 w-7 items-center justify-center rounded-md bg-slate-800 text-slate-100 hover:bg-slate-700"
                            onClick={() => handleOpenEdit(sol)}
                          >
                            <Pencil className="h-3.5 w-3.5" />
                            <span className="sr-only">Editar</span>
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {editingSolicitud && (
        <EditSolicitudModal
          solicitud={editingSolicitud}
          onClose={() => setEditingSolicitud(null)}
          onSaved={handleSaved}
        />
      )}

      {attachmentsForSolicitudId !== null && (
        <SolicitudAttachmentsModal
          open={attachmentsForSolicitudId !== null}
          solicitudId={attachmentsForSolicitudId}
          onClose={() => setAttachmentsForSolicitudId(null)}
        />
      )}
    </AppLayout>
  )
}