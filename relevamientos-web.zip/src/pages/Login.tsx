/**
 * @file Login.tsx
 * @description Pantalla de inicio de sesión con número de legajo y contraseña.
 */

import { FormEvent, useState } from 'react'
import { useNavigate } from 'react-router'
import { useSystemUser } from '../context/SystemUserContext'

/**
 * LoginPage
 * @description Permite autenticarse usando número de legajo y contraseña (sin Google).
 */
export default function LoginPage() {
  const [legajo, setLegajo] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState<string | null>(null)
  const [isSubmitting, setIsSubmitting] = useState(false)

  const { loginWithCredentials, isLoading } = useSystemUser()
  const navigate = useNavigate()

  /**
   * handleSubmit
   * @description Valida el formulario de login en el frontend y simula envío.
   */
  const handleSubmit = async (event: FormEvent) => {
    event.preventDefault()
    setError(null)

    if (!legajo.trim() || !password.trim()) {
      setError('Debe ingresar número de legajo y contraseña.')
      return
    }

    if (password.length < 6) {
      setError('La contraseña debe tener al menos 6 caracteres.')
      return
    }

    setIsSubmitting(true)

    try {
      await loginWithCredentials(legajo, password)
      navigate('/dashboard')
    } catch (err) {
      const message =
        err instanceof Error
          ? err.message
          : 'No se pudo iniciar sesión. Intente nuevamente.'
      setError(message)
    } finally {
      setIsSubmitting(false)
    }
  }

  const isBusy = isSubmitting || isLoading

  return (
    <div className="min-h-screen bg-gradient-to-br from-sky-900 via-slate-900 to-sky-800 flex items-center justify-center px-4">
      <div className="w-full max-w-md">
        <div className="bg-white/95 rounded-xl shadow-xl border border-slate-200 px-8 py-10 space-y-8">
          <header className="space-y-2 text-center">
            <p className="text-xs font-semibold tracking-[0.2em] text-sky-700 uppercase">
              Ministerio de Seguridad
            </p>
            <h1 className="text-2xl font-bold text-slate-900">
              Sistema de Gestión de Relevamientos
            </h1>
            <p className="text-xs text-slate-500">
              Provincia de Buenos Aires
            </p>
          </header>

          <form className="space-y-6" onSubmit={handleSubmit} noValidate>
            <div className="space-y-4">
              <div className="space-y-1.5">
                <label
                  htmlFor="legajo"
                  className="block text-sm font-medium text-slate-700"
                >
                  Número de legajo
                </label>
                <input
                  id="legajo"
                  type="text"
                  inputMode="numeric"
                  autoComplete="username"
                  className="block w-full rounded-md border border-slate-300 px-3 py-2 text-sm shadow-sm focus:border-sky-600 focus:outline-none focus:ring-2 focus:ring-sky-500 focus:ring-offset-1"
                  placeholder="Ej: 12345"
                  value={legajo}
                  onChange={(e) => setLegajo(e.target.value)}
                />
              </div>

              <div className="space-y-1.5">
                <label
                  htmlFor="password"
                  className="block text-sm font-medium text-slate-700"
                >
                  Contraseña
                </label>
                <input
                  id="password"
                  type="password"
                  autoComplete="current-password"
                  className="block w-full rounded-md border border-slate-300 px-3 py-2 text-sm shadow-sm focus:border-sky-600 focus:outline-none focus:ring-2 focus:ring-sky-500 focus:ring-offset-1"
                  placeholder="Mínimo 6 caracteres"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                />
              </div>
            </div>

            {error && (
              <p className="text-sm text-red-600 bg-red-50 border border-red-200 rounded-md px-3 py-2">
                {error}
              </p>
            )}

            <button
              type="submit"
              disabled={isBusy}
              className="inline-flex w-full items-center justify-center rounded-md bg-sky-700 px-4 py-2.5 text-sm font-semibold text-white shadow-sm hover:bg-sky-800 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-500 focus-visible:ring-offset-1 disabled:cursor-not-allowed disabled:opacity-70"
            >
              {isBusy ? 'Verificando…' : 'Iniciar sesión'}
            </button>
          </form>

          <div className="space-y-2 text-center">
            <p className="text-[11px] leading-snug text-slate-500">
              El acceso se realiza únicamente con número de legajo y contraseña
              asignada por el administrador del sistema.
            </p>
            <p className="text-[11px] leading-snug text-slate-500">
              Para pruebas de esta versión:
              <br />
              <span className="font-semibold text-slate-700">
                Legajo: 1000 · Contraseña: admin123
              </span>
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}
