-- /**
--  * @file seed_demo.sql
--  * @description Semilla mínima para entorno local SQLite: dependencias, jerarquías y usuarios de prueba.
--  *              Ejecutar después de las migraciones principales.
--  */

BEGIN TRANSACTION;

-- Dependencias de ejemplo
INSERT OR IGNORE INTO dependencias (nombre, descripcion) VALUES
('Dependencia central', 'Unidad central del SGR'),
('Comisaría 1ra. La Plata', 'Comisaría de prueba');

-- Jerarquías de ejemplo
INSERT OR IGNORE INTO jerarquias (nombre, orden) VALUES
('Crio. Mayor', 1),
('Of. Ppal.', 2),
('Sgto.', 3);

-- Usuarios demo (password_hash dejado vacío para que el developer establezca la contraseña de forma segura)
INSERT OR IGNORE INTO usuarios (numero_legajo, nombre, apellido, jerarquia, tipo_usuario, telefono, email, dependencia_id, is_active, password_hash)
VALUES
('1000','Admin','Demo','Crio. Mayor','administrador','221-000-0000','admin.demo@sgr.test', NULL, 1, ''),
('2000','Ana','Secretaria','Of. Ppal.','secretario','221-111-1111','ana.secretaria@sgr.test', (SELECT id FROM dependencias WHERE nombre='Comisaría 1ra. La Plata'), 1, ''),
('3000','Carlos','Relevador','Sgto.','relevador','221-222-2222','carlos.relevador@sgr.test', (SELECT id FROM dependencias WHERE nombre='Comisaría 1ra. La Plata'), 1, '');

COMMIT;