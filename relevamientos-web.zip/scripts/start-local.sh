#!/usr/bin/env bash
# scripts/start-local.sh
# Script para entorno de desarrollo local:
# - Ejecuta migraciones/seed en ./data/sgr.sqlite
# - Recomienda/inicia Miniflare para servir el Worker en http://localhost:8787
#
# Requisitos: sqlite3 CLI, node, npm. Miniflare se puede instalar globalmente: npm i -g miniflare
set -e

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
DB_PATH="${SGR_SQLITE_PATH:-$ROOT/data/sgr.sqlite}"

echo "Ruta DB: $DB_PATH"

echo "1) Aplicando migraciones y seed..."
"$ROOT/scripts/migrate-sqlite.sh" "$DB_PATH" "$ROOT/src/worker/migrations/001_init.sql" "$ROOT/scripts/seed_demo.sql"

echo "DB creada/actualizada en: $DB_PATH"

if command -v miniflare >/dev/null 2>&1; then
  echo "2) Iniciando Miniflare en http://0.0.0.0:8787"
  # exportar variable para proceso child
  export SGR_SQLITE_PATH="$DB_PATH"
  npx miniflare --watch src/worker/index.ts --host 0.0.0.0 --port 8787
else
  echo "Miniflare no instalado. Instalar con: npm i -g miniflare"
  echo "O ejecutar manualmente:"
  echo "  env SGR_SQLITE_PATH=\"$DB_PATH\" npx miniflare --watch src/worker/index.ts --host 0.0.0.0 --port 8787"
fi