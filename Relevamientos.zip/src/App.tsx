/**
 * @file App.tsx
 * @description Componente raíz de la aplicación que define las rutas principales del SGR.
 *              Adaptado para dispositivos con recursos limitados (Pi 3):
 *               - Lazy-load de páginas para reducir memoria inicial
 *               - Health-check al backend usando cliente API configurable (mocks / real)
 */

import React, { Suspense, useEffect, useState } from 'react'
import { HashRouter, Route, Routes } from 'react-router'
import { SystemUserProvider } from './context/SystemUserContext'
import { Toaster } from 'sonner'
import { healthCheck } from './lib/apiClient'
import HomePage from './pages/Home'

/**
 * Lazy-loaded pages to reduce initial bundle and memory pressure on low-RAM devices.
 * Each import is a dynamic chunk loaded on demand.
 */
const LoginPage = React.lazy(() => import('./pages/Login'))
const DashboardPage = React.lazy(() => import('./pages/Dashboard'))
const SolicitudesPage = React.lazy(() => import('./pages/Solicitudes'))
const NuevaSolicitudPage = React.lazy(() => import('./pages/NuevaSolicitud'))
const SolicitudDetallePage = React.lazy(() => import('./pages/SolicitudDetalle'))
const RelevamientosPage = React.lazy(() => import('./pages/Relevamientos'))
const NuevoRelevamientoPage = React.lazy(() => import('./pages/NuevoRelevamiento'))
const InformeRelevamientoPage = React.lazy(() => import('./pages/InformeRelevamiento'))
const UsuariosPage = React.lazy(() => import('./pages/Usuarios'))
const DependenciasPage = React.lazy(() => import('./pages/Dependencias'))
const JerarquiasPage = React.lazy(() => import('./pages/Jerarquias'))
const EstadisticasPage = React.lazy(() => import('./pages/Estadisticas'))
const NotificacionesPage = React.lazy(() => import('./pages/Notificaciones'))

/**
 * App
 * @description Configura el enrutador y las rutas de alto nivel del SGR.
 */
export default function App() {
  const [backendHealthy, setBackendHealthy] = useState<boolean | null>(null)
  const [migrating, setMigrating] = useState(false)

  useEffect(() => {
    let mounted = true
    async function check() {
      const ok = await healthCheck()
      if (mounted) setBackendHealthy(ok)
      // re-check cada 30s si está fallando (intenta recuperar)
      if (!ok) {
        setTimeout(check, 30000)
      }
    }
    check()
    return () => {
      mounted = false
    }
  }, [])

  /**
   * Ejecuta /migrate automáticamente si se configura para hacerlo en runtime.
   * - globalThis.__ENV__.RUN_MIGRATE_ON_START === '1'|'true'
   * - o localStorage.SGR_RUN_MIGRATE === 'true'
   * Solo se ejecuta cuando los mocks están desactivados.
   */
  useEffect(() => {
    async function tryAutoMigrate() {
      try {
        let runMigrate = false
        try {
          const g: any = (globalThis as any) || {}
          if (g.__ENV__ && (g.__ENV__.RUN_MIGRATE_ON_START === '1' || String(g.__ENV__.RUN_MIGRATE_ON_START).toLowerCase() === 'true')) {
            runMigrate = true
          }
        } catch {}
        try {
          const ls = localStorage.getItem('SGR_RUN_MIGRATE')
          if (ls === 'true') runMigrate = true
        } catch {}
        // Determinar effective mocks
        let effectiveMocks = false
        try {
          const ls = localStorage.getItem('SGR_USE_MOCKS_OVERRIDE')
          if (ls === 'true') effectiveMocks = true
          else if (ls === 'false') effectiveMocks = false
          else effectiveMocks = false
        } catch {
          effectiveMocks = false
        }

        if (runMigrate && !effectiveMocks) {
          setMigrating(true)
          await migrateDb()
          setMigrating(false)
          // refrescar health
          const ok = await healthCheck()
          setBackendHealthy(ok)
        }
      } catch (err) {
        console.warn('auto migrate failed', err)
        setMigrating(false)
      }
    }

    tryAutoMigrate()
  }, [])

  return (
    <SystemUserProvider>
      {/* Toaster global para notificaciones (sonner) */}
      <Toaster position="top-right" />
      {/* Indicador discreto en consola y comentario en DOM para debugging; evitar UI pesada */}
      <div aria-hidden style={{ position: 'absolute', left: -9999 }}>
        {backendHealthy === false ? 'BACKEND_OFFLINE' : backendHealthy === true ? 'BACKEND_OK' : 'BACKEND_UNKNOWN'}
      </div>

      <HashRouter>
        <Suspense fallback={<div className="p-6 text-center">Cargando...</div>}>
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/login" element={<LoginPage />} />
            <Route path="/dashboard" element={<DashboardPage />} />
            <Route path="/estadisticas" element={<EstadisticasPage />} />
            <Route path="/solicitudes" element={<SolicitudesPage />} />
            <Route path="/solicitudes/nueva" element={<NuevaSolicitudPage />} />
            <Route path="/solicitudes/:id" element={<SolicitudDetallePage />} />
            <Route path="/relevamientos" element={<RelevamientosPage />} />
            <Route path="/relevamientos/nuevo" element={<NuevoRelevamientoPage />} />
            <Route path="/relevamientos/:id/informe" element={<InformeRelevamientoPage />} />
            <Route path="/usuarios" element={<UsuariosPage />} />
            <Route path="/dependencias" element={<DependenciasPage />} />
            <Route path="/jerarquias" element={<JerarquiasPage />} />
            <Route path="/notificaciones" element={<NotificacionesPage />} />
          </Routes>
        </Suspense>
      </HashRouter>
    </SystemUserProvider>
  )
}