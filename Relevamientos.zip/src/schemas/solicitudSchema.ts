/**
 * @file solicitudSchema.ts
 * @description Esquema Zod y tipos relacionados para validar datos de solicitud.
 */

import { z } from 'zod'

/**
 * CreateSolicitudSchema
 * @description Esquema Zod para la creación/edición de una solicitud mínima.
 */
export const CreateSolicitudSchema = z.object({
  ipp: z.string().min(3, 'El número de IPP debe tener al menos 3 caracteres.'),
  fiscalia: z.string().min(3, 'La fiscalía debe tener al menos 3 caracteres.'),
  caratula: z.string().min(5, 'La carátula debe tener al menos 5 caracteres.'),
  lugar: z.string().min(5, 'El lugar debe ser más descriptivo.'),
  resumen: z.string().min(10, 'El resumen debe tener al menos 10 caracteres.'),
  hasAdjuntos: z.boolean().optional(),
  dependenciaId: z.number().nullable().optional(),
  lat: z.number().nullable().optional(),
  lng: z.number().nullable().optional(),
})

/**
 * CreateSolicitudInput
 * @description Tipo TypeScript inferido del esquema de creación de solicitud.
 */
export type CreateSolicitudInput = z.infer<typeof CreateSolicitudSchema>