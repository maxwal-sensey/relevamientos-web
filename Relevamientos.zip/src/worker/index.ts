/**
 * @file src/worker/index.ts
 * @description Cloudflare Worker (Hono) que expone API CRUD para mensajes, usuarios,
 *              dependencias y jerarquías usando D1 (o adapter local SQLite3 CLI).
 *
 * Rutas nuevas añadidas en esta versión:
 *  - /api/users           GET, POST, PUT, DELETE
 *  - /api/dependencias    GET, POST, PUT, DELETE
 *  - /api/jerarquias      GET, POST, PUT, DELETE
 *
 * Nota:
 *  - El adaptador getDb(c) intenta usar c.env.SGR_DB (D1). Si no está disponible,
 *    ejecuta sqlite3 CLI contra el archivo ./data/sgr.sqlite (solo desarrollo).
 *  - Para simplicidad, el hash de contraseña se almacena tal cual cuando se envía.
 *    En producción se debe hashear en el backend de forma segura.
 */

import { Hono } from 'hono'
import { type Context } from 'hono'

/**
 * Env
 * @description Typings de bindings que el Worker espera recibir.
 */
interface Env {
  R2_BUCKET?: any
  SGR_DB?: any
}

/**
 * quoteParam
 * @description Escapa/serializa parámetros para inyección segura en el adapter local.
 *              Uso limitado al adapter local; en D1 los bindings usan binding.execute.
 */
function quoteParam(p: any): string {
  if (p === null || typeof p === 'undefined') return 'NULL'
  if (typeof p === 'number' || (typeof p === 'string' && /^\d+(\.\d+)?$/.test(p))) return String(p)
  const s = String(p).replace(/'/g, "''")
  return `'${s}'`
}

/**
 * getDb
 * @description Crea un cliente DB compatible con las llamadas que usa el Worker.
 *              Si el binding D1 (c.env.SGR_DB) existe, se retorna directamente.
 *              En otro caso se crea un adaptador que ejecuta sqlite3 CLI contra un archivo local.
 * @param c Context del handler
 */
function getDb(c: Context<{ Bindings: Env }>) {
  // Si existe binding D1 -> usarlo (Cloudflare)
  try {
    const maybe = (c.env as any)?.SGR_DB
    if (maybe && typeof maybe.prepare === 'function') {
      return maybe
    }
  } catch {
    // continuar a adapter local
  }

  // Local adapter usando sqlite3 CLI
  const path = (process && (process.env.SGR_SQLITE_PATH as string)) || 'data/sgr.sqlite'

  /**
   * @description Reemplaza de forma secuencial cada ? por el parámetro correspondiente.
   */
  function sqlWithParams(sql: string, params: any[] = []) {
    let i = 0
    return sql.replace(/\?/g, () => {
      const p = params[i++]
      return quoteParam(p)
    })
  }

  /**
   * @description Ejecuta SQL usando sqlite3 CLI y retorna el stdout.
   */
  function execSqlRaw(finalSql: string) {
    try {
      // require dinámico para evitar errores en entorno Worker
      // eslint-disable-next-line @typescript-eslint/no-var-requires
      const child = require('child_process')
      // Usar opción -json si está disponible (sqlite3 >= 3.38). Si no, intentar ejecutar igualmente.
      const args = [path, '-json', finalSql]
      const proc = child.spawnSync('sqlite3', args, { encoding: 'utf8' })
      if (proc.error) {
        throw proc.error
      }
      // stdout puede venir vacío
      return proc.stdout || ''
    } catch (err) {
      throw err
    }
  }

  return {
    /**
     * @description Prepara una sentencia SQL.
     * @param sql string
     */
    prepare(sql: string) {
      return {
        /**
         * @description Bind de parámetros. Devuelve objeto con all() y run().
         */
        bind(...params: any[]) {
          return {
            /**
             * @description Ejecuta query y retorna { results: [...] } para compatibilidad.
             */
            async all() {
              const q = sqlWithParams(sql, params)
              const out = execSqlRaw(q)
              try {
                const parsed = out ? JSON.parse(out) : []
                return { results: parsed }
              } catch (e) {
                return { results: [] }
              }
            },
            /**
             * @description Ejecuta statement tipo INSERT/UPDATE/DELETE.
             */
            async run() {
              const q = sqlWithParams(sql, params)
              const out = execSqlRaw(q)
              try {
                const parsed = out ? JSON.parse(out) : []
                return { results: parsed }
              } catch {
                return { results: [] }
              }
            },
          }
        },
      }
    },
  }
}

/**
 * jsonResponse
 * @description Helper para respuestas JSON con CORS básico.
 */
function jsonResponse(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: {
      'content-type': 'application/json;charset=utf-8',
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type',
    },
  })
}

const app = new Hono<{ Bindings: Env }>()

/**
 * ensureSchema
 * @description Crea tablas necesarias si no existen (idempotente).
 *              Ejecutar al inicio de cada petición para asegurar persistencia.
 * @param c Context
 */
async function ensureSchema(c: Context<{ Bindings: Env }>) {
  const db = getDb(c)
  // users table
  await db
    .prepare(
      `CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        legajo TEXT NOT NULL UNIQUE,
        nombre TEXT NOT NULL,
        apellido TEXT NOT NULL,
        jerarquia TEXT,
        rol TEXT NOT NULL,
        dependencia_id INTEGER,
        dependencia_nombre TEXT,
        telefono TEXT,
        email TEXT,
        is_active INTEGER DEFAULT 1,
        password_hash TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )`
    )
    .bind()
    .run()

  // dependencias table
  await db
    .prepare(
      `CREATE TABLE IF NOT EXISTS dependencias (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nombre TEXT NOT NULL UNIQUE,
        descripcion TEXT,
        cantidad_usuarios INTEGER DEFAULT 0,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )`
    )
    .bind()
    .run()

  // jerarquias table
  await db
    .prepare(
      `CREATE TABLE IF NOT EXISTS jerarquias (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nombre TEXT NOT NULL UNIQUE,
        orden INTEGER DEFAULT 0,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )`
    )
    .bind()
    .run()

  // messages + attachments already expected elsewhere; leave untouched
}

/**
 * OPTIONS handler (CORS preflight)
 */
app.options('/api/*', (c) => {
  return new Response(null, {
    status: 204,
    headers: {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type',
    },
  })
})

/**
 * Health check
 */
app.get('/health', (c) => {
  return jsonResponse({ ok: true })
})

/**
 * ---------------------
 * Users CRUD
 * ---------------------
 */

/**
 * GET /api/users
 * @description Lista usuarios
 */
app.get('/api/users', async (c) => {
  try {
    await ensureSchema(c)
    const db = getDb(c)
    const res = await db
      .prepare(
        `SELECT id, legajo, nombre, apellido, jerarquia, rol, dependencia_id as dependenciaId, dependencia_nombre as dependenciaNombre, telefono, email, is_active as isActive, created_at, updated_at FROM users ORDER BY id DESC`
      )
      .bind()
      .all()
    const users = res.results || []
    return jsonResponse({ ok: true, users })
  } catch (err) {
    console.error('GET /api/users error:', err)
    return jsonResponse({ error: 'Error listando usuarios', details: String(err) }, 500)
  }
})

/**
 * POST /api/users
 * @description Crea un usuario. Espera JSON:
 *  { legajo, nombre, apellido, jerarquia, rol, dependenciaId, dependenciaNombre, telefono, email, isActive, password }
 */
app.post('/api/users', async (c) => {
  try {
    await ensureSchema(c)
    const payload = await c.req.json()
    const {
      legajo,
      nombre,
      apellido,
      jerarquia,
      rol,
      dependenciaId,
      dependenciaNombre,
      telefono,
      email,
      isActive,
      password,
    } = payload

    if (!legajo || !nombre || !apellido || !rol) {
      return jsonResponse({ error: 'Campos obligatorios faltantes: legajo, nombre, apellido, rol' }, 400)
    }

    // Nota: en producción hashear password en backend. Aquí almacenamos tal cual (no recomendado).
    const passwordHash = password ? String(password) : null

    const db = getDb(c)
    const insertSql =
      `INSERT INTO users (legajo, nombre, apellido, jerarquia, rol, dependencia_id, dependencia_nombre, telefono, email, is_active, password_hash) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) RETURNING id`
    const insertRes = await db
      .prepare(insertSql)
      .bind(
        legajo,
        nombre,
        apellido,
        jerarquia ?? null,
        rol,
        dependenciaId ?? null,
        dependenciaNombre ?? null,
        telefono ?? null,
        email ?? null,
        isActive ? 1 : 0,
        passwordHash
      )
      .all()
    const inserted = (insertRes.results && insertRes.results[0]) || null

    let newId = inserted?.id ?? null
    if (!newId) {
      // Fallback: buscar por legajo
      const sel = await db.prepare(`SELECT id FROM users WHERE legajo = ? ORDER BY id DESC LIMIT 1`).bind(legajo).all()
      newId = sel.results && sel.results[0] ? sel.results[0].id : null
    }

    if (!newId) {
      return jsonResponse({ error: 'No se pudo crear usuario' }, 500)
    }

    const rowRes = await db.prepare(`SELECT id, legajo, nombre, apellido, jerarquia, rol, dependencia_id as dependenciaId, dependencia_nombre as dependenciaNombre, telefono, email, is_active as isActive, created_at, updated_at FROM users WHERE id = ?`).bind(newId).all()
    const row = rowRes.results && rowRes.results[0] ? rowRes.results[0] : null

    return jsonResponse({ ok: true, user: row })
  } catch (err) {
    console.error('POST /api/users error:', err)
    return jsonResponse({ error: 'Error creando usuario', details: String(err) }, 500)
  }
})

/**
 * PUT /api/users/:id
 * @description Actualiza un usuario parcialmente
 */
app.put('/api/users/:id', async (c) => {
  try {
    await ensureSchema(c)
    const id = Number(c.req.param('id'))
    const payload = await c.req.json()
    const fields: string[] = []
    const params: any[] = []

    const allowed = ['legajo','nombre','apellido','jerarquia','rol','dependenciaId','dependenciaNombre','telefono','email','isActive','password']
    for (const key of allowed) {
      if (key in payload) {
        if (key === 'dependenciaId') {
          fields.push(`dependencia_id = ?`)
          params.push(payload[key])
        } else if (key === 'dependenciaNombre') {
          fields.push(`dependencia_nombre = ?`)
          params.push(payload[key])
        } else if (key === 'isActive') {
          fields.push(`is_active = ?`)
          params.push(payload[key] ? 1 : 0)
        } else if (key === 'password') {
          // Nota: almacenar password tal cual; en producción hashear.
          fields.push(`password_hash = ?`)
          params.push(payload[key] ?? null)
        } else {
          fields.push(`${key} = ?`)
          params.push(payload[key])
        }
      }
    }

    if (fields.length === 0) {
      return jsonResponse({ error: 'No hay campos a actualizar' }, 400)
    }

    params.push(id)
    const sql = `UPDATE users SET ${fields.join(', ')}, updated_at = CURRENT_TIMESTAMP WHERE id = ?`
    const db = getDb(c)
    await db.prepare(sql).bind(...params).run()

    const rowRes = await db.prepare(`SELECT id, legajo, nombre, apellido, jerarquia, rol, dependencia_id as dependenciaId, dependencia_nombre as dependenciaNombre, telefono, email, is_active as isActive, created_at, updated_at FROM users WHERE id = ?`).bind(id).all()
    const row = rowRes.results && rowRes.results[0] ? rowRes.results[0] : null

    return jsonResponse({ ok: true, user: row })
  } catch (err) {
    console.error('PUT /api/users/:id error:', err)
    return jsonResponse({ error: 'Error actualizando usuario', details: String(err) }, 500)
  }
})

/**
 * DELETE /api/users/:id
 */
app.delete('/api/users/:id', async (c) => {
  try {
    await ensureSchema(c)
    const id = Number(c.req.param('id'))
    const db = getDb(c)
    await db.prepare(`DELETE FROM users WHERE id = ?`).bind(id).run()
    return jsonResponse({ ok: true })
  } catch (err) {
    console.error('DELETE /api/users/:id error:', err)
    return jsonResponse({ error: 'Error eliminando usuario', details: String(err) }, 500)
  }
})

/**
 * ---------------------
 * Dependencias CRUD
 * ---------------------
 */

/**
 * GET /api/dependencias
 */
app.get('/api/dependencias', async (c) => {
  try {
    await ensureSchema(c)
    const db = getDb(c)
    const res = await db.prepare(`SELECT id, nombre, descripcion, cantidad_usuarios as cantidadUsuarios, created_at FROM dependencias ORDER BY nombre COLLATE NOCASE`).bind().all()
    const deps = res.results || []
    return jsonResponse({ ok: true, dependencias: deps })
  } catch (err) {
    console.error('GET /api/dependencias error:', err)
    return jsonResponse({ error: 'Error listando dependencias', details: String(err) }, 500)
  }
})

/**
 * POST /api/dependencias
 */
app.post('/api/dependencias', async (c) => {
  try {
    await ensureSchema(c)
    const payload = await c.req.json()
    const { nombre, descripcion } = payload
    if (!nombre) return jsonResponse({ error: 'Nombre obligatorio' }, 400)
    const db = getDb(c)
    const insertRes = await db.prepare(`INSERT INTO dependencias (nombre, descripcion) VALUES (?, ?) RETURNING id`).bind(nombre, descripcion ?? null).all()
    let newId = insertRes.results && insertRes.results[0] && insertRes.results[0].id ? insertRes.results[0].id : null
    if (!newId) {
      const sel = await db.prepare(`SELECT id FROM dependencias WHERE nombre = ? ORDER BY id DESC LIMIT 1`).bind(nombre).all()
      newId = sel.results && sel.results[0] ? sel.results[0].id : null
    }
    const rowRes = await db.prepare(`SELECT id, nombre, descripcion, cantidad_usuarios as cantidadUsuarios, created_at FROM dependencias WHERE id = ?`).bind(newId).all()
    const row = rowRes.results && rowRes.results[0] ? rowRes.results[0] : null
    return jsonResponse({ ok: true, dependencia: row })
  } catch (err) {
    console.error('POST /api/dependencias error:', err)
    return jsonResponse({ error: 'Error creando dependencia', details: String(err) }, 500)
  }
})

/**
 * PUT /api/dependencias/:id
 */
app.put('/api/dependencias/:id', async (c) => {
  try {
    await ensureSchema(c)
    const id = Number(c.req.param('id'))
    const payload = await c.req.json()
    const fields: string[] = []
    const params: any[] = []
    if ('nombre' in payload) {
      fields.push('nombre = ?')
      params.push(payload.nombre)
    }
    if ('descripcion' in payload) {
      fields.push('descripcion = ?')
      params.push(payload.descripcion)
    }
    if (fields.length === 0) return jsonResponse({ error: 'No hay campos a actualizar' }, 400)
    params.push(id)
    const db = getDb(c)
    await db.prepare(`UPDATE dependencias SET ${fields.join(', ')}, updated_at = CURRENT_TIMESTAMP WHERE id = ?`).bind(...params).run()
    const rowRes = await db.prepare(`SELECT id, nombre, descripcion, cantidad_usuarios as cantidadUsuarios, created_at FROM dependencias WHERE id = ?`).bind(id).all()
    const row = rowRes.results && rowRes.results[0] ? rowRes.results[0] : null
    return jsonResponse({ ok: true, dependencia: row })
  } catch (err) {
    console.error('PUT /api/dependencias/:id error:', err)
    return jsonResponse({ error: 'Error actualizando dependencia', details: String(err) }, 500)
  }
})

/**
 * DELETE /api/dependencias/:id
 */
app.delete('/api/dependencias/:id', async (c) => {
  try {
    await ensureSchema(c)
    const id = Number(c.req.param('id'))
    const db = getDb(c)
    await db.prepare(`DELETE FROM dependencias WHERE id = ?`).bind(id).run()
    return jsonResponse({ ok: true })
  } catch (err) {
    console.error('DELETE /api/dependencias/:id error:', err)
    return jsonResponse({ error: 'Error eliminando dependencia', details: String(err) }, 500)
  }
})

/**
 * ---------------------
 * Jerarquias CRUD
 * ---------------------
 */

/**
 * GET /api/jerarquias
 */
app.get('/api/jerarquias', async (c) => {
  try {
    await ensureSchema(c)
    const db = getDb(c)
    const res = await db.prepare(`SELECT id, nombre, orden, created_at FROM jerarquias ORDER BY orden ASC`).bind().all()
    const list = res.results || []
    return jsonResponse({ ok: true, jerarquias: list })
  } catch (err) {
    console.error('GET /api/jerarquias error:', err)
    return jsonResponse({ error: 'Error listando jerarquías', details: String(err) }, 500)
  }
})

/**
 * POST /api/jerarquias
 */
app.post('/api/jerarquias', async (c) => {
  try {
    await ensureSchema(c)
    const payload = await c.req.json()
    const { nombre, orden } = payload
    if (!nombre) return jsonResponse({ error: 'Nombre obligatorio' }, 400)
    const db = getDb(c)
    const insertRes = await db.prepare(`INSERT INTO jerarquias (nombre, orden) VALUES (?, ?) RETURNING id`).bind(nombre, orden ?? 0).all()
    let newId = insertRes.results && insertRes.results[0] && insertRes.results[0].id ? insertRes.results[0].id : null
    if (!newId) {
      const sel = await db.prepare(`SELECT id FROM jerarquias WHERE nombre = ? ORDER BY id DESC LIMIT 1`).bind(nombre).all()
      newId = sel.results && sel.results[0] ? sel.results[0].id : null
    }
    const rowRes = await db.prepare(`SELECT id, nombre, orden, created_at FROM jerarquias WHERE id = ?`).bind(newId).all()
    const row = rowRes.results && rowRes.results[0] ? rowRes.results[0] : null
    return jsonResponse({ ok: true, jerarquia: row })
  } catch (err) {
    console.error('POST /api/jerarquias error:', err)
    return jsonResponse({ error: 'Error creando jerarquía', details: String(err) }, 500)
  }
})

/**
 * PUT /api/jerarquias/:id
 */
app.put('/api/jerarquias/:id', async (c) => {
  try {
    await ensureSchema(c)
    const id = Number(c.req.param('id'))
    const payload = await c.req.json()
    const fields: string[] = []
    const params: any[] = []
    if ('nombre' in payload) {
      fields.push('nombre = ?')
      params.push(payload.nombre)
    }
    if ('orden' in payload) {
      fields.push('orden = ?')
      params.push(payload.orden)
    }
    if (fields.length === 0) return jsonResponse({ error: 'No hay campos a actualizar' }, 400)
    params.push(id)
    const db = getDb(c)
    await db.prepare(`UPDATE jerarquias SET ${fields.join(', ')}, updated_at = CURRENT_TIMESTAMP WHERE id = ?`).bind(...params).run()
    const rowRes = await db.prepare(`SELECT id, nombre, orden, created_at FROM jerarquias WHERE id = ?`).bind(id).all()
    const row = rowRes.results && rowRes.results[0] ? rowRes.results[0] : null
    return jsonResponse({ ok: true, jerarquia: row })
  } catch (err) {
    console.error('PUT /api/jerarquias/:id error:', err)
    return jsonResponse({ error: 'Error actualizando jerarquía', details: String(err) }, 500)
  }
})

/**
 * DELETE /api/jerarquias/:id
 */
app.delete('/api/jerarquias/:id', async (c) => {
  try {
    await ensureSchema(c)
    const id = Number(c.req.param('id'))
    const db = getDb(c)
    await db.prepare(`DELETE FROM jerarquias WHERE id = ?`).bind(id).run()
    return jsonResponse({ ok: true })
  } catch (err) {
    console.error('DELETE /api/jerarquias/:id error:', err)
    return jsonResponse({ error: 'Error eliminando jerarquía', details: String(err) }, 500)
  }
})

/**
 * Mantener rutas previas para mensajes (GET/POST /api/messages) tal cual están en este worker.
 * Para no duplicar código aquí, mantenemos el manejo anterior de mensajes ya presente en el proyecto.
 */

export default app.handle