/**
 * @file DeviceContext.tsx
 * @description Contexto para detectar tipo de dispositivo (móvil / tablet / desktop) y dimensiones de viewport.
 */

import React, { createContext, useContext, useEffect, useState, ReactNode } from 'react'

/**
 * DeviceInfo
 * @description Información expuesta por el contexto de dispositivo.
 */
export interface DeviceInfo {
  /** Indica si se considera un dispositivo móvil (pequeña pantalla). */
  isMobile: boolean
  /** Indica si se considera una tablet. */
  isTablet: boolean
  /** Ancho de la ventana en píxeles. */
  viewportWidth: number
  /** Alto de la ventana en píxeles. */
  viewportHeight: number
}

/**
 * DeviceContextValue
 * @description Valor por defecto del contexto.
 */
const DEFAULT: DeviceInfo = {
  isMobile: false,
  isTablet: false,
  viewportWidth: typeof window !== 'undefined' ? window.innerWidth : 1024,
  viewportHeight: typeof window !== 'undefined' ? window.innerHeight : 768,
}

const DeviceContext = createContext<DeviceInfo>(DEFAULT)

/**
 * DeviceProviderProps
 * @description Propiedades del proveedor de contexto de dispositivo.
 */
interface DeviceProviderProps {
  children: ReactNode
}

/**
 * detectMobileByUA
 * @description Heurística simple basada en userAgent para casos donde matchMedia no esté disponible.
 */
function detectMobileByUA() {
  if (typeof navigator === 'undefined') return false
  const ua = navigator.userAgent || navigator.vendor || (window as any).opera
  return /Android|iPhone|iPad|iPod|Windows Phone/i.test(ua)
}

/**
 * DeviceProvider
 * @description Proveedor que detecta cambios de tamaño y media queries para exponer info de dispositivo.
 */
export function DeviceProvider({ children }: DeviceProviderProps) {
  const [viewportWidth, setViewportWidth] = useState(
    typeof window !== 'undefined' ? window.innerWidth : DEFAULT.viewportWidth
  )
  const [viewportHeight, setViewportHeight] = useState(
    typeof window !== 'undefined' ? window.innerHeight : DEFAULT.viewportHeight
  )
  const [isMobile, setIsMobile] = useState<boolean>(() => {
    if (typeof window === 'undefined') return DEFAULT.isMobile
    // Consideramos móvil si el width < 768 (tailwind md breakpoint) o UA detecta móvil
    return window.matchMedia?.('(max-width: 767px)')?.matches ?? detectMobileByUA()
  })
  const [isTablet, setIsTablet] = useState<boolean>(() => {
    if (typeof window === 'undefined') return DEFAULT.isTablet
    return window.matchMedia?.('(min-width: 768px) and (max-width: 1023px)')?.matches ?? false
  })

  useEffect(() => {
    if (typeof window === 'undefined') return

    const handleResize = () => {
      setViewportWidth(window.innerWidth)
      setViewportHeight(window.innerHeight)
    }

    const mmMobile = window.matchMedia('(max-width: 767px)')
    const mmTablet = window.matchMedia('(min-width: 768px) and (max-width: 1023px)')

    const handleMM = () => {
      setIsMobile(mmMobile.matches || detectMobileByUA())
      setIsTablet(mmTablet.matches)
    }

    // Inicial
    handleResize()
    handleMM()

    // Listeners
    window.addEventListener('resize', handleResize)
    mmMobile.addEventListener?.('change', handleMM)
    mmTablet.addEventListener?.('change', handleMM)

    return () => {
      window.removeEventListener('resize', handleResize)
      mmMobile.removeEventListener?.('change', handleMM)
      mmTablet.removeEventListener?.('change', handleMM)
    }
  }, [])

  const value: DeviceInfo = {
    isMobile,
    isTablet,
    viewportWidth,
    viewportHeight,
  }

  return <DeviceContext.Provider value={value}>{children}</DeviceContext.Provider>
}

/**
 * useDevice
 * @description Hook para consumir la información de dispositivo.
 */
export function useDevice(): DeviceInfo {
  return useContext(DeviceContext)
}