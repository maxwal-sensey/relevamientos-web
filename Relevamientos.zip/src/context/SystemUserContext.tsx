/**
 * @file SystemUserContext.tsx
 * @description Contexto global para gestionar la sesión del usuario del SGR (autenticación simulada en frontend).
 */

import {
  createContext,
  useCallback,
  useContext,
  useMemo,
  useState,
  type ReactNode,
} from 'react'
import { findDemoUserByCredentials } from '../mock/demoUsers'

/**
 * SystemUserRole
 * @description Tipos de rol soportados por el sistema.
 */
export type SystemUserRole = 'secretario' | 'relevador' | 'administrador'

/**
 * SystemUser
 * @description Representa un usuario autenticado en el sistema.
 */
export interface SystemUser {
  id: number
  legajo: string
  nombre: string
  apellido: string
  rol: SystemUserRole
  dependenciaId?: number | null
}

/**
 * SystemUserContextValue
 * @description Contrato del contexto de usuario (estado y acciones).
 */
export interface SystemUserContextValue {
  currentUser: SystemUser | null
  isLoading: boolean
  loginWithCredentials: (legajo: string, password: string) => Promise<void>
  logout: () => void
}

const SystemUserContext = createContext<SystemUserContextValue | undefined>(
  undefined
)

/**
 * useSystemUser
 * @description Hook para acceder al contexto de usuario.
 */
export function useSystemUser(): SystemUserContextValue {
  const ctx = useContext(SystemUserContext)
  if (!ctx) {
    throw new Error('useSystemUser debe usarse dentro de SystemUserProvider')
  }
  return ctx
}

/**
 * SystemUserProviderProps
 * @description Props para el proveedor de contexto de usuario.
 */
interface SystemUserProviderProps {
  children: ReactNode
}

/**
 * SystemUserProvider
 * @description Proveedor que mantiene el estado de autenticación del usuario.
 */
export function SystemUserProvider({ children }: SystemUserProviderProps) {
  const [currentUser, setCurrentUser] = useState<SystemUser | null>(null)
  const [isLoading, setIsLoading] = useState(false)

  /**
   * loginWithCredentials
   * @description Simula autenticación local usando legajo y contraseña sobre usuarios demo.
   */
  const loginWithCredentials = useCallback(
    async (legajo: string, password: string) => {
      setIsLoading(true)

      try {
        // Simulación de latencia de red para dar feedback visual.
        await new Promise((resolve) => setTimeout(resolve, 600))

        const demoUser = findDemoUserByCredentials(legajo, password)

        if (!demoUser || !demoUser.isActive) {
          throw new Error('Legajo o contraseña incorrectos.')
        }

        const { id, legajo: numLegajo, nombre, apellido, rol, dependenciaId } =
          demoUser

        const systemUser: SystemUser = {
          id,
          legajo: numLegajo,
          nombre,
          apellido,
          rol,
          dependenciaId: dependenciaId ?? null,
        }

        setCurrentUser(systemUser)
      } finally {
        setIsLoading(false)
      }
    },
    []
  )

  /**
   * logout
   * @description Cierra la sesión actual en el frontend.
   */
  const logout = useCallback(() => {
    setCurrentUser(null)
  }, [])

  const value: SystemUserContextValue = useMemo(
    () => ({
      currentUser,
      isLoading,
      loginWithCredentials,
      logout,
    }),
    [currentUser, isLoading, loginWithCredentials, logout]
  )

  return (
    <SystemUserContext.Provider value={value}>
      {children}
    </SystemUserContext.Provider>
  )
}