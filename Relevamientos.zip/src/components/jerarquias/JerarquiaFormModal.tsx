/**
 * @file JerarquiaFormModal.tsx
 * @description Modal simple para crear/editar jerarquías (componente reutilizable).
 */

import { useEffect, useState } from 'react'
import { X } from 'lucide-react'
import type { DemoJerarquia } from '../../mock/jerarquiasStore'

/**
 * Dependency: pequeño set de tipos para el formulario de jerarquía.
 */
export type JerarquiaFormMode = 'create' | 'edit'

/**
 * JerarquiaFormValues
 * @description Tipos de los valores del formulario de jerarquía.
 */
export interface JerarquiaFormValues {
  nombre: string
  orden?: number
}

/**
 * JerarquiaFormModalProps
 * @description Props del modal de jerarquía.
 */
interface JerarquiaFormModalProps {
  open: boolean
  mode: JerarquiaFormMode
  initial?: DemoJerarquia
  onClose: () => void
  onSubmit: (values: JerarquiaFormValues) => void
}

/**
 * JerarquiaFormModal
 * @description Modal controlado que permite crear o editar una jerarquía.
 */
export default function JerarquiaFormModal({
  open,
  mode,
  initial,
  onClose,
  onSubmit,
}: JerarquiaFormModalProps) {
  const [nombre, setNombre] = useState('')
  const [orden, setOrden] = useState<number | undefined>(undefined)
  const [error, setError] = useState<string | null>(null)

  /**
   * Resetea el formulario cuando se abre/cierra o cambia el initial.
   */
  useEffect(() => {
    if (open) {
      setNombre(initial?.nombre ?? '')
      setOrden(initial?.orden)
      setError(null)
    }
  }, [open, initial])

  /**
   * handleSubmit
   * @description Valida valores mínimos y dispara onSubmit con el payload correcto.
   */
  function handleSubmit(e?: React.FormEvent) {
    e?.preventDefault?.()
    if (!nombre.trim()) {
      setError('El nombre es obligatorio')
      return
    }
    onSubmit({ nombre: nombre.trim(), orden })
  }

  if (!open) return null

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
      <div className="w-full max-w-md rounded-lg bg-slate-900 p-4 shadow-lg">
        <div className="mb-3 flex items-center justify-between">
          <h3 className="text-sm font-semibold text-slate-50">
            {mode === 'create' ? 'Nueva jerarquía' : 'Editar jerarquía'}
          </h3>
          <button
            aria-label="Cerrar"
            onClick={onClose}
            className="rounded-md p-1 text-slate-300 hover:bg-slate-800"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-3">
          <div>
            <label className="mb-1 block text-xs font-medium text-slate-300">Nombre</label>
            <input
              value={nombre}
              onChange={(e) => setNombre(e.target.value)}
              className="block w-full rounded-md border border-slate-700 bg-slate-900 px-3 py-2 text-sm text-slate-100 placeholder:text-slate-500 focus:border-sky-500 focus:ring-1 focus:ring-sky-500"
              placeholder="Ej: Comisario"
            />
          </div>

          <div>
            <label className="mb-1 block text-xs font-medium text-slate-300">Orden (opcional)</label>
            <input
              type="number"
              value={orden ?? ''}
              onChange={(e) => setOrden(e.target.value === '' ? undefined : Number(e.target.value))}
              className="block w-32 rounded-md border border-slate-700 bg-slate-900 px-3 py-2 text-sm text-slate-100 placeholder:text-slate-500 focus:border-sky-500 focus:ring-1 focus:ring-sky-500"
              placeholder="1"
            />
          </div>

          {error && <div className="text-xs text-red-300">{error}</div>}

          <div className="flex items-center justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="rounded-md bg-slate-800 px-3 py-1.5 text-xs font-medium text-slate-200 hover:bg-slate-700"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="rounded-md bg-sky-600 px-3 py-1.5 text-xs font-semibold text-white hover:bg-sky-700"
            >
              {mode === 'create' ? 'Crear' : 'Guardar'}
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}