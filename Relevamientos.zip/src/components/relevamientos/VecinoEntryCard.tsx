/**
 * @file VecinoEntryCard.tsx
 * @description Tarjeta reutilizable para editar un vecino entrevistado.
 */

import React from 'react'
import { Trash2 } from 'lucide-react'
import type { VecinoEntry } from '../../types/relevamiento'

/**
 * @interface Props
 * @description Props para VecinoEntryCard.
 */
interface Props {
  v: VecinoEntry
  onUpdate: (id: number, patch: Partial<VecinoEntry>) => void
  onRemove: (id: number) => void
}

/**
 * @component VecinoEntryCard
 * @description Muestra los campos editables de un vecino y botones de acción.
 */
export default function VecinoEntryCard({ v, onUpdate, onRemove }: Props) {
  return (
    <div key={v.id} className="space-y-2 rounded-lg border border-slate-800 bg-slate-950 px-3 py-3">
      <div className="flex items-center justify-between gap-2">
        <p className="text-[11px] font-semibold text-slate-100">Vecino entrevistado</p>
        <button
          type="button"
          onClick={() => onRemove(v.id)}
          className="inline-flex items-center gap-1 rounded-md border border-red-700/70 px-2 py-0.5 text-[10px] font-medium text-red-200 hover:bg-red-900/60"
        >
          <Trash2 className="h-3 w-3" />
          Quitar
        </button>
      </div>

      <div className="grid gap-2 sm:grid-cols-2">
        <div>
          <label className="mb-1 block text-[11px] font-medium text-slate-200">Lugar de entrevista</label>
          <input
            type="text"
            value={v.lugar}
            onChange={(e) => onUpdate(v.id, { lugar: e.target.value })}
            className="block w-full rounded-md border border-slate-700 bg-slate-950 px-2 py-1 text-[11px] text-slate-100 placeholder:text-slate-500 focus:border-sky-500 focus:outline-none focus:ring-1 focus:ring-sky-500"
            placeholder="Ej: Domicilio del vecino, comercio, vía pública"
          />
        </div>
        <div className="grid grid-cols-2 gap-2">
          <div>
            <label className="mb-1 block text-[11px] font-medium text-slate-200">Nombre</label>
            <input
              type="text"
              value={v.nombre}
              onChange={(e) => onUpdate(v.id, { nombre: e.target.value })}
              className="block w-full rounded-md border border-slate-700 bg-slate-950 px-2 py-1 text-[11px] text-slate-100 placeholder:text-slate-500 focus:border-sky-500 focus:outline-none focus:ring-1 focus:ring-sky-500"
            />
          </div>
          <div>
            <label className="mb-1 block text-[11px] font-medium text-slate-200">Apellido</label>
            <input
              type="text"
              value={v.apellido}
              onChange={(e) => onUpdate(v.id, { apellido: e.target.value })}
              className="block w-full rounded-md border border-slate-700 bg-slate-950 px-2 py-1 text-[11px] text-slate-100 placeholder:text-slate-500 focus:border-sky-500 focus:outline-none focus:ring-1 focus:ring-sky-500"
            />
          </div>
        </div>
      </div>

      <div className="grid gap-2 sm:grid-cols-3">
        <div className="flex items-center gap-2">
          <input
            id={`presencio-${v.id}`}
            type="checkbox"
            checked={v.presencio}
            onChange={(e) => onUpdate(v.id, { presencio: e.target.checked })}
            className="h-3.5 w-3.5 rounded border-slate-600 bg-slate-900 text-sky-500 focus:ring-sky-500"
          />
          <label htmlFor={`presencio-${v.id}`} className="text-[11px] text-slate-200">Presenció el hecho</label>
        </div>
        <div className="flex items-center gap-2">
          <input
            id={`conocimiento-${v.id}`}
            type="checkbox"
            checked={v.conocimiento}
            onChange={(e) => onUpdate(v.id, { conocimiento: e.target.checked })}
            className="h-3.5 w-3.5 rounded border-slate-600 bg-slate-900 text-sky-500 focus:ring-sky-500"
          />
          <label htmlFor={`conocimiento-${v.id}`} className="text-[11px] text-slate-200">Tiene conocimiento del hecho</label>
        </div>
        <div className="flex items-center gap-2">
          <input
            id={`sincamaras-${v.id}`}
            type="checkbox"
            checked={v.sinCamaras}
            onChange={(e) => onUpdate(v.id, { sinCamaras: e.target.checked })}
            className="h-3.5 w-3.5 rounded border-slate-600 bg-slate-900 text-sky-500 focus:ring-sky-500"
          />
          <label htmlFor={`sincamaras-${v.id}`} className="text-[11px] text-slate-200">No posee cámaras de seguridad</label>
        </div>
      </div>

      <div className="grid gap-2 sm:grid-cols-2">
        <div className="flex items-center gap-2">
          <input
            id={`nograban-${v.id}`}
            type="checkbox"
            checked={v.camarasNoGraban}
            onChange={(e) => onUpdate(v.id, { camarasNoGraban: e.target.checked })}
            className="h-3.5 w-3.5 rounded border-slate-600 bg-slate-900 text-sky-500 focus:ring-sky-500"
          />
          <label htmlFor={`nograban-${v.id}`} className="text-[11px] text-slate-200">Las cámaras no graban / sin registros</label>
        </div>
        <div className="flex items-center gap-2">
          <input
            id={`nodanlugar-${v.id}`}
            type="checkbox"
            checked={v.camarasNoDanLugar}
            onChange={(e) => onUpdate(v.id, { camarasNoDanLugar: e.target.checked })}
            className="h-3.5 w-3.5 rounded border-slate-600 bg-slate-900 text-sky-500 focus:ring-sky-500"
          />
          <label htmlFor={`nodanlugar-${v.id}`} className="text-[11px] text-slate-200">Las cámaras no dan al lugar del hecho</label>
        </div>
      </div>

      <div>
        <label className="mb-1 block text-[11px] font-medium text-slate-200">Observaciones</label>
        <textarea
          rows={2}
          value={v.observaciones}
          onChange={(e) => onUpdate(v.id, { observaciones: e.target.value })}
          className="block w-full rounded-md border border-slate-700 bg-slate-950 px-2 py-1 text-[11px] text-slate-100 placeholder:text-slate-500 focus:border-sky-500 focus:outline-none focus:ring-1 focus:ring-sky-500"
          placeholder="Si deja vacío este campo, el sistema generará automáticamente un texto básico según las opciones tildadas."
        />
      </div>
    </div>
  )
}