/**
 * @file QuickSummary.tsx
 * @description Componente reutilizable que muestra un resumen rápido de un informe/relevamiento
 *              en un modal. Incluye una función auxiliar `showQuickSummary(id)` para montar el modal
 *              dinámicamente desde cualquier parte de la aplicación sin tocar rutas.
 */

import React, { useEffect } from 'react'
import { createRoot, Root } from 'react-dom/client'
import { FileText, Camera, Users, MapPin, Calendar } from 'lucide-react'
import { getInformeById, InformeRelevamientoData } from '../../mock/relevamientosStore'

/**
 * QuickSummaryProps
 * @description Props del componente QuickSummaryModal.
 */
interface QuickSummaryProps {
  informe?: InformeRelevamientoData
  onClose: () => void
}

/**
 * QuickSummaryModal
 * @description Modal que presenta la información esencial de un informe de relevamiento.
 *              Responsabilidad única: visualización y cierre del modal.
 */
function QuickSummaryModal({ informe, onClose }: QuickSummaryProps) {
  useEffect(() => {
    function onKey(e: KeyboardEvent) {
      if (e.key === 'Escape') onClose()
    }
    document.addEventListener('keydown', onKey)
    return () => document.removeEventListener('keydown', onKey)
  }, [onClose])

  if (!informe) {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center">
        <div className="absolute inset-0 bg-black/50" onClick={onClose} />
        <div className="relative z-10 w-full max-w-md rounded-lg bg-slate-900/95 p-6 text-slate-200 shadow-lg">
          <p className="text-sm">Informe no encontrado.</p>
          <div className="mt-4 flex justify-end">
            <button
              className="rounded bg-sky-600 px-3 py-1 text-xs font-medium hover:bg-sky-500"
              onClick={onClose}
            >
              Cerrar
            </button>
          </div>
        </div>
      </div>
    )
  }

  const camerasCount = informe.camaras?.length ?? 0
  const vecinosCount = informe.vecinos?.length ?? 0

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      <div
        className="absolute inset-0 bg-black/60 backdrop-blur-sm"
        onClick={onClose}
        aria-hidden
      />
      <article
        role="dialog"
        aria-modal="true"
        className="relative z-10 w-full max-w-3xl transform rounded-xl border border-slate-800 bg-gradient-to-b from-slate-900/95 to-slate-900/80 p-6 shadow-2xl"
      >
        <header className="mb-4 flex items-start justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="rounded-md bg-sky-600/20 p-2 text-sky-400">
              <FileText className="h-6 w-6" />
            </div>
            <div>
              <h3 className="text-sm font-semibold text-slate-50">
                Resumen rápido — {informe.numeroRegistro}
              </h3>
              <p className="mt-1 text-xs text-slate-400">
                {informe.fiscalia} • {informe.fecha}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 text-xs text-slate-400">
            <span className="inline-flex items-center gap-1 rounded-full border border-slate-700 px-2 py-1">
              <Calendar className="h-4 w-4 text-slate-300" />
              {informe.fecha}
            </span>
          </div>
        </header>

        <section className="grid gap-4 md:grid-cols-3">
          <div className="col-span-2 space-y-2">
            <p className="text-sm font-medium text-slate-100">{informe.caratula}</p>
            <p className="text-xs text-slate-300">
              <MapPin className="inline-block mr-1 h-4 w-4 align-text-bottom text-slate-300" />
              {informe.lugar}
            </p>
            <p className="max-h-28 overflow-hidden text-xs text-slate-400">
              {informe.resumenHecho}
            </p>

            <div className="mt-3 flex flex-wrap gap-2">
              <a
                href={`#/relevamientos/${informe.id}/informe`}
                className="inline-flex items-center gap-2 rounded bg-sky-600 px-3 py-1 text-xs font-medium hover:bg-sky-500"
              >
                Ver informe completo
              </a>
              <button
                onClick={onClose}
                className="inline-flex items-center gap-2 rounded border border-slate-700 bg-transparent px-3 py-1 text-xs font-medium text-slate-200 hover:bg-slate-800"
              >
                Cerrar
              </button>
            </div>
          </div>

          <aside className="space-y-3 rounded-lg border border-slate-800 bg-slate-800/30 p-3 text-sm">
            <div className="flex items-center justify-between gap-3">
              <div className="flex items-center gap-2">
                <div className="rounded bg-slate-700 p-2 text-sky-300">
                  <Camera className="h-4 w-4" />
                </div>
                <div>
                  <p className="text-xs text-slate-300">Cámaras</p>
                  <p className="text-sm font-semibold text-slate-50">{camerasCount}</p>
                </div>
              </div>
            </div>

            <div className="flex items-center justify-between gap-3">
              <div className="flex items-center gap-2">
                <div className="rounded bg-slate-700 p-2 text-violet-300">
                  <Users className="h-4 w-4" />
                </div>
                <div>
                  <p className="text-xs text-slate-300">Vecinos entrevistados</p>
                  <p className="text-sm font-semibold text-slate-50">{vecinosCount}</p>
                </div>
              </div>
            </div>

            <div className="pt-2 text-xs text-slate-400">
              <p className="font-medium text-slate-200">Secretaria: </p>
              <p>{informe.secretariaNombre || '—'}</p>
            </div>
          </aside>
        </section>
      </article>
    </div>
  )
}

/**
 * showQuickSummary
 * @description Monta dinámicamente el modal de resumen rápido para el informe especificado.
 *              Retorna una función close() para cerrarlo programáticamente si se desea.
 *
 * @param id Identificador interno del informe/relevamiento
 * @returns close function
 */
export function showQuickSummary(id: number): () => void {
  const container = document.createElement('div')
  container.setAttribute('data-quick-summary', String(id))
  document.body.appendChild(container)

  const root: Root = createRoot(container)
  const informe = getInformeById(id)

  function handleClose() {
    try {
      root.unmount()
    } catch (e) {
      /* ignore */
    }
    if (container.parentNode) container.parentNode.removeChild(container)
  }

  root.render(<QuickSummaryModal informe={informe} onClose={handleClose} />)

  return handleClose
}

export default QuickSummaryModal
