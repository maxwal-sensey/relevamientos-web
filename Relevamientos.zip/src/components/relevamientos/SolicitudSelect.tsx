/**
 * @file SolicitudSelect.tsx
 * @description Componente para seleccionar una solicitud pendiente y mostrar un resumen.
 */

import React from 'react'
import type { OpcionSolicitud } from '../../types/relevamiento'

/**
 * @interface Props
 * @description Props del componente SolicitudSelect.
 */
interface Props {
  opciones: OpcionSolicitud[]
  value: number | ''
  onChange: (v: number | '') => void
}

/**
 * @component SolicitudSelect
 * @description Selector de solicitud con resumen contextual.
 */
export default function SolicitudSelect({ opciones, value, onChange }: Props) {
  const solicitudSeleccionada =
    typeof value === 'number'
      ? opciones.find((s) => s.id === value) ?? null
      : null

  return (
    <div className="space-y-3">
      <div className="grid gap-3 sm:grid-cols-2">
        <div>
          <label
            htmlFor="solicitud"
            className="mb-1 block text-xs font-medium text-slate-200"
          >
            Solicitud a relevar *
          </label>
          <select
            id="solicitud"
            value={value}
            onChange={(e) => onChange(e.target.value ? Number(e.target.value) : '')}
            className="block w-full rounded-md border border-slate-700 bg-slate-950 px-2 py-1.5 text-xs text-slate-100 focus:border-sky-500 focus:outline-none focus:ring-1 focus:ring-sky-500"
          >
            <option value="">Seleccione una solicitud…</option>
            {opciones.map((s) => (
              <option key={s.id} value={s.id}>
                {s.numeroRegistro} — {s.caratula}
              </option>
            ))}
          </select>
        </div>

        {solicitudSeleccionada && (
          <div className="rounded-md border border-slate-700 bg-slate-950 px-3 py-2 text-[11px] text-slate-200">
            <p className="font-semibold text-slate-100">
              {solicitudSeleccionada.caratula}
            </p>
            <p className="text-slate-300">
              IPP: <span className="font-mono">{solicitudSeleccionada.ipp}</span>
            </p>
            <p className="text-slate-300">Fiscalía: {solicitudSeleccionada.fiscalia}</p>
            <p className="text-slate-400">Lugar: {solicitudSeleccionada.lugar}</p>
            <p className="mt-1 text-[10px] text-slate-400">
              Resumen del hecho: <span className="italic">{solicitudSeleccionada.resumenHecho}</span>
            </p>
          </div>
        )}
      </div>
    </div>
  )
}