/**
 * @file SolicitudAttachmentsModal.tsx
 * @description Modal que muestra los archivos adjuntos asociados a una solicitud
 *              (busca mensajes persistidos en mockApi y lista sus attachments).
 */

import React, { useEffect, useState } from 'react'
import { X as XIcon, DownloadCloud } from 'lucide-react'
import { getAttachmentsForSolicitud, getAttachmentBlob } from '../../lib/mockApi'

/**
 * Props del modal de attachments.
 */
interface SolicitudAttachmentsModalProps {
  /** Id de la solicitud (number o string) */
  solicitudId: string | number
  /** Abierto / cerrado */
  open: boolean
  /** Callback de cierre */
  onClose: () => void
}

/**
 * AttachmentRow
 * @description Tipo local para representar un attachment encontrado.
 */
interface AttachmentRow {
  messageId: number
  messageSubject: string
  from: string
  createdAt: string
  attachment: {
    name: string
    size: number
    type: string
  }
  attachmentIndex: number
}

/**
 * SolicitudAttachmentsModal
 * @description Muestra los attachments de los mensajes relacionados con la solicitud.
 */
export default function SolicitudAttachmentsModal({
  solicitudId,
  open,
  onClose,
}: SolicitudAttachmentsModalProps) {
  const [loading, setLoading] = useState(false)
  const [items, setItems] = useState<AttachmentRow[]>([])
  const [downloading, setDownloading] = useState<number | null>(null)

  useEffect(() => {
    if (!open) return
    let mounted = true
    setLoading(true)
    getAttachmentsForSolicitud(solicitudId)
      .then((list) => {
        if (!mounted) return
        setItems(list)
      })
      .catch((err) => {
        console.error('[SolicitudAttachmentsModal] error fetching attachments', err)
        setItems([])
      })
      .finally(() => {
        if (!mounted) return
        setLoading(false)
      })
    return () => {
      mounted = false
    }
  }, [open, solicitudId])

  if (!open) return null

  /**
   * handleDownload
   * @description Pide el blob demo al mockApi y fuerza descarga en el cliente.
   * @param row AttachmentRow
   */
  async function handleDownload(row: AttachmentRow) {
    try {
      setDownloading(row.messageId)
      const blob = await getAttachmentBlob(row.messageId, row.attachmentIndex)
      const url = URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = url
      a.download = row.attachment.name || 'adjunto.bin'
      document.body.appendChild(a)
      a.click()
      document.body.removeChild(a)
      URL.revokeObjectURL(url)
    } catch (err) {
      console.error('Error descargando adjunto (mock):', err)
      // eslint-disable-next-line no-alert
      alert('Error descargando el adjunto (demo). Revisa la consola.')
    } finally {
      setDownloading(null)
    }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      <div className="absolute inset-0 bg-black/50" onClick={onClose} aria-hidden />
      <div className="relative z-10 w-full max-w-2xl rounded-lg bg-slate-900 p-4 shadow-lg">
        <div className="mb-3 flex items-center justify-between">
          <h3 className="text-sm font-semibold text-slate-50">Archivos relacionados a la solicitud</h3>
          <button type="button" onClick={onClose} className="rounded p-1 text-slate-300 hover:bg-slate-800" aria-label="Cerrar">
            <XIcon className="h-4 w-4" />
          </button>
        </div>

        {loading ? (
          <div className="py-8 text-center text-sm text-slate-400">Cargando adjuntos...</div>
        ) : items.length === 0 ? (
          <div className="py-8 text-center text-sm text-slate-400">No hay archivos adjuntos relacionados con esta solicitud.</div>
        ) : (
          <div className="space-y-3">
            {items.map((row) => (
              <div key={`${row.messageId}-${row.attachmentIndex}`} className="flex items-center justify-between rounded-md border border-slate-800 bg-slate-800/30 px-3 py-2">
                <div className="min-w-0">
                  <div className="text-sm text-slate-100">{row.attachment.name}</div>
                  <div className="mt-1 text-xs text-slate-400">
                    {row.attachment.size} bytes · {row.attachment.type || 'application/octet-stream'} · mensaje: <span className="font-medium text-slate-200">{row.messageSubject || '(sin asunto)'}</span>
                  </div>
                  <div className="mt-1 text-xs text-slate-400">Remitente: {row.from} · {new Date(row.createdAt).toLocaleString()}</div>
                </div>

                <div className="ml-4 flex-shrink-0">
                  <button
                    onClick={() => handleDownload(row)}
                    className="inline-flex items-center gap-2 rounded-md bg-sky-600 px-3 py-1 text-xs font-semibold text-white hover:bg-sky-700 disabled:opacity-60"
                    disabled={downloading !== null}
                  >
                    <DownloadCloud className="h-4 w-4" />
                    {downloading === row.messageId ? 'Descargando…' : 'Descargar'}
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}