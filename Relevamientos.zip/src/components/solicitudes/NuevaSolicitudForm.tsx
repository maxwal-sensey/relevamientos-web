/**
 * @file NuevaSolicitudForm.tsx
 * @description Formulario para crear una nueva solicitud usando CreateSolicitudSchema (Zod).
 *              Incluye búsqueda de direcciones (AddressSearch) y preview de mapa (MapPreview).
 */

import React, { FormEvent, useState } from 'react'
import { z } from 'zod'
import { CreateSolicitudSchema, CreateSolicitudInput } from '../../schemas/solicitudSchema'
import { createSolicitud } from '../../mock/solicitudesStore'
import { toast } from 'sonner'
import AddressSearch from '../common/AddressSearch'
import MapPreview from '../common/MapPreview'

/**
 * Props del componente NuevaSolicitudForm
 * @description onSaved: callback con la nueva solicitud creada; onCancel: cerrar/descartar formulario
 */
interface NuevaSolicitudFormProps {
  onSaved?: (created: any) => void
  onCancel?: () => void
}

/**
 * FieldErrors
 * @description Tipo para errores por campo (mensajes de validación).
 */
type FieldErrors = Partial<Record<keyof CreateSolicitudInput, string>>

/**
 * validateWithZod
 * @description Valida parcialmente un objeto contra CreateSolicitudSchema y devuelve errores por campo.
 * @param values Valores a validar
 */
function validateWithZod(values: Partial<CreateSolicitudInput>): FieldErrors {
  const result = CreateSolicitudSchema.safeParse(values)
  if (result.success) return {}
  const formatted: FieldErrors = {}
  for (const issue of result.error.issues) {
    const key = issue.path[0] as keyof FieldErrors
    if (!formatted[key]) formatted[key] = issue.message
  }
  return formatted
}

/**
 * NuevaSolicitudForm
 * @description Formulario que valida con Zod, permite buscar direcciones y seleccionar ubicación.
 */
export default function NuevaSolicitudForm({ onSaved, onCancel }: NuevaSolicitudFormProps) {
  const [ipp, setIpp] = useState('')
  const [fiscalia, setFiscalia] = useState('')
  const [caratula, setCaratula] = useState('')
  const [lugar, setLugar] = useState('')
  const [resumen, setResumen] = useState('')
  const [hasAdjuntos, setHasAdjuntos] = useState<boolean>(false)
  const [dependenciaId, setDependenciaId] = useState<number | null>(null)
  const [lat, setLat] = useState<number | null>(null)
  const [lng, setLng] = useState<number | null>(null)

  const [saving, setSaving] = useState(false)
  const [fieldErrors, setFieldErrors] = useState<FieldErrors>({})
  const [serverError, setServerError] = useState<string | null>(null)

  /**
   * handleAddressSelect
   * @description Callback al seleccionar una dirección desde AddressSearch.
   *              Rellena lugar, lat y lng automáticamente.
   */
  const handleAddressSelect = (res: { display_name: string; lat: number; lon: number }) => {
    setLugar(res.display_name)
    setLat(res.lat)
    setLng(res.lon)
    // Limpiar errores relacionados
    setFieldErrors((prev) => ({ ...prev, lugar: undefined, lat: undefined, lng: undefined }))
  }

  /**
   * handleFieldBlur
   * @description Valida el formulario completo y extrae el error del campo solicitado.
   * @param name Nombre del campo a validar
   */
  const handleFieldBlur = (name: keyof CreateSolicitudInput) => {
    const errs = validateWithZod({
      ipp,
      fiscalia,
      caratula,
      lugar,
      resumen,
      hasAdjuntos,
      dependenciaId,
      lat,
      lng,
    })
    setFieldErrors((prev) => ({ ...prev, [name]: errs[name] }))
  }

  /**
   * handleSubmit
   * @description Valida con Zod y llama a createSolicitud del mock-store. Maneja errores y notificaciones.
   * @param e Evento de submit
   */
  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault()
    setServerError(null)

    const payload: CreateSolicitudInput = {
      ipp: ipp.trim(),
      fiscalia: fiscalia.trim(),
      caratula: caratula.trim(),
      lugar: lugar.trim(),
      resumen: resumen.trim(),
      hasAdjuntos,
      dependenciaId: dependenciaId ?? null,
      lat: lat ?? null,
      lng: lng ?? null,
    }

    // Validación Zod
    const parsed = CreateSolicitudSchema.safeParse(payload)
    if (!parsed.success) {
      const mapped: FieldErrors = {}
      for (const issue of parsed.error.issues) {
        const key = issue.path[0] as keyof FieldErrors
        if (!mapped[key]) mapped[key] = issue.message
      }
      setFieldErrors(mapped)
      toast.error('Corrija los campos marcados antes de enviar.')
      return
    }

    setSaving(true)
    try {
      const created = await createSolicitud(payload, 'Usuario Demo')
      toast.success('Solicitud creada correctamente.')
      if (onSaved) onSaved(created)
      // Limpiar formulario opcionalmente
    } catch (err: any) {
      if (err?.validation && err?.issues) {
        // Errores que vienen del "servidor" (mock)
        const mapped: FieldErrors = {}
        for (const issue of err.issues) {
          const k = issue.path[0] as keyof FieldErrors
          mapped[k] = issue.message
        }
        setFieldErrors(mapped)
        toast.error('Errores de validación del formulario.')
      } else {
        setServerError('Error al crear la solicitud. Intente nuevamente.')
        toast.error('Error al crear la solicitud.')
      }
    } finally {
      setSaving(false)
    }
  }

  return (
    <form onSubmit={handleSubmit} className="w-full max-w-2xl space-y-4 rounded-lg border border-slate-800 bg-slate-900/60 p-4">
      {serverError && <div className="rounded-md border border-red-500/60 bg-red-950/60 px-3 py-2 text-xs text-red-100">{serverError}</div>}

      <div className="grid gap-3 sm:grid-cols-2">
        <div>
          <label className="mb-1 block text-xs font-medium text-slate-300">N° IPP *</label>
          <input
            value={ipp}
            onChange={(e) => setIpp(e.target.value)}
            onBlur={() => handleFieldBlur('ipp')}
            className={`block w-full rounded-md border px-3 py-1.5 text-sm text-slate-100 ${fieldErrors.ipp ? 'border-red-500 bg-red-950/20' : 'border-slate-700 bg-slate-950'}`}
          />
          {fieldErrors.ipp && <p className="mt-1 text-[11px] text-red-300">{fieldErrors.ipp}</p>}
        </div>

        <div>
          <label className="mb-1 block text-xs font-medium text-slate-300">Fiscalía *</label>
          <input
            value={fiscalia}
            onChange={(e) => setFiscalia(e.target.value)}
            onBlur={() => handleFieldBlur('fiscalia')}
            className={`block w-full rounded-md border px-3 py-1.5 text-sm text-slate-100 ${fieldErrors.fiscalia ? 'border-red-500 bg-red-950/20' : 'border-slate-700 bg-slate-950'}`}
          />
          {fieldErrors.fiscalia && <p className="mt-1 text-[11px] text-red-300">{fieldErrors.fiscalia}</p>}
        </div>

        <div>
          <label className="mb-1 block text-xs font-medium text-slate-300">Carátula *</label>
          <input
            value={caratula}
            onChange={(e) => setCaratula(e.target.value)}
            onBlur={() => handleFieldBlur('caratula')}
            className={`block w-full rounded-md border px-3 py-1.5 text-sm text-slate-100 ${fieldErrors.caratula ? 'border-red-500 bg-red-950/20' : 'border-slate-700 bg-slate-950'}`}
          />
          {fieldErrors.caratula && <p className="mt-1 text-[11px] text-red-300">{fieldErrors.caratula}</p>}
        </div>

        <div>
          <label className="mb-1 block text-xs font-medium text-slate-300">Resumen *</label>
          <input
            value={resumen}
            onChange={(e) => setResumen(e.target.value)}
            onBlur={() => handleFieldBlur('resumen')}
            className={`block w-full rounded-md border px-3 py-1.5 text-sm text-slate-100 ${fieldErrors.resumen ? 'border-red-500 bg-red-950/20' : 'border-slate-700 bg-slate-950'}`}
          />
          {fieldErrors.resumen && <p className="mt-1 text-[11px] text-red-300">{fieldErrors.resumen}</p>}
        </div>
      </div>

      <div>
        <label className="mb-1 block text-xs font-medium text-slate-300">Lugar del hecho *</label>
        <div className="mb-2">
          <AddressSearch value={lugar} onSelect={handleAddressSelect} />
        </div>
        <input
          value={lugar}
          onChange={(e) => setLugar(e.target.value)}
          onBlur={() => handleFieldBlur('lugar')}
          className={`block w-full rounded-md border px-3 py-1.5 text-sm text-slate-100 ${fieldErrors.lugar ? 'border-red-500 bg-red-950/20' : 'border-slate-700 bg-slate-950'}`}
          placeholder="Puede buscar una dirección arriba o escribir manualmente"
        />
        {fieldErrors.lugar && <p className="mt-1 text-[11px] text-red-300">{fieldErrors.lugar}</p>}
      </div>

      <div className="grid gap-3 sm:grid-cols-2">
        <div>
          <label className="mb-1 block text-xs font-medium text-slate-300">Latitud</label>
          <input
            value={lat ?? ''}
            onChange={(e) => setLat(e.target.value === '' ? null : Number(e.target.value))}
            onBlur={() => handleFieldBlur('lat')}
            className={`block w-full rounded-md border px-3 py-1.5 text-sm text-slate-100 ${fieldErrors.lat ? 'border-red-500 bg-red-950/20' : 'border-slate-700 bg-slate-950'}`}
            placeholder="Ej: -34.9220"
          />
          {fieldErrors.lat && <p className="mt-1 text-[11px] text-red-300">{fieldErrors.lat}</p>}
        </div>

        <div>
          <label className="mb-1 block text-xs font-medium text-slate-300">Longitud</label>
          <input
            value={lng ?? ''}
            onChange={(e) => setLng(e.target.value === '' ? null : Number(e.target.value))}
            onBlur={() => handleFieldBlur('lng')}
            className={`block w-full rounded-md border px-3 py-1.5 text-sm text-slate-100 ${fieldErrors.lng ? 'border-red-500 bg-red-950/20' : 'border-slate-700 bg-slate-950'}`}
            placeholder="Ej: -57.9545"
          />
          {fieldErrors.lng && <p className="mt-1 text-[11px] text-red-300">{fieldErrors.lng}</p>}
        </div>
      </div>

      <div>
        <MapPreview lat={lat ?? null} lng={lng ?? null} />
      </div>

      <div className="flex items-center justify-between gap-2">
        <label className="flex items-center gap-2 text-sm text-slate-300">
          <input type="checkbox" checked={hasAdjuntos} onChange={(e) => setHasAdjuntos(e.target.checked)} />
          Tiene adjuntos
        </label>

        <div className="flex items-center gap-2">
          <button type="button" onClick={onCancel} className="rounded-md border border-slate-700 px-3 py-1.5 text-xs text-slate-200 hover:bg-slate-800">
            Cancelar
          </button>
          <button
            type="submit"
            disabled={saving}
            className="rounded-md bg-sky-600 px-4 py-1.5 text-xs font-semibold text-white hover:bg-sky-700 disabled:opacity-60"
          >
            {saving ? 'Creando…' : 'Crear solicitud'}
          </button>
        </div>
      </div>
    </form>
  )
}