/**
 * @file NewSolicitudButton.tsx
 * @description Botón que abre un modal con el formulario de nueva solicitud. El modal
 *              usa el componente NuevaSolicitudForm para asegurar que la búsqueda de
 *              direcciones (AddressSearch) y el MapPreview estén disponibles también
 *              cuando se abre desde el listado en modo modal.
 */

import React, { useState } from 'react'
import NuevaSolicitudForm from './NuevaSolicitudForm'

/**
 * NewSolicitudButtonProps
 * @description Props para el componente NewSolicitudButton.
 */
interface NewSolicitudButtonProps {
  className?: string
}

/**
 * NewSolicitudButton
 * @description Botón que abre/oculta un modal con el formulario NuevaSolicitudForm.
 *              El modal es simple y autocontenido para evitar dependencias externas.
 */
export default function NewSolicitudButton({ className = '' }: NewSolicitudButtonProps) {
  const [open, setOpen] = useState(false)

  /**
   * openModal
   * @description Abre el modal.
   */
  function openModal() {
    setOpen(true)
  }

  /**
   * closeModal
   * @description Cierra el modal.
   */
  function closeModal() {
    setOpen(false)
  }

  return (
    <>
      <button
        type="button"
        onClick={openModal}
        className={`inline-flex items-center gap-2 rounded bg-sky-600 px-3 py-1 text-sm font-medium text-white hover:bg-sky-500 ${className}`}
      >
        Nueva solicitud
      </button>

      {open && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 flex items-start justify-center overflow-auto bg-black/50 p-4"
        >
          <div className="mt-8 w-full max-w-3xl rounded-lg bg-slate-900/90 shadow-lg">
            <div className="flex items-center justify-between border-b border-slate-800 px-4 py-3">
              <h3 className="text-sm font-semibold text-slate-100">Nueva solicitud</h3>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={closeModal}
                  className="rounded-md border border-slate-700 px-3 py-1 text-xs text-slate-200 hover:bg-slate-800"
                >
                  Cerrar
                </button>
              </div>
            </div>

            <div className="p-4">
              {/* El formulario maneja onCancel/onSaved a través de props; aquí cerramos el modal */}
              <NuevaSolicitudForm
                onCancel={closeModal}
                onSaved={() => {
                  // Al guardar, cerramos el modal. Si se desea, se puede mostrar notificación adicional.
                  closeModal()
                }}
              />
            </div>
          </div>
        </div>
      )}
    </>
  )
}