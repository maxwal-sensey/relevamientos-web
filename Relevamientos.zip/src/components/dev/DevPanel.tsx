/**
 * @file DevPanel.tsx
 * @description Panel de desarrollo/operaciones para:
 *  - configurar API_BASE override
 *  - togglear mocks
 *  - ejecutar /migrate
 *  - probar login admin (1000/admin123)
 *
 * Nota: diseñado para facilitar pruebas en entornos de staging/prod al publicar.
 */

import React, { useEffect, useState } from 'react'
import { migrateDb, healthCheck } from '../../lib/apiClient'
import { API_BASE as DEFAULT_API_BASE } from '../../config/serverConfig'

/**
 * DevPanel
 * @description Componente que muestra controles para operaciones de integración.
 */
export default function DevPanel(): JSX.Element {
  const [apiBase, setApiBase] = useState(() => {
    try {
      return localStorage.getItem('SGR_API_BASE_OVERRIDE') || DEFAULT_API_BASE
    } catch {
      return DEFAULT_API_BASE
    }
  })
  const [useMocks, setUseMocks] = useState(() => {
    try {
      const v = localStorage.getItem('SGR_USE_MOCKS_OVERRIDE')
      if (v === 'true') return true
      if (v === 'false') return false
    } catch {}
    return false
  })
  const [status, setStatus] = useState<string>('idle')
  const [migrating, setMigrating] = useState(false)
  const [health, setHealth] = useState<boolean | null>(null)

  useEffect(() => {
    let mounted = true
    async function check() {
      try {
        const ok = await healthCheck()
        if (mounted) setHealth(ok)
      } catch {
        if (mounted) setHealth(false)
      }
    }
    check()
    return () => {
      mounted = false
    }
  }, [apiBase, useMocks])

  /**
   * handleSave
   * @description Guarda settings en localStorage.
   */
  function handleSave() {
    try {
      localStorage.setItem('SGR_API_BASE_OVERRIDE', apiBase || '')
      localStorage.setItem('SGR_USE_MOCKS_OVERRIDE', useMocks ? 'true' : 'false')
      setStatus('saved')
      setTimeout(() => setStatus('idle'), 1500)
    } catch (err) {
      setStatus('error')
    }
  }

  /**
   * handleMigrate
   * @description Ejecuta /migrate contra el API activo.
   */
  async function handleMigrate() {
    setMigrating(true)
    setStatus('migrating')
    try {
      const res = await migrateDb()
      setStatus('migrated')
      console.info('migrate result', res)
      // refrescar health
      const ok = await healthCheck()
      setHealth(ok)
    } catch (err) {
      console.error('migrate error', err)
      setStatus('migrate_failed')
    } finally {
      setMigrating(false)
      setTimeout(() => setStatus('idle'), 1500)
    }
  }

  /**
   * handleTestLoginAdmin
   * @description Intenta loguear al admin de seed (1000/admin123) contra /auth/login.
   */
  async function handleTestLoginAdmin() {
    setStatus('testing_login')
    try {
      const base = (localStorage.getItem('SGR_API_BASE_OVERRIDE') || DEFAULT_API_BASE).replace(/\/$/, '')
      const res = await fetch(`${base}/auth/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ legajo: '1000', password: 'admin123' }),
      })
      const payload = await res.json().catch(() => ({}))
      if (res.ok && payload && payload.user) {
        setStatus('login_ok')
      } else {
        setStatus('login_failed')
        console.warn('login failed', payload)
      }
    } catch (err) {
      console.error('login error', err)
      setStatus('login_error')
    } finally {
      setTimeout(() => setStatus('idle'), 1500)
    }
  }

  return (
    <div className="fixed right-4 bottom-4 z-50 w-[320px] rounded-md border border-slate-700 bg-slate-900/90 p-3 text-slate-100 shadow-lg">
      <div className="flex items-center justify-between">
        <h3 className="text-sm font-semibold">Dev / Ops</h3>
        <div className="text-xs text-slate-400">Staging helpers</div>
      </div>

      <div className="mt-2 space-y-2 text-xs">
        <label className="block">
          <div className="mb-1 text-[11px] text-slate-300">API Base</div>
          <input
            value={apiBase}
            onChange={(e) => setApiBase(e.target.value)}
            className="w-full rounded bg-slate-800 px-2 py-1 text-xs text-slate-100 placeholder:text-slate-500"
          />
        </label>

        <label className="flex items-center gap-2">
          <input
            type="checkbox"
            checked={useMocks}
            onChange={(e) => setUseMocks(e.target.checked)}
            className="h-4 w-4"
          />
          <span className="text-xs">Usar mocks (override)</span>
        </label>

        <div className="flex gap-2">
          <button
            onClick={handleSave}
            className="inline-flex items-center justify-center rounded-md bg-sky-600 px-2 py-1 text-[12px] font-medium text-white hover:bg-sky-700"
          >
            Guardar
          </button>
          <button
            onClick={() => {
              // quick set run migrate flag in localStorage
              try {
                localStorage.setItem('SGR_RUN_MIGRATE', 'true')
                setStatus('run_migrate_flag_set')
                setTimeout(() => setStatus('idle'), 1200)
              } catch {
                setStatus('error')
              }
            }}
            className="inline-flex items-center justify-center rounded-md border border-slate-700 px-2 py-1 text-[12px] text-slate-100"
          >
            Flag migrate
          </button>
        </div>

        <div className="flex gap-2">
          <button
            onClick={handleMigrate}
            disabled={migrating}
            className="inline-flex items-center justify-center w-full rounded-md bg-emerald-600 px-2 py-1 text-[12px] font-medium text-white hover:bg-emerald-700 disabled:opacity-60"
          >
            Ejecutar migrate
          </button>
        </div>

        <div className="flex gap-2">
          <button
            onClick={handleTestLoginAdmin}
            className="inline-flex items-center justify-center w-full rounded-md bg-amber-600 px-2 py-1 text-[12px] font-medium text-slate-900 hover:bg-amber-700"
          >
            Probar login admin (1000/admin123)
          </button>
        </div>

        <div className="mt-2 flex items-center justify-between text-[12px] text-slate-300">
          <div>Health:</div>
          <div className="font-mono">{health === null ? 'unknown' : health ? 'ok' : 'down'}</div>
        </div>

        <div className="mt-1 text-[11px] text-slate-400">
          Estado: <span className="font-mono">{status}</span>
        </div>
      </div>
    </div>
  )
}