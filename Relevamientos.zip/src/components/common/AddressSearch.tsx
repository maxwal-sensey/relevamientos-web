/**
 * @file AddressSearch.tsx
 * @description Input de búsqueda de direcciones con debounce, timeout y manejo robusto de AbortController.
 *              Protege contra errores de red (p.ej. "Failed to fetch") asegurando que ninguna excepción
 *              de fetch o de la función performFetch (sincrónica o asíncrona) llegue como rejection
 *              no manejado al ciclo de React. Devuelve resultados locales como fallback cuando la búsqueda
 *              remota falla o es vacía.
 */

import React, { useEffect, useRef, useState } from 'react'

/**
 * AddressResult
 * @description Representa un resultado de búsqueda de dirección.
 */
export interface AddressResult {
  id: string
  text: string
  lat?: number
  lon?: number
}

/**
 * AddressSearchProps
 * @description Props del componente AddressSearch.
 */
interface AddressSearchProps {
  placeholder?: string
  /**
   * Callback que recibe los resultados (se llama de forma silenciosa ante errores).
   */
  onResults?: (results: AddressResult[]) => void
  /**
   * Función opcional para realizar la búsqueda (útil para tests o mocks).
   * Si no se provee, se usa fetch interno hacia Nominatim.
   */
  performFetch?: (query: string, signal: AbortSignal) => Promise<AddressResult[]>
}

/**
 * AddressSearch
 * @description Input con debounce que realiza búsquedas y maneja correctamente AbortController,
 *              timeouts y evita actualizar estado después del unmount. Maneja entradas con número
 *              catastrales de forma segura y evita propagar errores "Failed to fetch".
 */
export default function AddressSearch({
  placeholder = 'Buscar dirección...',
  onResults,
  performFetch,
}: AddressSearchProps) {
  const [query, setQuery] = useState('')
  const [results, setResults] = useState<AddressResult[]>([])
  const [loading, setLoading] = useState(false)
  const [errorMsg, setErrorMsg] = useState<string | null>(null)

  /** Referencia al AbortController de la petición en curso (si existe). */
  const controllerRef = useRef<AbortController | null>(null)
  /** Debounce timer id. */
  const debounceRef = useRef<number | null>(null)
  /** Timeout id para el fetch. */
  const fetchTimeoutRef = useRef<number | null>(null)
  /** Mounted flag para evitar setState después del unmount. */
  const mountedRef = useRef(true)

  useEffect(() => {
    mountedRef.current = true
    return () => {
      mountedRef.current = false
      // Cleanup timers y abortar petición en curso al desmontar
      if (debounceRef.current) {
        window.clearTimeout(debounceRef.current)
        debounceRef.current = null
      }
      if (fetchTimeoutRef.current) {
        window.clearTimeout(fetchTimeoutRef.current)
        fetchTimeoutRef.current = null
      }
      if (controllerRef.current && !controllerRef.current.signal.aborted) {
        try {
          controllerRef.current.abort()
        } catch {
          // Silenciar cualquier excepción al abortar
        }
        controllerRef.current = null
      }
    }
  }, [])

  /**
   * defaultFetch
   * @description Implementación por defecto que realiza una llamada fetch a Nominatim.
   *              Esta función NUNCA lanza errores hacia arriba: captura AbortError y cualquier
   *              otro fallo de red/parsing y devuelve un arreglo vacío, para evitar "Failed to fetch"
   *              propagado al componente.
   */
  async function defaultFetch(queryText: string, signal: AbortSignal): Promise<AddressResult[]> {
    // Protección extra: si fetch no está disponible, devolvemos []
    if (typeof fetch !== 'function') return []

    const encoded = encodeURIComponent(queryText.trim())
    const url = `https://nominatim.openstreetmap.org/search?q=${encoded}&format=json&limit=6`

    try {
      const res = await fetch(url, { signal })
      if (!res.ok) {
        // Devolver vacío en caso de status no-ok
        return []
      }
      const data = await res.json()
      return (data || []).map((d: any, idx: number) => ({
        id: d.place_id ? String(d.place_id) : `${Date.now()}-${idx}`,
        text: d.display_name ?? `${d.lat},${d.lon}`,
        lat: d.lat ? Number(d.lat) : undefined,
        lon: d.lon ? Number(d.lon) : undefined,
      }))
    } catch (err: any) {
      // Capturamos cualquier error (incluyendo AbortError y "Failed to fetch") y devolvemos []
      // Esto garantiza que nunca habrá un rejection no manejado proveniente de aquí.
      return []
    }
  }

  /**
   * safePerformSearch
   * @description Ejecuta una búsqueda protegida: cancela la petición anterior, crea un nuevo
   *              AbortController, aplica timeout y gestiona errores (incluyendo AbortError).
   *              Garantiza que nunca se propague "Failed to fetch" al hilo de ejecución del componente.
   *
   * Notas importantes:
   * - Evitamos Promise.resolve(fn(...)).catch(...) porque la invocación fn(...) se evalúa antes y
   *   puede lanzar sincronamente provocando que la excepción escape. En su lugar, llamamos a fn(...)
   *   dentro de un try/catch y luego await del resultado con Promise.resolve para cubrir tanto
   *   retornos sync como promesas.
   */
  async function safePerformSearch(q: string) {
    // Normalizar consulta
    const queryText = q.trim()
    if (!queryText) {
      if (mountedRef.current) {
        setResults([])
        onResults?.([])
        setLoading(false)
        setErrorMsg(null)
      }
      return
    }

    // Reiniciar estado visual
    setErrorMsg(null)
    setLoading(true)

    // Cancelar petición previa si existe
    if (controllerRef.current && !controllerRef.current.signal.aborted) {
      try {
        controllerRef.current.abort()
      } catch {
        // silenciar
      }
      controllerRef.current = null
    }

    // Crear nuevo controller para la petición actual
    const controller = new AbortController()
    controllerRef.current = controller

    // Establecer timeout para la petición (ej. 8s)
    if (fetchTimeoutRef.current) {
      window.clearTimeout(fetchTimeoutRef.current)
      fetchTimeoutRef.current = null
    }
    fetchTimeoutRef.current = window.setTimeout(() => {
      if (controllerRef.current && !controllerRef.current.signal.aborted) {
        try {
          controllerRef.current.abort()
        } catch {
          // silenciar
        }
      }
    }, 8000)

    // Llamada al fetch protegida: manejamos tanto throws síncronos como rechazos asíncronos
    try {
      const fn = performFetch ?? defaultFetch
      const signalToUse = controllerRef.current ? controllerRef.current.signal : controller.signal

      let remoteResults: AddressResult[] = []

      try {
        // Ejecutamos la función dentro de try/catch para atrapar throws síncronos
        // y luego 'await' su resultado (que puede ser una promesa o un valor directo)
        const maybePromise = fn(queryText, signalToUse)
        remoteResults = await Promise.resolve(maybePromise)
      } catch {
        // Si la función custom/default falla (sync o async), devolvemos vacío para fallback
        remoteResults = []
      }

      // Si el componente ya no está montado o la petición fue abortada, salir silenciosamente
      if (!mountedRef.current) return
      if (signalToUse.aborted) return

      // Si la búsqueda remota devolvió resultados vacíos, aplicar fallback local y mensaje amistoso.
      if (!remoteResults || remoteResults.length === 0) {
        const fallback: AddressResult[] = [
          { id: `m-1-${Date.now()}`, text: `${queryText} 1 (resultado local)` },
          { id: `m-2-${Date.now()}`, text: `${queryText} 2 (resultado local)` },
        ]
        if (mountedRef.current) {
          setResults(fallback)
          onResults?.(fallback)
          setErrorMsg('No se pudo completar la búsqueda remota; mostrando resultados locales.')
        }
        return
      }

      // Resultados válidos: actualizar estado
      if (mountedRef.current) {
        setResults(remoteResults)
        onResults?.(remoteResults)
      }
    } catch {
      // Backup: en caso extremo, aplicamos fallback local
      if (!mountedRef.current) return
      const fallback: AddressResult[] = [
        { id: `m-1-${Date.now()}`, text: `${queryText} 1 (resultado local)` },
        { id: `m-2-${Date.now()}`, text: `${queryText} 2 (resultado local)` },
      ]
      setResults(fallback)
      onResults?.(fallback)
      setErrorMsg('No se pudo completar la búsqueda; mostrando resultados locales.')
    } finally {
      // Cleanup timeout
      if (fetchTimeoutRef.current) {
        window.clearTimeout(fetchTimeoutRef.current)
        fetchTimeoutRef.current = null
      }
      // Sólo limpiar loading si el componente sigue montado
      if (mountedRef.current) {
        setLoading(false)
      }
      // Liberar controller si aún apunta al actual
      if (controllerRef.current === controller) {
        controllerRef.current = null
      }
    }
  }

  /**
   * handleChange
   * @description Dispara la búsqueda con debounce. Asegura que no se creen múltiples timers
   *              y que cualquier rechazo esté manejado.
   */
  function handleChange(next: string) {
    setQuery(next)
    setErrorMsg(null)

    if (debounceRef.current) {
      window.clearTimeout(debounceRef.current)
      debounceRef.current = null
    }

    // No buscar si la consulta está vacía
    if (!next.trim()) {
      if (controllerRef.current && !controllerRef.current.signal.aborted) {
        try {
          controllerRef.current.abort()
        } catch {
          /* silenciar */
        }
        controllerRef.current = null
      }
      setResults([])
      onResults?.([])
      setLoading(false)
      return
    }

    // Debounce: si el usuario está agregando número catastral rápidamente, esperar un poco más
    const debounceMs = /\d/.test(next) ? 450 : 350
    debounceRef.current = window.setTimeout(() => {
      // Ejecutar búsqueda; capturamos cualquier rechazo para evitar unhandled promise
      safePerformSearch(next).catch(() => {
        // Errores ya manejados dentro de safePerformSearch
      })
      debounceRef.current = null
    }, debounceMs)
  }

  /**
   * handleSelect
   * @description Al seleccionar un resultado, colocamos el texto en el input y notificamos al caller.
   *              No dispara una nueva búsqueda innecesaria.
   */
  function handleSelect(r: AddressResult) {
    setQuery(r.text)
    // cancelar petición en curso (ya que el usuario eligió un resultado)
    if (controllerRef.current && !controllerRef.current.signal.aborted) {
      try {
        controllerRef.current.abort()
      } catch {
        // silenciar
      }
      controllerRef.current = null
    }
    setResults([])
    onResults?.([r])
  }

  return (
    <div className="w-full">
      <div className="mb-2">
        <input
          value={query}
          onChange={(e) => handleChange(e.target.value)}
          placeholder={placeholder}
          className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm"
          aria-label="Buscar dirección"
        />
      </div>

      {loading && <div className="text-xs text-slate-500">Buscando…</div>}

      {errorMsg && <div className="mt-2 text-xs text-amber-600">{errorMsg}</div>}

      <ul className="mt-2 max-h-44 overflow-auto space-y-1">
        {results.map((r) => (
          <li
            key={r.id}
            className="cursor-pointer rounded px-2 py-1 text-sm hover:bg-slate-100"
            onMouseDown={(e) => {
              /**
               * Usamos onMouseDown en vez de onClick para evitar que el input pierda foco
               * antes de que el parent pueda leer el valor (evita race conditions en forms).
               */
              e.preventDefault()
              handleSelect(r)
            }}
          >
            {r.text}
          </li>
        ))}
      </ul>
    </div>
  )
}
