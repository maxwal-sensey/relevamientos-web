/**
 * @file MapPreview.tsx
 * @description Componente que muestra un preview de mapa embebido de OpenStreetMap
 *              centrado en las coordenadas proporcionadas. Si no hay coordenadas,
 *              muestra un placeholder.
 */

import React from 'react'

/**
 * MapPreviewProps
 * @description Props del componente MapPreview.
 */
interface MapPreviewProps {
  lat?: number | null
  lng?: number | null
  zoom?: number
  height?: string
}

/**
 * buildOsmEmbedUrl
 * @description Construye la URL para embeber OpenStreetMap con marcador centrado.
 * @param lat Latitud
 * @param lng Longitud
 * @param zoom Nivel de zoom
 * @returns URL string
 */
function buildOsmEmbedUrl(lat: number, lng: number, zoom = 16) {
  // Usamos el parámetro marker para centrar el mapa en la ubicación indicada.
  // No todos los parámetros de OSM son documentados como API pública, pero el embed funciona.
  const bboxDelta = 0.01
  const left = lng - bboxDelta
  const bottom = lat - bboxDelta
  const right = lng + bboxDelta
  const top = lat + bboxDelta
  return `https://www.openstreetmap.org/export/embed.html?bbox=${left},${bottom},${right},${top}&layer=mapnik&marker=${lat},${lng}&zoom=${zoom}`
}

/**
 * MapPreview
 * @description Muestra un iframe de OpenStreetMap si hay coordenadas; de lo contrario
 *              muestra un placeholder informativo.
 */
export default function MapPreview({ lat, lng, zoom = 16, height = 'h-48' }: MapPreviewProps) {
  const hasCoords = typeof lat === 'number' && typeof lng === 'number' && !isNaN(lat) && !isNaN(lng)

  return (
    <div className="rounded-md border border-slate-800 bg-slate-900/50 p-1">
      {hasCoords ? (
        <div className={`overflow-hidden rounded-sm border border-slate-800 ${height}`}>
          <iframe
            title="Mapa de ubicación"
            src={buildOsmEmbedUrl(lat as number, lng as number, zoom)}
            className="h-full w-full"
            loading="lazy"
          />
        </div>
      ) : (
        <div className={`flex h-48 items-center justify-center rounded-sm bg-slate-800/50 text-sm text-slate-400 ${height}`}>
          Coordenadas no disponibles
        </div>
      )}
    </div>
  )
}