/**
 * @file RecipientAutocomplete.tsx
 * @description Componente Autocomplete / Combobox multi-select para elegir destinatarios.
 */

import { useEffect, useMemo, useRef, useState } from 'react'
import type { DemoUser } from '../../mock/demoUsers'
import { Check, X } from 'lucide-react'

/**
 * RecipientAutocompleteProps
 * @description Props para el autocomplete de destinatarios.
 */
interface RecipientAutocompleteProps {
  /** Lista completa de candidatos (usuarios) */
  recipients: DemoUser[]
  /** Ids seleccionados (controlado) */
  selectedIds: string[]
  /** Callback al cambiar selección */
  onChange: (ids: string[]) => void
  /** Placeholder del input */
  placeholder?: string
}

/**
 * RecipientAutocomplete
 * @description Combobox con búsqueda y multi-select para seleccionar destinatarios.
 */
export default function RecipientAutocomplete({
  recipients,
  selectedIds,
  onChange,
  placeholder = 'Buscar por nombre, apellido o legajo...',
}: RecipientAutocompleteProps) {
  const [query, setQuery] = useState('')
  const [isOpen, setIsOpen] = useState(false)
  const [highlightIndex, setHighlightIndex] = useState(0)
  const inputRef = useRef<HTMLInputElement | null>(null)
  const containerRef = useRef<HTMLDivElement | null>(null)

  /**
   * formatDisplayName
   * @description Devuelve la representación legible de un usuario demo.
   */
  function formatDisplayName(user: DemoUser) {
    return `${user.apellido}, ${user.nombre} (${user.legajo})`
  }

  /**
   * filtered
   * @description Lista filtrada según la query.
   */
  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase()
    if (!q) return recipients
    return recipients.filter((u) => {
      return (
        u.legajo.toLowerCase().includes(q) ||
        `${u.nombre} ${u.apellido}`.toLowerCase().includes(q) ||
        `${u.apellido} ${u.nombre}`.toLowerCase().includes(q) ||
        formatDisplayName(u).toLowerCase().includes(q)
      )
    })
  }, [query, recipients])

  useEffect(() => {
    // reset highlight when list changes
    setHighlightIndex(0)
  }, [query, isOpen])

  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (
        containerRef.current &&
        !containerRef.current.contains(e.target as Node)
      ) {
        setIsOpen(false)
      }
    }
    document.addEventListener('click', handleClickOutside)
    return () => document.removeEventListener('click', handleClickOutside)
  }, [])

  /**
   * toggleId
   * @description Añade o quita un id de la selección.
   */
  function toggleId(id: string) {
    if (selectedIds.includes(id)) {
      onChange(selectedIds.filter((s) => s !== id))
    } else {
      onChange([...selectedIds, id])
    }
    setQuery('')
    inputRef.current?.focus()
  }

  /**
   * removeLast
   * @description Elimina el último seleccionado (utilizado en Backspace).
   */
  function removeLast() {
    if (selectedIds.length === 0) return
    const next = selectedIds.slice(0, -1)
    onChange(next)
  }

  /**
   * handleKeyDown
   * @description Maneja navegación por teclado dentro del combobox.
   */
  function handleKeyDown(e: React.KeyboardEvent<HTMLInputElement>) {
    if (e.key === 'ArrowDown') {
      e.preventDefault()
      setIsOpen(true)
      setHighlightIndex((i) => Math.min(i + 1, filtered.length - 1))
      return
    }
    if (e.key === 'ArrowUp') {
      e.preventDefault()
      setHighlightIndex((i) => Math.max(i - 1, 0))
      return
    }
    if (e.key === 'Enter') {
      e.preventDefault()
      const item = filtered[highlightIndex]
      if (item) toggleId(String(item.id))
      return
    }
    if (e.key === 'Escape') {
      setIsOpen(false)
      return
    }
    if (e.key === 'Backspace' && query === '') {
      removeLast()
      return
    }
  }

  return (
    <div ref={containerRef} className="relative">
      <div
        className="flex flex-wrap items-center gap-2 rounded-md border border-slate-700 bg-slate-800 px-2 py-1"
        onClick={() => {
          setIsOpen(true)
          inputRef.current?.focus()
        }}
      >
        {selectedIds.map((id) => {
          const u = recipients.find((r) => String(r.id) === id)
          if (!u) return null
          return (
            <span
              key={id}
              className="flex items-center gap-2 rounded-full bg-slate-700 px-2 py-0.5 text-xs text-slate-100"
            >
              <span>{formatDisplayName(u)}</span>
              <button
                type="button"
                aria-label={`Quitar ${u.nombre}`}
                onClick={(e) => {
                  e.stopPropagation()
                  toggleId(id)
                }}
                className="rounded-full p-0.5 text-slate-300 hover:text-white"
              >
                <X className="h-3 w-3" />
              </button>
            </span>
          )
        })}

        <input
          ref={inputRef}
          value={query}
          onChange={(e) => {
            setQuery(e.target.value)
            setIsOpen(true)
          }}
          onKeyDown={handleKeyDown}
          placeholder={placeholder}
          className="min-w-[120px] flex-1 bg-transparent text-sm text-slate-100 placeholder:text-slate-400 focus:outline-none"
        />
      </div>

      {isOpen && filtered.length > 0 && (
        <ul className="absolute z-50 mt-1 max-h-56 w-full overflow-auto rounded-md bg-slate-900/95 p-1 shadow-lg">
          {filtered.map((r, idx) => {
            const id = String(r.id)
            const isSelected = selectedIds.includes(id)
            const isHighlighted = idx === highlightIndex
            return (
              <li
                key={id}
                role="option"
                aria-selected={isHighlighted}
                onMouseDown={(e) => {
                  // use mouseDown to prevent blur before click
                  e.preventDefault()
                  toggleId(id)
                }}
                onMouseEnter={() => setHighlightIndex(idx)}
                className={`flex cursor-pointer items-center justify-between gap-2 rounded-md px-2 py-2 text-sm hover:bg-slate-800 ${
                  isHighlighted ? 'bg-slate-800' : ''
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className="text-xs text-slate-400">
                    {r.dependenciaNombre ? r.dependenciaNombre : ''}
                  </div>
                  <div className="text-sm text-slate-100">
                    {formatDisplayName(r)}
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  {isSelected ? <Check className="h-4 w-4 text-sky-400" /> : null}
                </div>
              </li>
            )
          })}
        </ul>
      )}

      {isOpen && filtered.length === 0 && (
        <div className="absolute z-50 mt-1 w-full rounded-md bg-slate-900/95 p-2 text-sm text-slate-400 shadow">
          No hay coincidencias.
        </div>
      )}
    </div>
  )
}