/**
 * @file Sidebar.tsx
 * @description Barra lateral principal con navegación de la aplicación e indicador (badge)
 *              de mensajes no leídos filtrado por dependencia del usuario autenticado.
 */

import { useEffect, useState } from 'react'
import { NavLink } from 'react-router'
import {
  Home,
  FileText,
  MessageCircle,
  Users,
  Layers,
  BarChart2,
  Bell,
} from 'lucide-react'
import { useSystemUser } from '../../context/SystemUserContext'
import { getUnreadCount } from '../../mock/messagesStore'

/**
 * Sidebar
 * @description Componente de navegación lateral; muestra links a secciones clave y
 *              un badge con la cantidad de notificaciones sin leer del usuario actual.
 */
export default function Sidebar() {
  const { currentUser } = useSystemUser()
  const [unread, setUnread] = useState<number>(0)

  /**
   * getDisplayName
   * @description Construye el nombre legible usado en el store de mensajes: "Apellido, Nombre".
   * @returns string | null
   */
  function getDisplayName(): string | null {
    if (!currentUser) return null
    return `${currentUser.apellido}, ${currentUser.nombre}`
  }

  /**
   * refreshUnread
   * @description Actualiza el contador de mensajes sin leer consultando el store demo.
   */
  function refreshUnread() {
    const name = getDisplayName()
    if (!name) {
      setUnread(0)
      return
    }
    const count = getUnreadCount(name)
    setUnread(count)
  }

  useEffect(() => {
    // Primera carga
    refreshUnread()
    // Polling ligero para mantener badge actualizado en demo
    const id = setInterval(refreshUnread, 2500)
    return () => clearInterval(id)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [currentUser?.id, currentUser?.dependenciaId])

  const linkBase =
    'flex items-center gap-3 rounded-md px-3 py-2 text-sm hover:bg-slate-800 transition-colors'

  return (
    <aside className="w-64 shrink-0 bg-gradient-to-b from-sky-900 to-sky-800 text-slate-100">
      <div className="px-4 py-5">
        <div className="mb-6 flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-md bg-white/10">
            <Layers className="h-5 w-5 text-white" />
          </div>
          <div>
            <h1 className="text-sm font-semibold">SGR</h1>
            <p className="text-xs text-slate-200/80">Ministerio de Seguridad</p>
          </div>
        </div>

        <nav className="space-y-1">
          <NavLink
            to="/dashboard"
            className={({ isActive }: any) =>
              `${linkBase} ${isActive ? 'bg-slate-800 font-medium' : 'text-slate-200'}`
            }
          >
            <Home className="h-4 w-4" />
            <span>Dashboard</span>
          </NavLink>

          <NavLink
            to="/solicitudes"
            className={({ isActive }: any) =>
              `${linkBase} ${isActive ? 'bg-slate-800 font-medium' : 'text-slate-200'}`
            }
          >
            <FileText className="h-4 w-4" />
            <span>Solicitudes</span>
          </NavLink>

          <NavLink
            to="/relevamientos"
            className={({ isActive }: any) =>
              `${linkBase} ${isActive ? 'bg-slate-800 font-medium' : 'text-slate-200'}`
            }
          >
            <Users className="h-4 w-4" />
            <span>Relevamientos</span>
          </NavLink>

          <NavLink
            to="/estadisticas"
            className={({ isActive }: any) =>
              `${linkBase} ${isActive ? 'bg-slate-800 font-medium' : 'text-slate-200'}`
            }
          >
            <BarChart2 className="h-4 w-4" />
            <span>Estadísticas</span>
          </NavLink>

          <NavLink
            to="/notificaciones"
            className={({ isActive }: any) =>
              `${linkBase} ${isActive ? 'bg-slate-800 font-medium' : 'text-slate-200'} justify-between`
            }
          >
            <div className="flex items-center gap-3">
              <MessageCircle className="h-4 w-4" />
              <span>Notificaciones</span>
            </div>

            {/* Badge de mensajes no leídos */}
            {unread > 0 ? (
              <span className="ml-2 rounded-full bg-red-600 px-2 py-0.5 text-xs font-semibold text-white">
                {unread}
              </span>
            ) : null}
          </NavLink>

          <div className="mt-4 border-t border-slate-700 pt-4">
            <NavLink
              to="/usuarios"
              className={({ isActive }: any) =>
                `${linkBase} ${isActive ? 'bg-slate-800 font-medium' : 'text-slate-200'}`
              }
            >
              <Users className="h-4 w-4" />
              <span>Usuarios</span>
            </NavLink>

            <NavLink
              to="/dependencias"
              className={({ isActive }: any) =>
                `${linkBase} ${isActive ? 'bg-slate-800 font-medium' : 'text-slate-200'}`
              }
            >
              <Bell className="h-4 w-4" />
              <span>Dependencias</span>
            </NavLink>

            <NavLink
              to="/jerarquias"
              className={({ isActive }: any) =>
                `${linkBase} ${isActive ? 'bg-slate-800 font-medium' : 'text-slate-200'}`
              }
            >
              <Layers className="h-4 w-4" />
              <span>Jerarquías</span>
            </NavLink>
          </div>
        </nav>
      </div>
    </aside>
  )
}