/**
 * @file DependencyFormModal.tsx
 * @description Modal de formulario para alta/edición de dependencias en la vista demo.
 */

import { useEffect, useState } from 'react'
import type { DemoDependencia } from '../../mock/dependenciasStore'

/**
 * DependencyFormMode
 * @description Modo del formulario: creación o edición.
 */
export type DependencyFormMode = 'create' | 'edit'

/**
 * DependencyFormValues
 * @description Valores gestionados en el formulario de dependencias.
 */
export interface DependencyFormValues {
  nombre: string
  descripcion: string
}

/**
 * DependencyFormModalProps
 * @description Propiedades del modal de alta/edición de dependencias.
 */
interface DependencyFormModalProps {
  /** Indica si el modal está visible. */
  open: boolean
  /** Modo del formulario: creación o edición. */
  mode: DependencyFormMode
  /** Dependencia inicial para modo edición (opcional). */
  initialDependency?: DemoDependencia
  /** Callback al cerrar el modal sin enviar. */
  onClose: () => void
  /** Callback al enviar el formulario con datos válidos. */
  onSubmit: (values: DependencyFormValues) => void
}

/**
 * FormErrors
 * @description Estructura básica de errores de validación.
 */
interface FormErrors {
  nombre?: string
}

/**
 * buildInitialValues
 * @description Construye los valores iniciales según el modo y la dependencia recibida.
 */
function buildInitialValues(
  mode: DependencyFormMode,
  dependency?: DemoDependencia | null
): DependencyFormValues {
  if (mode === 'edit' && dependency) {
    return {
      nombre: dependency.nombre,
      descripcion: dependency.descripcion ?? '',
    }
  }

  return {
    nombre: '',
    descripcion: '',
  }
}

/**
 * DependencyFormModal
 * @description Modal con formulario controlado para crear o editar dependencias (sin persistencia real en la demo).
 */
export function DependencyFormModal({
  open,
  mode,
  initialDependency,
  onClose,
  onSubmit,
}: DependencyFormModalProps) {
  const [values, setValues] = useState<DependencyFormValues>(() =>
    buildInitialValues(mode, initialDependency ?? null)
  )
  const [errors, setErrors] = useState<FormErrors>({})

  /**
   * @description Sincroniza valores y errores al abrir el modal o cambiar modo/dependencia inicial.
   */
  useEffect(() => {
    if (open) {
      setValues(buildInitialValues(mode, initialDependency ?? null))
      setErrors({})
    }
  }, [open, mode, initialDependency])

  /**
   * handleChange
   * @description Actualiza un campo concreto del formulario.
   */
  const handleChange = <K extends keyof DependencyFormValues>(
    field: K,
    value: DependencyFormValues[K]
  ) => {
    setValues((prev) => ({
      ...prev,
      [field]: value,
    }))
  }

  /**
   * validate
   * @description Valida campos mínimos requeridos y actualiza errores.
   */
  const validate = (): boolean => {
    const nextErrors: FormErrors = {}

    if (!values.nombre.trim()) {
      nextErrors.nombre = 'El nombre de la dependencia es obligatorio.'
    }

    setErrors(nextErrors)
    return Object.keys(nextErrors).length === 0
  }

  /**
   * handleSubmit
   * @description Gestiona el envío del formulario, valida y notifica al componente padre.
   */
  const handleSubmit = (event: React.FormEvent) => {
    event.preventDefault()
    if (!validate()) return
    onSubmit(values)
  }

  if (!open) {
    return null
  }

  return (
    <div className="fixed inset-0 z-40 flex items-center justify-center bg-slate-950/60 px-4 py-6">
      <div
        role="dialog"
        aria-modal="true"
        aria-label={
          mode === 'create'
            ? 'Crear nueva dependencia'
            : 'Editar dependencia existente'
        }
        className="relative w-full max-w-md rounded-xl border border-slate-700 bg-slate-950 text-slate-50 shadow-xl"
      >
        {/* Cabecera */}
        <header className="flex items-start justify-between border-b border-slate-800 px-5 py-3">
          <div>
            <h2 className="text-sm font-semibold text-slate-50">
              {mode === 'create' ? 'Nueva dependencia' : 'Editar dependencia'}
            </h2>
            <p className="mt-0.5 text-xs text-slate-400">
              Este formulario es solo de demostración: los cambios no se
              guardan todavía en la base de datos real.
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="inline-flex h-7 w-7 items-center justify-center rounded-full text-slate-400 hover:bg-slate-800 hover:text-slate-100"
          >
            <span className="text-sm leading-none">&times;</span>
            <span className="sr-only">Cerrar</span>
          </button>
        </header>

        {/* Contenido del formulario */}
        <form onSubmit={handleSubmit} className="space-y-4 px-5 py-4">
          {/* Nombre */}
          <div>
            <label className="mb-1 block text-xs font-medium text-slate-300">
              Nombre de la dependencia *
            </label>
            <input
              type="text"
              value={values.nombre}
              onChange={(e) => handleChange('nombre', e.target.value)}
              className="block w-full rounded-md border border-slate-700 bg-slate-900 px-2 py-1.5 text-xs text-slate-100 placeholder:text-slate-500 focus:border-sky-500 focus:outline-none focus:ring-1 focus:ring-sky-500"
              placeholder="Ej: Comisaría 3ra. La Plata"
            />
            {errors.nombre && (
              <p className="mt-1 text-[11px] text-red-400">{errors.nombre}</p>
            )}
          </div>

          {/* Descripción */}
          <div>
            <label className="mb-1 block text-xs font-medium text-slate-300">
              Descripción
            </label>
            <textarea
              value={values.descripcion}
              onChange={(e) => handleChange('descripcion', e.target.value)}
              rows={3}
              className="block w-full rounded-md border border-slate-700 bg-slate-900 px-2 py-1.5 text-xs text-slate-100 placeholder:text-slate-500 focus:border-sky-500 focus:outline-none focus:ring-1 focus:ring-sky-500"
              placeholder="Describe brevemente la dependencia, zona de cobertura, etc."
            />
          </div>

          {/* Pie del formulario */}
          <div className="mt-2 flex flex-col gap-2 border-t border-slate-800 pt-3 text-[11px] text-slate-400">
            <p>
              En la versión integrada con backend, aquí se crearán o
              actualizarán registros en la tabla <span className="font-mono">dependencias</span> de D1.
              En esta demo solo se muestra la experiencia de usuario.
            </p>
            <div className="flex items-center justify-end gap-2 pt-1">
              <button
                type="button"
                onClick={onClose}
                className="inline-flex items-center justify-center rounded-md border border-slate-700 px-3 py-1.5 text-xs font-medium text-slate-100 hover:bg-slate-800"
              >
                Cancelar
              </button>
              <button
                type="submit"
                className="inline-flex items-center justify-center rounded-md bg-sky-600 px-3 py-1.5 text-xs font-semibold text-white shadow-sm hover:bg-sky-700"
              >
                {mode === 'create'
                  ? 'Crear dependencia'
                  : 'Guardar cambios'}
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  )
}