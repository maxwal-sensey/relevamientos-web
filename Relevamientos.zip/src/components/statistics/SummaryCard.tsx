/**
 * @file SummaryCard.tsx
 * @description Componente pequeño para mostrar una métrica de resumen (título, valor, descripción e ícono).
 */

import type { ReactNode } from 'react'

/**
 * SummaryCardProps
 * @description Propiedades del componente SummaryCard.
 */
interface SummaryCardProps {
  /** Título de la tarjeta */
  title: string
  /** Valor principal mostrado */
  value: string
  /** Texto descriptivo secundario */
  description?: string
  /** Icono a la derecha */
  icon?: ReactNode
  /** Clase de color para la franja superior */
  accentColorClass?: string
}

/**
 * SummaryCard
 * @description Tarjeta compacta que muestra una métrica con acento visual.
 */
export default function SummaryCard({
  title,
  value,
  description,
  icon,
  accentColorClass = 'bg-sky-500',
}: SummaryCardProps) {
  return (
    <div className="relative overflow-hidden rounded-xl border border-slate-800 bg-slate-900/60 px-4 py-4 shadow-sm">
      <div className={`absolute inset-x-0 top-0 h-1 ${accentColorClass} opacity-80`} />
      <div className="flex items-start justify-between gap-3">
        <div className="space-y-1">
          <p className="text-xs font-medium uppercase tracking-wide text-slate-400">{title}</p>
          <p className="text-2xl font-semibold text-slate-50">{value}</p>
          {description && <p className="text-xs text-slate-400">{description}</p>}
        </div>
        <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-slate-800/80 text-slate-100">
          {icon}
        </div>
      </div>
    </div>
  )
}