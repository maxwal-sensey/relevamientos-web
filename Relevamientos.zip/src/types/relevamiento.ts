/**
 * @file relevamiento.ts
 * @description Tipos compartidos para el módulo de relevamientos.
 */

/**
 * @interface OpcionSolicitud
 * @description Representa una solicitud pendiente seleccionable para un relevamiento.
 */
export interface OpcionSolicitud {
  id: number
  numeroRegistro: string
  ipp: string
  fiscalia: string
  caratula: string
  lugar: string
  resumenHecho: string
}

/**
 * @interface CameraEntry
 * @description Datos de una cámara relevada dentro del formulario.
 */
export interface CameraEntry {
  id: number
  lugar: string
  tipoCamara: 'privada' | 'com'
  accion:
    | 'solicito_grabacion'
    | 'no_graba'
    | 'no_apunta'
    | 'negativa'
    | 'entrega_material'
    | 'otro'
  entrevistadoNombre: string
  entrevistadoApellido: string
  observaciones: string
}

/**
 * @interface VecinoEntry
 * @description Datos de un vecino entrevistado dentro del formulario.
 */
export interface VecinoEntry {
  id: number
  lugar: string
  nombre: string
  apellido: string
  dni: string
  presencio: boolean
  conocimiento: boolean
  sinCamaras: boolean
  camarasNoGraban: boolean
  camarasNoDanLugar: boolean
  observaciones: string
}