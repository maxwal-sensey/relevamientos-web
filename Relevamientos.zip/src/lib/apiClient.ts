/**
 * @file apiClient.ts
 * @description Cliente API ligero que decide entre uso de mocks o llamadas HTTP reales.
 *              Se extendió para incluir CRUD de users, dependencias y jerarquías.
 */

import { API_BASE, USE_MOCKS } from '@/config/serverConfig'
import * as mockApi from './mockApi'

/**
 * @description Tiempo por defecto para health-check (ms).
 */
const HEALTH_TIMEOUT = 3000

/**
 * healthCheck
 * @description Consulta el endpoint /health del backend (si no hay backend, rechaza).
 * @returns Promise<boolean> true si backend responde 200 en tiempo.
 */
export async function healthCheck(): Promise<boolean> {
  if (USE_MOCKS) return Promise.resolve(true)
  try {
    const controller = new AbortController()
    const id = setTimeout(() => controller.abort(), HEALTH_TIMEOUT)
    const res = await fetch(`${API_BASE.replace(/\/$/, '')}/health`, { method: 'GET', signal: controller.signal })
    clearTimeout(id)
    return res.ok
  } catch (err) {
    return false
  }
}

/**
 * listMessages
 * @description Lista mensajes, delega al mock o al endpoint real.
 */
export async function listMessages() {
  if (USE_MOCKS) {
    return mockApi.listMessages()
  }
  const res = await fetch(`${API_BASE.replace(/\/$/, '')}/messages`)
  if (!res.ok) throw new Error('Error listando mensajes')
  return res.json()
}

/**
 * sendMessage
 * @description Envía un mensaje. Si se usa backend real, espera JSON; con mock usa mockApi.sendMessage.
 * @param payload FormData o datos objeto (cuando USE_MOCKS true usa objeto compatible con mockApi.SendMessageInput).
 */
export async function sendMessage(payload: FormData | any) {
  if (USE_MOCKS) {
    const input = {
      from: payload.get ? String(payload.get('from') ?? '') : payload.from,
      to: payload.get ? String(payload.get('to') ?? '') : payload.to,
      subject: payload.get ? String(payload.get('subject') ?? '') : payload.subject,
      body: payload.get ? String(payload.get('body') ?? '') : payload.body,
      attachments: [], // mockApi expects metadata; real uploads not simulated here
      solicitudId: payload.get ? String(payload.get('solicitudId') ?? '') : payload.solicitudId,
    }
    return mockApi.sendMessage(input)
  }

  // Backend real: enviar multipart/form-data
  const res = await fetch(`${API_BASE.replace(/\/$/, '')}/messages`, {
    method: 'POST',
    body: payload,
  })
  if (!res.ok) {
    const text = await res.text().catch(() => '')
    throw new Error(`Error enviando mensaje: ${res.status} ${text}`)
  }
  return res.json()
}

/**
 * getAttachmentsForSolicitud
 * @description Obtiene attachments para una solicitud (delegado).
 */
export async function getAttachmentsForSolicitud(solicitudId: string | number) {
  if (USE_MOCKS) {
    return mockApi.getAttachmentsForSolicitud(solicitudId)
  }
  const res = await fetch(`${API_BASE.replace(/\/$/, '')}/attachments/solicitud/${encodeURIComponent(String(solicitudId))}`)
  if (!res.ok) throw new Error('Error al obtener attachments')
  return res.json()
}

/**
 * getAttachmentBlob
 * @description Descarga un attachment (delegado a mock o endpoint real).
 */
export async function getAttachmentBlob(messageId: number, attachmentIndex: number): Promise<Blob> {
  if (USE_MOCKS) {
    return mockApi.getAttachmentBlob(messageId, attachmentIndex)
  }
  const res = await fetch(`${API_BASE.replace(/\/$/, '')}/attachments/${messageId}/${attachmentIndex}`)
  if (!res.ok) throw new Error('No se pudo descargar adjunto')
  return res.blob()
}

/**
 * ----------------------------
 * Users / Dependencias / Jerarquias
 * ----------------------------
 */

/**
 * listUsers
 * @description Lista usuarios desde el backend o mock.
 */
export async function listUsers() {
  if (USE_MOCKS) {
    return { ok: true, users: mockApi.getAllDemoUsers() }
  }
  const res = await fetch(`${API_BASE.replace(/\/$/, '')}/users`)
  if (!res.ok) throw new Error('Error listando usuarios')
  return res.json()
}

/**
 * createUser
 * @description Crea un usuario en backend o mock.
 */
export async function createUser(payload: any) {
  if (USE_MOCKS) {
    // mockApi no tiene creación persistente, devolver objeto simulado
    return mockApi.createDemoUser?.(payload) ?? { ok: true, user: payload }
  }
  const res = await fetch(`${API_BASE.replace(/\/$/, '')}/users`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(payload),
  })
  if (!res.ok) {
    const txt = await res.text().catch(() => '')
    throw new Error(`Error creando usuario: ${res.status} ${txt}`)
  }
  return res.json()
}

/**
 * updateUser
 */
export async function updateUser(id: number | string, payload: any) {
  if (USE_MOCKS) {
    return { ok: true, user: payload }
  }
  const res = await fetch(`${API_BASE.replace(/\/$/, '')}/users/${id}`, {
    method: 'PUT',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(payload),
  })
  if (!res.ok) {
    const txt = await res.text().catch(() => '')
    throw new Error(`Error actualizando usuario: ${res.status} ${txt}`)
  }
  return res.json()
}

/**
 * deleteUser
 */
export async function deleteUser(id: number | string) {
  if (USE_MOCKS) {
    return { ok: true }
  }
  const res = await fetch(`${API_BASE.replace(/\/$/, '')}/users/${id}`, {
    method: 'DELETE',
  })
  if (!res.ok) {
    const txt = await res.text().catch(() => '')
    throw new Error(`Error eliminando usuario: ${res.status} ${txt}`)
  }
  return res.json()
}

/**
 * Dependencias
 */
export async function listDependencias() {
  if (USE_MOCKS) {
    return { ok: true, dependencias: mockApi.getDependencias?.() ?? [] }
  }
  const res = await fetch(`${API_BASE.replace(/\/$/, '')}/dependencias`)
  if (!res.ok) throw new Error('Error listando dependencias')
  return res.json()
}

export async function createDependencia(payload: any) {
  if (USE_MOCKS) {
    return { ok: true, dependencia: payload }
  }
  const res = await fetch(`${API_BASE.replace(/\/$/, '')}/dependencias`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(payload),
  })
  if (!res.ok) {
    const txt = await res.text().catch(() => '')
    throw new Error(`Error creando dependencia: ${res.status} ${txt}`)
  }
  return res.json()
}

export async function updateDependencia(id: number | string, payload: any) {
  if (USE_MOCKS) {
    return { ok: true, dependencia: payload }
  }
  const res = await fetch(`${API_BASE.replace(/\/$/, '')}/dependencias/${id}`, {
    method: 'PUT',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(payload),
  })
  if (!res.ok) {
    const txt = await res.text().catch(() => '')
    throw new Error(`Error actualizando dependencia: ${res.status} ${txt}`)
  }
  return res.json()
}

export async function deleteDependencia(id: number | string) {
  if (USE_MOCKS) {
    return { ok: true }
  }
  const res = await fetch(`${API_BASE.replace(/\/$/, '')}/dependencias/${id}`, {
    method: 'DELETE',
  })
  if (!res.ok) {
    const txt = await res.text().catch(() => '')
    throw new Error(`Error eliminando dependencia: ${res.status} ${txt}`)
  }
  return res.json()
}

/**
 * Jerarquias
 */
export async function listJerarquias() {
  if (USE_MOCKS) {
    return { ok: true, jerarquias: mockApi.getJerarquias?.() ?? [] }
  }
  const res = await fetch(`${API_BASE.replace(/\/$/, '')}/jerarquias`)
  if (!res.ok) throw new Error('Error listando jerarquías')
  return res.json()
}

export async function createJerarquia(payload: any) {
  if (USE_MOCKS) {
    return { ok: true, jerarquia: payload }
  }
  const res = await fetch(`${API_BASE.replace(/\/$/, '')}/jerarquias`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(payload),
  })
  if (!res.ok) {
    const txt = await res.text().catch(() => '')
    throw new Error(`Error creando jerarquía: ${res.status} ${txt}`)
  }
  return res.json()
}

export async function updateJerarquia(id: number | string, payload: any) {
  if (USE_MOCKS) {
    return { ok: true, jerarquia: payload }
  }
  const res = await fetch(`${API_BASE.replace(/\/$/, '')}/jerarquias/${id}`, {
    method: 'PUT',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(payload),
  })
  if (!res.ok) {
    const txt = await res.text().catch(() => '')
    throw new Error(`Error actualizando jerarquía: ${res.status} ${txt}`)
  }
  return res.json()
}

export async function deleteJerarquia(id: number | string) {
  if (USE_MOCKS) {
    return { ok: true }
  }
  const res = await fetch(`${API_BASE.replace(/\/$/, '')}/jerarquias/${id}`, {
    method: 'DELETE',
  })
  if (!res.ok) {
    const txt = await res.text().catch(() => '')
    throw new Error(`Error eliminando jerarquía: ${res.status} ${txt}`)
  }
  return res.json()
}