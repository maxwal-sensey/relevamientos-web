/**
 * @file mockApi.ts
 * @description Mock API que persiste mensajes en localStorage para demo y simula latencia.
 */

 /** 
  * AttachmentMeta
  * @description Metadatos de adjunto guardados en el mock (sin contenido binario).
  */
 export interface AttachmentMeta {
   name: string
   size: number
   type: string
 }

 /**
  * SendMessageInput
  * @description Datos necesarios para enviar/guardar un mensaje en modo demo.
  */
 export interface SendMessageInput {
   from: string
   to: string
   subject: string
   body: string
   attachments?: AttachmentMeta[]
   solicitudId?: string | number | null
 }

 /**
  * MockMessage
  * @description Estructura persistida en localStorage.
  */
 export interface MockMessage {
   id: number
   from: string
   to: string
   subject: string
   body: string
   attachments: AttachmentMeta[]
   solicitudId?: string | number | null
   createdAt: string
 }

 /**
  * STORAGE_KEY
  * @description Clave usada en localStorage para guardar mensajes demo.
  */
 const STORAGE_KEY = 'mock_messages_v1'

 /**
  * readAll
  * @description Lee todos los mensajes desde localStorage.
  */
 function readAll(): MockMessage[] {
   try {
     const raw = localStorage.getItem(STORAGE_KEY)
     if (!raw) return []
     return JSON.parse(raw) as MockMessage[]
   } catch (e) {
     console.error('mockApi/readAll parse error', e)
     return []
   }
 }

 /**
  * writeAll
  * @description Persiste la lista completa en localStorage.
  */
 function writeAll(list: MockMessage[]) {
   localStorage.setItem(STORAGE_KEY, JSON.stringify(list))
 }

 /**
  * sendMessage
  * @description Simula envío/guardado de mensaje. Persiste metadatos y retorna cuando finaliza.
  * @param input Datos del mensaje (attachments: metadatos, no upload real)
  */
 export function sendMessage(input: SendMessageInput): Promise<MockMessage> {
   return new Promise((resolve) => {
     // simular latencia
     setTimeout(() => {
       const all = readAll()
       const nextId = all.length ? Math.max(...all.map((m) => m.id)) + 1 : 1
       const msg: MockMessage = {
         id: nextId,
         from: input.from,
         to: input.to,
         subject: input.subject,
         body: input.body,
         attachments: input.attachments ?? [],
         solicitudId: input.solicitudId ?? null,
         createdAt: new Date().toISOString(),
       }
       writeAll([msg, ...all])
       console.log('[mockApi] message saved:', msg)
       resolve(msg)
     }, 400 + Math.random() * 300)
   })
 }

 /**
  * listMessages
  * @description Retorna todos los mensajes persistidos (ordenados por fecha).
  */
 export function listMessages(): Promise<MockMessage[]> {
   return new Promise((resolve) => {
     setTimeout(() => {
       const all = readAll().sort((a, b) => +new Date(b.createdAt) - +new Date(a.createdAt))
       resolve(all)
     }, 150)
   })
 }

 /**
  * getAttachmentsForSolicitud
  * @description Retorna una lista de attachments asociados a mensajes que tienen solicitudId igual al provisto.
  * @param solicitudId Id (string|number) de la solicitud
  * @returns Promise con array de objetos { messageId, messageSubject, from, createdAt, attachment, attachmentIndex }
  */
 export async function getAttachmentsForSolicitud(solicitudId: string | number) {
   const all = await listMessages()
   const matches = all.filter((m) => String(m.solicitudId) === String(solicitudId))
   const result: Array<{
     messageId: number
     messageSubject: string
     from: string
     createdAt: string
     attachment: AttachmentMeta
     attachmentIndex: number
   }> = []
   matches.forEach((m) => {
     m.attachments.forEach((att, idx) => {
       result.push({
         messageId: m.id,
         messageSubject: m.subject,
         from: m.from,
         createdAt: m.createdAt,
         attachment: att,
         attachmentIndex: idx,
       })
     })
   })
   // ordenar por fecha del mensaje (desc)
   result.sort((a, b) => +new Date(b.createdAt) - +new Date(a.createdAt))
   return result
 }

 /**
  * getAttachmentBlob
  * @description Devuelve un Blob con contenido demo para el attachment solicitado.
  *              En producción este método se debería reemplazar por una llamada al Worker/R2.
  * @param messageId Id del mensaje
  * @param attachmentIndex Índice del attachment dentro del arreglo del mensaje
  * @returns Promise<Blob>
  */
 export async function getAttachmentBlob(messageId: number, attachmentIndex: number): Promise<Blob> {
   const all = readAll()
   const msg = all.find((m) => m.id === messageId)
   if (!msg) throw new Error('Mensaje no encontrado (mock).')
   const att = msg.attachments[attachmentIndex]
   if (!att) throw new Error('Adjunto no encontrado (mock).')
   // Generar contenido demo (placeholder)
   const content = `Archivo demo: ${att.name}\nTamaño: ${att.size} bytes\nTipo: ${att.type}\n\nEste es un archivo simulado (demo).`
   const blob = new Blob([content], { type: att.type || 'text/plain' })
   return blob
 }