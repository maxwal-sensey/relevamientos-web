/**
 * @file Jerarquias.tsx
 * @description Página de gestión de jerarquías conectada al backend real (D1) o mocks.
 */

import { useMemo, useState, useEffect } from 'react'
import { List, Plus, Pencil, Trash2 } from 'lucide-react'
import AppLayout from '../components/layout/AppLayout'
import UnauthorizedScreen from '../components/common/UnauthorizedScreen'
import { useSystemUser } from '../context/SystemUserContext'
import JerarquiaFormModal, { type JerarquiaFormValues, type JerarquiaFormMode } from '../components/jerarquias/JerarquiaFormModal'
import { listJerarquias, createJerarquia, updateJerarquia, deleteJerarquia } from '../lib/apiClient'

/**
 * JerarquiasPage
 * @description Página principal para administrar jerarquías (consume API real).
 */
export default function JerarquiasPage() {
  const { currentUser } = useSystemUser()
  const [searchTerm, setSearchTerm] = useState('')
  const [isFormOpen, setIsFormOpen] = useState(false)
  const [formMode, setFormMode] = useState<JerarquiaFormMode>('create')
  const [selected, setSelected] = useState<any | null>(null)
  const [refreshKey, setRefreshKey] = useState(0)

  const [items, setItems] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  // Acceso restringido a administradores
  if (!currentUser || currentUser.rol !== 'administrador') {
    return <UnauthorizedScreen />
  }

  useEffect(() => {
    load()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [refreshKey])

  async function load() {
    setLoading(true)
    setError(null)
    try {
      const res = await listJerarquias()
      if (res && res.ok) setItems(res.jerarquias ?? [])
      else setItems(res.jerarquias ?? [])
    } catch (err: any) {
      console.error('load jerarquias error', err)
      setError(String(err?.message ?? err))
    } finally {
      setLoading(false)
    }
  }

  const filtered = useMemo(() => {
    const term = searchTerm.trim().toLowerCase()
    if (!term) return items
    return items.filter((j) => (j.nombre ?? '').toLowerCase().includes(term))
  }, [searchTerm, items])

  function handleSubmit(values: JerarquiaFormValues) {
    ;(async () => {
      try {
        if (formMode === 'create') {
          await createJerarquia({ nombre: values.nombre, orden: values.orden ?? 0 })
          alert('Jerarquía creada.')
        } else if (formMode === 'edit' && selected) {
          await updateJerarquia(selected.id, { nombre: values.nombre, orden: values.orden ?? 0 })
          alert('Jerarquía actualizada.')
        }
        setIsFormOpen(false)
        setSelected(null)
        setRefreshKey((k) => k + 1)
      } catch (err: any) {
        alert('Error guardando jerarquía: ' + String(err?.message ?? err))
      }
    })()
  }

  async function handleDelete(j: any) {
    const ok = confirm('Eliminar jerarquía?')
    if (!ok) return
    try {
      await deleteJerarquia(j.id)
      setRefreshKey((k) => k + 1)
    } catch (err: any) {
      alert('Error eliminando jerarquía: ' + String(err?.message ?? err))
    }
  }

  return (
    <AppLayout title="Jerarquías">
      <div className="space-y-4">
        <div className="flex items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-sky-600/20 text-sky-300">
              <List className="h-4 w-4" />
            </div>
            <div>
              <h2 className="text-sm font-semibold text-slate-100">Jerarquías</h2>
              <p className="text-xs text-slate-400">Gestión de rangos policiales.</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <input
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Buscar por nombre..."
              className="rounded-md border border-slate-700 bg-slate-900 px-2 py-1 text-xs text-slate-100 placeholder:text-slate-500 focus:border-sky-500 focus:outline-none focus:ring-1 focus:ring-sky-500"
            />
            <button
              type="button"
              onClick={() => {
                setFormMode('create')
                setSelected(null)
                setIsFormOpen(true)
              }}
              className="inline-flex items-center gap-1 rounded-md bg-sky-600 px-3 py-1.5 text-xs font-semibold text-white hover:bg-sky-700"
            >
              <Plus className="h-3.5 w-3.5" />
              Nueva
            </button>
          </div>
        </div>

        <div className="rounded-xl border border-slate-800 bg-slate-900/70 p-3">
          <div className="grid gap-2">
            {loading && <div className="text-xs text-slate-400">Cargando jerarquías…</div>}
            {!loading && filtered.map((j) => (
              <div key={j.id} className="flex items-center justify-between gap-3 rounded-md border border-slate-800 bg-slate-900 p-3">
                <div className="flex items-center gap-3">
                  <div className="flex flex-col">
                    <span className="text-sm font-medium text-slate-100">{j.nombre}</span>
                    <span className="text-xs text-slate-400">Orden: <span className="font-mono text-slate-200">{j.orden}</span></span>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      setFormMode('edit')
                      setSelected(j)
                      setIsFormOpen(true)
                    }}
                    className="inline-flex items-center gap-1 rounded-md bg-slate-800 px-2 py-1 text-[11px] font-medium text-slate-100 hover:bg-slate-700"
                  >
                    <Pencil className="h-3.5 w-3.5" />
                    Editar
                  </button>

                  <button
                    type="button"
                    onClick={() => handleDelete(j)}
                    className="inline-flex items-center gap-1 rounded-md bg-slate-800 px-2 py-1 text-[11px] font-medium text-red-200 hover:bg-red-700"
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                    Eliminar
                  </button>
                </div>
              </div>
            ))}

            {!loading && filtered.length === 0 && (
              <div className="col-span-full rounded-lg border border-dashed border-slate-700 bg-slate-900/60 p-6 text-center text-xs text-slate-400">
                No se encontraron jerarquías con el término ingresado.
              </div>
            )}
          </div>
        </div>
      </div>

      <JerarquiaFormModal
        open={isFormOpen}
        mode={formMode}
        initial={selected ?? undefined}
        onClose={() => {
          setIsFormOpen(false)
          setSelected(null)
        }}
        onSubmit={(vals) => handleSubmit(vals)}
      />
    </AppLayout>
  )
}