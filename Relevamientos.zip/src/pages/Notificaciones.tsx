/**
 * @file Notificaciones.tsx
 * @description Página de Notificaciones / Mensajería interna (modo demo).
 */

import AppLayout from '../components/layout/AppLayout'
import UnauthorizedScreen from '../components/common/UnauthorizedScreen'
import { useSystemUser } from '../context/SystemUserContext'
import NotificationsList from '../components/notifications/NotificationsList'

/**
 * NotificacionesPage
 * @description Página principal de notificaciones; acceso solo para usuarios autenticados.
 */
export default function NotificacionesPage() {
  const { currentUser } = useSystemUser()

  if (!currentUser) {
    return <UnauthorizedScreen />
  }

  const displayName = `${currentUser.apellido}, ${currentUser.nombre}`

  return (
    <AppLayout title="Notificaciones">
      <section>
        <NotificationsList currentUserName={displayName} />
      </section>
    </AppLayout>
  )
}