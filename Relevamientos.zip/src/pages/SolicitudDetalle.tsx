/**
 * @file SolicitudDetalle.tsx
 * @description Vista de detalle de una solicitud de relevamiento.
 */

import React from 'react'
import { useLocation, useNavigate, useParams } from 'react-router'
import { ArrowLeft, FileText, Paperclip, ClipboardList, Edit3 } from 'lucide-react'
import AppLayout from '../components/layout/AppLayout'
import { useSystemUser } from '../context/SystemUserContext'

/**
 * SolicitudMinimal
 * @description Tipo mínimo esperado para la solicitud pasada por state.
 */
interface SolicitudMinimal {
  id: number
  numeroRegistro: string
  fecha: string
  ipp: string
  fiscalia: string
  lugar: string
  caratula: string
  estado: 'pendiente' | 'finalizada'
  creador: string
  hasAdjuntos: boolean
  /** Latitud (opcional) */
  lat?: number | null
  /** Longitud (opcional) */
  lng?: number | null
}

/**
 * SolicitudDetallePage
 * @description Página que muestra la información detallada de una solicitud.
 *
 * Comportamiento:
 * - Si la solicitud es pasada via location.state la muestra inmediatamente.
 * - Si no hay state, muestra un aviso indicándole al usuario que la info no está disponible (mock).
 * - Muestra un mapa embebido de OpenStreetMap si existen coordenadas.
 */
export default function SolicitudDetallePage() {
  const { id } = useParams<{ id: string }>()
  const navigate = useNavigate()
  const location = useLocation()
  const { currentUser } = useSystemUser()

  // Intentar leer la solicitud desde el state (navegación desde el listado).
  const stateSolicitud = (location.state as any)?.solicitud as SolicitudMinimal | undefined

  // Si no hay state, construir un fallback ligero indicando que no hay datos (puede expandirse con fetch).
  const solicitud: SolicitudMinimal | null = stateSolicitud
    ? stateSolicitud
    : id
    ? {
        id: Number(id),
        numeroRegistro: `SGR-20250218-0${id}`,
        fecha: '2025-02-18',
        ipp: 'PP-XXXXX-2025',
        fiscalia: 'UFIJ N/D',
        lugar: 'Dirección no disponible',
        caratula: 'Carátula no disponible',
        estado: 'pendiente',
        creador: 'Usuario desconocido',
        hasAdjuntos: false,
        lat: null,
        lng: null,
      }
    : null

  /**
   * handleBack
   * @description Navega a la pantalla anterior.
   */
  const handleBack = () => {
    navigate(-1)
  }

  /**
   * action handlers (mock)
   */
  const handleViewAttachments = () => {
    window.alert('Ver archivos adjuntos (mock).')
  }
  const handleStartRelevamiento = () => {
    window.alert('Iniciar nuevo relevamiento (mock).')
  }
  const handleViewInforme = () => {
    window.alert('Abrir informe imprimible (mock).')
  }
  const handleEdit = () => {
    window.alert('Editar solicitud (mock).')
  }

  /**
   * buildOsmEmbedUrl
   * @description Construye la URL de embed de OpenStreetMap centrada en lat/lng con un bbox razonable.
   * @param lat Latitud
   * @param lng Longitud
   * @returns URL string para el iframe de OSM
   */
  const buildOsmEmbedUrl = (lat: number, lng: number) => {
    const delta = 0.01 // bbox padding (~1km)
    const left = lng - delta
    const bottom = lat - delta
    const right = lng + delta
    const top = lat + delta
    return `https://www.openstreetmap.org/export/embed.html?bbox=${left},${bottom},${right},${top}&layer=mapnik&marker=${lat},${lng}`
  }

  return (
    <AppLayout title="Detalle de solicitud">
      <div className="space-y-4">
        <div className="flex items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={handleBack}
              className="inline-flex items-center justify-center rounded-md bg-slate-800 p-2 text-slate-100 hover:bg-slate-700"
              aria-label="Volver"
            >
              <ArrowLeft className="h-4 w-4" />
            </button>
            <div>
              <h2 className="text-sm font-semibold text-slate-50">
                {solicitud ? solicitud.numeroRegistro : 'Solicitud'}
              </h2>
              <p className="text-xs text-slate-400">
                {solicitud ? `${new Date(solicitud.fecha).toLocaleDateString('es-AR')} · ${solicitud.ipp}` : ''}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleEdit}
              className="inline-flex items-center gap-2 rounded-md bg-slate-800 px-3 py-2 text-xs font-medium text-slate-100 hover:bg-slate-700"
            >
              <Edit3 className="h-4 w-4" />
              Editar
            </button>
          </div>
        </div>

        {/* Card resumen */}
        <div className="rounded-xl border border-slate-800 bg-slate-900/70 p-4">
          <div className="grid gap-3 sm:grid-cols-2">
            <div>
              <h3 className="text-xs font-semibold text-slate-300">Fiscalía</h3>
              <p className="mt-1 text-sm text-slate-100">{solicitud?.fiscalia}</p>
            </div>

            <div>
              <h3 className="text-xs font-semibold text-slate-300">Lugar del hecho</h3>
              <p className="mt-1 text-sm text-slate-100">{solicitud?.lugar}</p>
            </div>

            <div>
              <h3 className="text-xs font-semibold text-slate-300">Carátula</h3>
              <p className="mt-1 text-sm text-slate-100">{solicitud?.caratula}</p>
            </div>

            <div>
              <h3 className="text-xs font-semibold text-slate-300">Estado</h3>
              <p className="mt-1 text-sm text-slate-100 capitalize">{solicitud?.estado}</p>
            </div>
          </div>
        </div>

        {/* Acciones rápidas */}
        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={handleViewAttachments}
            disabled={!solicitud?.hasAdjuntos}
            className="inline-flex items-center gap-2 rounded-md bg-slate-800 px-3 py-2 text-xs font-medium text-slate-100 hover:bg-slate-700 disabled:opacity-40 disabled:cursor-not-allowed"
          >
            <Paperclip className="h-4 w-4" />
            Archivos
          </button>

          <button
            type="button"
            onClick={handleStartRelevamiento}
            disabled={solicitud?.estado !== 'pendiente'}
            className="inline-flex items-center gap-2 rounded-md bg-amber-600 px-3 py-2 text-xs font-medium text-slate-900 hover:bg-amber-700 disabled:opacity-40 disabled:cursor-not-allowed"
          >
            <ClipboardList className="h-4 w-4" />
            Iniciar relevamiento
          </button>

          <button
            type="button"
            onClick={handleViewInforme}
            disabled={solicitud?.estado !== 'finalizada'}
            className="inline-flex items-center gap-2 rounded-md bg-emerald-600 px-3 py-2 text-xs font-medium text-slate-900 hover:bg-emerald-700 disabled:opacity-40 disabled:cursor-not-allowed"
          >
            <FileText className="h-4 w-4" />
            Ver informe
          </button>
        </div>

        {/* Observaciones / notas (mock) */}
        <div className="rounded-xl border border-slate-800 bg-slate-900/70 p-4">
          <h4 className="mb-2 text-xs font-semibold text-slate-300">Observaciones</h4>
          <p className="text-sm text-slate-200">
            {solicitud
              ? 'No hay observaciones registradas para esta solicitud (mock).'
              : 'Detalle no disponible.'}
          </p>
        </div>

        {/* Mapa embebido (OpenStreetMap) */}
        <div className="rounded-xl border border-slate-800 bg-slate-900/70 p-4">
          <h4 className="mb-2 text-xs font-semibold text-slate-300">Mapa / Ubicación</h4>

          {solicitud && typeof solicitud.lat === 'number' && typeof solicitud.lng === 'number' ? (
            <div className="overflow-hidden rounded-md border border-slate-800">
              <div className="h-64 w-full">
                <iframe
                  title="Mapa ubicación"
                  src={buildOsmEmbedUrl(solicitud.lat, solicitud.lng)}
                  className="h-full w-full"
                  loading="lazy"
                />
              </div>
              <div className="mt-2 text-xs text-slate-400">
                <a
                  href={`https://www.openstreetmap.org/?mlat=${solicitud.lat}&mlon=${solicitud.lng}#map=18/${solicitud.lat}/${solicitud.lng}`}
                  target="_blank"
                  rel="noreferrer"
                  className="text-sky-400"
                >
                  Abrir en OpenStreetMap
                </a>
              </div>
            </div>
          ) : (
            <div className="h-48 w-full rounded-md bg-slate-800/50 flex items-center justify-center text-slate-400">
              Coordenadas no disponibles
            </div>
          )}
        </div>
      </div>
    </AppLayout>
  )
}