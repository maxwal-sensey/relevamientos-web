/**
 * @file Estadisticas.tsx
 * @description Página de estadísticas con KPIs y gráficos basados en datos reales del mock-store.
 */

import React, { useEffect, useMemo, useState } from 'react'
import { Users, Camera, FileText, UserCheck } from 'lucide-react'
import AppLayout from '../components/layout/AppLayout'
import { useSystemUser } from '../context/SystemUserContext'
import UnauthorizedScreen from '../components/common/UnauthorizedScreen'
import SummaryCard from '../components/statistics/SummaryCard'
import Charts from '../components/statistics/Charts'
import { fetchSolicitudes } from '../mock/solicitudesStore'
import { getInformeById, InformeRelevamientoData } from '../mock/relevamientosStore'

/**
 * EstadisticasPage
 * @description Página principal de estadísticas; carga solicitudes e informes mock y construye
 *              KPIs y datasets para los gráficos (estado, últimos 6 meses, top relevadores).
 */
export default function EstadisticasPage() {
  const { currentUser } = useSystemUser()
  const [loading, setLoading] = useState(true)
  const [solicitudes, setSolicitudes] = useState<any[]>([])
  const [informes, setInformes] = useState<InformeRelevamientoData[]>([])

  useEffect(() => {
    let mounted = true
    async function load() {
      setLoading(true)
      try {
        const sols = await fetchSolicitudes()
        if (!mounted) return
        setSolicitudes(sols)

        // Cargar informes probando ids comunes (1..200)
        const items: InformeRelevamientoData[] = []
        for (let i = 1; i <= 200; i++) {
          const inf = getInformeById(i)
          if (inf) items.push(inf)
        }
        if (!mounted) return
        setInformes(items)
      } finally {
        if (!mounted) return
        setLoading(false)
      }
    }
    load()
    return () => {
      mounted = false
    }
  }, [])

  if (!currentUser) {
    return <UnauthorizedScreen />
  }

  /**
   * statusData
   * @description Construye la distribución de estados de solicitudes (Pendiente/Finalizada).
   */
  const statusData = useMemo(() => {
    const pendientes = solicitudes.filter((s) => s.estado === 'pendiente').length
    const finalizadas = solicitudes.filter((s) => s.estado === 'finalizada').length
    return [
      { name: 'Pendiente', value: pendientes },
      { name: 'Finalizada', value: finalizadas },
    ]
  }, [solicitudes])

  /**
   * monthlyData
   * @description Agrupa por mes (últimos 6 meses) la cantidad de relevamientos (por fecha de informe).
   */
  const monthlyData = useMemo(() => {
    const months: { key: string; label: string; date: Date }[] = []
    const today = new Date()
    for (let i = 5; i >= 0; i--) {
      const d = new Date(today.getFullYear(), today.getMonth() - i, 1)
      const key = `${d.getFullYear()}-${d.getMonth() + 1}`
      const label = d.toLocaleString('es-AR', { month: 'short' })
      months.push({ key, label, date: d })
    }

    const counts: Record<string, number> = {}
    months.forEach((m) => (counts[m.key] = 0))

    informes.forEach((inf) => {
      const dt = new Date(inf.fecha)
      const key = `${dt.getFullYear()}-${dt.getMonth() + 1}`
      if (counts[key] !== undefined) counts[key]++
    })

    return months.map((m) => ({ month: m.label, value: counts[m.key] || 0 }))
  }, [informes])

  /**
   * topData
   * @description Ranking de relevadores por cantidad de informes (top 5).
   */
  const topData = useMemo(() => {
    const map = new Map<string, number>()
    informes.forEach((inf) => {
      const name = inf.relevadorNombre || 'Sin asignar'
      map.set(name, (map.get(name) || 0) + 1)
    })
    const arr = Array.from(map.entries()).map(([name, value]) => ({ name, value }))
    arr.sort((a, b) => b.value - a.value)
    return arr.slice(0, 5)
  }, [informes])

  // KPIs principales
  const totalSolicitudes = solicitudes.length
  const pendientes = statusData.find((d) => d.name === 'Pendiente')?.value ?? 0
  const finalizadas = statusData.find((d) => d.name === 'Finalizada')?.value ?? 0
  const totalRelevamientos = informes.length
  const totalCamaras = informes.reduce((acc, inf) => acc + (inf.camaras?.length ?? 0), 0)
  const vecinos = informes.reduce((acc, inf) => acc + (inf.vecinos?.length ?? 0), 0)

  return (
    <AppLayout title="Estadísticas">
      <section className="space-y-6">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <h2 className="text-sm font-semibold text-slate-100">Métricas del sistema</h2>
            <p className="mt-1 max-w-xl text-xs text-slate-400">
              Resumen y visualizaciones representativas. Los datos aquí provienen del store mock.
            </p>
          </div>
        </div>

        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          <SummaryCard
            title="Solicitudes"
            value={loading ? '—' : String(totalSolicitudes)}
            description="Total de solicitudes registradas"
            accentColorClass="bg-amber-500"
            icon={<FileText className="h-5 w-5" />}
          />
          <SummaryCard
            title="Relevamientos"
            value={loading ? '—' : String(totalRelevamientos)}
            description="Relevamientos realizados"
            accentColorClass="bg-sky-500"
            icon={<Camera className="h-5 w-5" />}
          />
          <SummaryCard
            title="Cámaras registradas"
            value={loading ? '—' : String(totalCamaras)}
            description="Cámaras asociadas a relevamientos"
            accentColorClass="bg-cyan-500"
            icon={<Camera className="h-5 w-5" />}
          />
          <SummaryCard
            title="Vecinos entrevistados"
            value={loading ? '—' : String(vecinos)}
            description="Personas entrevistadas en relevamientos"
            accentColorClass="bg-violet-500"
            icon={<Users className="h-5 w-5" />}
          />
          <SummaryCard
            title="Solicitudes pendientes"
            value={loading ? '—' : String(pendientes)}
            description="Solicitudes en estado pendiente"
            accentColorClass="bg-fuchsia-500"
            icon={<svg className="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M12 9v4" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" /><path d="M12 17h.01" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" /><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z" strokeWidth="1.2" strokeLinecap="round" strokeLinejoin="round" /></svg>}
          />
          <SummaryCard
            title="Relevadores activos"
            value="7"
            description="Con actividad en los últimos 30 días"
            accentColorClass="bg-indigo-500"
            icon={<UserCheck className="h-5 w-5" />}
          />
        </div>

        <Charts statusData={statusData} monthlyData={monthlyData} topData={topData} />
      </section>
    </AppLayout>
  )
}