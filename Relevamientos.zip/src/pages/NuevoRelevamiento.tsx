/**
 * @file NuevoRelevamiento.tsx
 * @description Formulario para crear un nuevo relevamiento (datos simulados en frontend).
 */

import { FormEvent, useMemo, useState } from 'react'
import {
  ArrowLeft,
  Info,
  Plus,
  Trash2,
  Video,
  Users,
} from 'lucide-react'
import { useNavigate } from 'react-router'
import AppLayout from '../components/layout/AppLayout'
import { useSystemUser } from '../context/SystemUserContext'
import UnauthorizedScreen from '../components/common/UnauthorizedScreen'
import {
  registerNuevoRelevamientoFromForm,
  type CameraReport,
  type VecinoReport,
} from '../mock/relevamientosStore'

/**
 * @interface OpcionSolicitud
 * @description Representa una solicitud pendiente seleccionable para un relevamiento.
 */
interface OpcionSolicitud {
  id: number
  numeroRegistro: string
  ipp: string
  fiscalia: string
  caratula: string
  lugar: string
  resumenHecho: string
}

/** Datos mock de solicitudes pendientes para selección en el relevamiento. */
const MOCK_SOLICITUDES_PENDIENTES: OpcionSolicitud[] = [
  {
    id: 1,
    numeroRegistro: 'SGR-20250218-0001',
    ipp: 'PP-12345-2025',
    fiscalia: 'UFIJ N° 3',
    caratula: 'Robo agravado',
    lugar: 'Calle Falsa 123, La Plata',
    resumenHecho:
      'Hecho de robo agravado ocurrido en comercio de rubro minimercado, donde autores ignorados sustraen dinero en efectivo y mercaderías.',
  },
  {
    id: 2,
    numeroRegistro: 'SGR-20250210-0003',
    ipp: 'PP-22222-2025',
    fiscalia: 'UFIJ N° 1',
    caratula: 'Lesiones leves',
    lugar: 'Calle 50 y 7, La Plata',
    resumenHecho:
      'Lesiones leves en la vía pública producto de una discusión entre dos personas, con intervención de personal policial y traslado al centro asistencial.',
  },
]

/**
 * @interface CameraEntry
 * @description Datos de una cámara relevada dentro del formulario.
 */
interface CameraEntry {
  id: number
  lugar: string
  tipoCamara: 'privada' | 'com'
  accion:
    | 'solicito_grabacion'
    | 'no_graba'
    | 'no_apunta'
    | 'negativa'
    | 'entrega_material'
    | 'otro'
  entrevistadoNombre: string
  entrevistadoApellido: string
  observaciones: string
}

/**
 * @interface VecinoEntry
 * @description Datos de un vecino entrevistado dentro del formulario.
 */
interface VecinoEntry {
  id: number
  lugar: string
  nombre: string
  apellido: string
  dni: string
  presencio: boolean
  conocimiento: boolean
  sinCamaras: boolean
  camarasNoGraban: boolean
  camarasNoDanLugar: boolean
  observaciones: string
}

/**
 * generateRelevamientoNumber
 * @description Genera un identificador simulado para el relevamiento.
 */
function generateRelevamientoNumber(date: Date): string {
  const year = date.getFullYear()
  const month = `${date.getMonth() + 1}`.padStart(2, '0')
  const day = `${date.getDate()}`.padStart(2, '0')
  const sequential = '0001'
  return `REL-${year}${month}${day}-${sequential}`
}

/**
 * buildObservacionesVecino
 * @description Genera texto automático de observaciones según flags del vecino.
 */
function buildObservacionesVecino(entry: VecinoEntry): string {
  // Si ya hay observaciones manuales, se respetan.
  if (entry.observaciones.trim().length > 0) {
    return entry.observaciones
  }

  if (!entry.presencio && !entry.conocimiento) {
    return 'No presenció ni tiene conocimiento del hecho.'
  }

  if (!entry.presencio && entry.conocimiento) {
    return 'No presenció el hecho, pero tiene conocimiento del mismo.'
  }

  if (entry.presencio && !entry.conocimiento) {
    return 'Presenció el hecho, pero no posee mayor conocimiento adicional.'
  }

  // Caso en el que presenció y tiene conocimiento.
  return 'Presenció el hecho y tiene conocimiento directo sobre el mismo.'
}

/**
 * mapAccionCamaraToTexto
 * @description Mapea el código de acción de cámara a un texto legible para el informe.
 */
function mapAccionCamaraToTexto(
  accion: CameraEntry['accion']
): string {
  switch (accion) {
    case 'solicito_grabacion':
      return 'Se solicitó grabación.'
    case 'no_graba':
      return 'No graba / sin registros disponibles.'
    case 'no_apunta':
      return 'La cámara no apunta al lugar del hecho.'
    case 'negativa':
      return 'Negativa a entregar grabaciones.'
    case 'entrega_material':
      return 'Entrega material fílmico en el lugar.'
    case 'otro':
    default:
      return 'Otra situación relevada con la cámara.'
  }
}

/**
 * buildInfoCamarasVecino
 * @description Construye texto sobre el estado de cámaras del vecino en base a los flags.
 */
function buildInfoCamarasVecino(entry: VecinoEntry): string | undefined {
  const partes: string[] = []

  if (entry.sinCamaras) {
    partes.push('No posee cámaras de seguridad.')
  }
  if (entry.camarasNoGraban) {
    partes.push('Las cámaras no graban o no conservan registros útiles.')
  }
  if (entry.camarasNoDanLugar) {
    partes.push('Las cámaras no dan al lugar específico del hecho.')
  }

  if (partes.length === 0) {
    return undefined
  }

  return partes.join(' ')
}

/**
 * NuevoRelevamientoPage
 * @description Vista de alta de nuevo relevamiento (sin persistencia real, pero conectada a mocks de informe).
 */
export default function NuevoRelevamientoPage() {
  const { currentUser } = useSystemUser()
  const navigate = useNavigate()

  const [selectedSolicitudId, setSelectedSolicitudId] = useState<number | ''>(
    ''
  )
  const [camaras, setCamaras] = useState<CameraEntry[]>([])
  const [vecinos, setVecinos] = useState<VecinoEntry[]>([])
  const [observacionesGenerales, setObservacionesGenerales] = useState('')
  const [secretariaNombre, setSecretariaNombre] = useState(
    'Secretaría actuante de prueba'
  )
  const [dependenciaNombre, setDependenciaNombre] = useState(
    'Dependencia policial de prueba'
  )
  const [error, setError] = useState<string | null>(null)
  const [successNumero, setSuccessNumero] = useState<string | null>(null)
  const [isSubmitting, setIsSubmitting] = useState(false)

  // Restricción de acceso por rol: solo relevador y administrador.
  if (
    !currentUser ||
    (currentUser.rol !== 'relevador' && currentUser.rol !== 'administrador')
  ) {
    return <UnauthorizedScreen />
  }

  /**
   * solicitudSeleccionada
   * @description Obtiene la solicitud elegida para mostrar resumen contextual.
   */
  const solicitudSeleccionada = useMemo(
    () =>
      typeof selectedSolicitudId === 'number'
        ? MOCK_SOLICITUDES_PENDIENTES.find(
            (s) => s.id === selectedSolicitudId
          ) ?? null
        : null,
    [selectedSolicitudId]
  )

  /**
   * handleAddCamara
   * @description Agrega una nueva fila de cámara al formulario.
   */
  const handleAddCamara = () => {
    setCamaras((prev) => [
      ...prev,
      {
        id: Date.now(),
        lugar: '',
        tipoCamara: 'privada',
        accion: 'solicito_grabacion',
        entrevistadoNombre: '',
        entrevistadoApellido: '',
        observaciones: '',
      },
    ])
  }

  /**
   * handleUpdateCamara
   * @description Actualiza parcialmente una cámara existente.
   */
  const handleUpdateCamara = (
    id: number,
    patch: Partial<CameraEntry>
  ) => {
    setCamaras((prev) =>
      prev.map((cam) => {
        if (cam.id !== id) return cam

        const next: CameraEntry = { ...cam, ...patch }

        // Automatismo: si la acción es solicitar grabación y no hay observaciones,
        // sugerir texto base.
        if (
          patch.accion === 'solicito_grabacion' &&
          next.observaciones.trim().length === 0
        ) {
          next.observaciones = 'Recibe nota de solicitud de imágenes.'
        }

        return next
      })
    )
  }

  /**
   * handleRemoveCamara
   * @description Elimina una cámara del listado del formulario.
   */
  const handleRemoveCamara = (id: number) => {
    setCamaras((prev) => prev.filter((cam) => cam.id !== id))
  }

  /**
   * handleAddVecino
   * @description Agrega un nuevo vecino entrevistado.
   */
  const handleAddVecino = () => {
    setVecinos((prev) => [
      ...prev,
      {
        id: Date.now(),
        lugar: '',
        nombre: '',
        apellido: '',
        dni: '',
        presencio: false,
        conocimiento: false,
        sinCamaras: false,
        camarasNoGraban: false,
        camarasNoDanLugar: false,
        observaciones: '',
      },
    ])
  }

  /**
   * handleUpdateVecino
   * @description Actualiza parcialmente un vecino existente.
   */
  const handleUpdateVecino = (
    id: number,
    patch: Partial<VecinoEntry>
  ) => {
    setVecinos((prev) => prev.map((v) => (v.id === id ? { ...v, ...patch } : v)))
  }

  /**
   * handleRemoveVecino
   * @description Elimina un vecino del listado del formulario.
   */
  const handleRemoveVecino = (id: number) => {
    setVecinos((prev) => prev.filter((v) => v.id !== id))
  }

  /**
   * handleSubmit
   * @description Valida el formulario y simula el alta de un nuevo relevamiento, actualizando el store de informes.
   */
  const handleSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault()
    setError(null)
    setSuccessNumero(null)

    if (!selectedSolicitudId || !solicitudSeleccionada) {
      setError('Debe seleccionar una solicitud a relevar.')
      return
    }

    if (camaras.length === 0 && vecinos.length === 0) {
      setError(
        'Debe registrar al menos una cámara relevada o un vecino entrevistado.'
      )
      return
    }

    if (observacionesGenerales.trim().length < 10) {
      setError(
        'Las observaciones generales deben tener al menos 10 caracteres para brindar contexto.'
      )
      return
    }

    setIsSubmitting(true)

    try {
      // Simulación de llamada a backend.
      await new Promise((resolve) => setTimeout(resolve, 800))

      // Aplicar automatismos de observaciones para vecinos.
      const vecinosConTextoAutomatico: VecinoEntry[] = vecinos.map((v) => ({
        ...v,
        observaciones: buildObservacionesVecino(v),
      }))

      // Preparar cámaras para el informe imprimible.
      const camarasParaInforme: CameraReport[] = camaras.map((cam) => {
        const tipo: CameraReport['tipo'] =
          cam.tipoCamara === 'com' ? 'COM' : 'Privada'

        const accionTexto = mapAccionCamaraToTexto(cam.accion)

        const entrevistado = [cam.entrevistadoNombre, cam.entrevistadoApellido]
          .map((val) => val.trim())
          .filter(Boolean)
          .join(' ')

        const observaciones =
          cam.observaciones.trim().length > 0
            ? cam.observaciones.trim()
            : undefined

        return {
          id: cam.id,
          lugar: cam.lugar,
          tipo,
          accion: accionTexto,
          entrevistado: entrevistado || undefined,
          observaciones,
        }
      })

      // Preparar vecinos para el informe imprimible.
      const vecinosParaInforme: VecinoReport[] = vecinosConTextoAutomatico.map(
        (v) => {
          const nombreCompleto = [v.nombre, v.apellido]
            .map((val) => val.trim())
            .filter(Boolean)
            .join(', ')

          const detallePresencio = v.presencio
            ? 'Refiere haber presenciado el hecho o parte del mismo.'
            : 'No presenció el hecho.'

          const detalleConocimiento = v.conocimiento
            ? 'Refiere tener conocimiento del hecho por propia vivencia o comentarios.'
            : 'No aporta conocimiento adicional sobre el hecho.'

          const infoCamaras = buildInfoCamarasVecino(v)

          const observaciones =
            v.observaciones.trim().length > 0
              ? v.observaciones.trim()
              : undefined

          return {
            id: v.id,
            nombreCompleto: nombreCompleto || 'Vecino sin identificar',
            dni: v.dni.trim() || undefined,
            lugarEntrevista: v.lugar,
            presencio: v.presencio,
            detallePresencio,
            conocimiento: v.conocimiento,
            detalleConocimiento,
            infoCamaras,
            observaciones,
          }
        }
      )

      // Registrar en el store compartido para listado + informe.
      const relevadorNombre = `${currentUser.apellido}, ${currentUser.nombre} (Relevador)`

      registerNuevoRelevamientoFromForm({
        solicitudNumeroRegistro: solicitudSeleccionada.numeroRegistro,
        solicitudIPP: solicitudSeleccionada.ipp,
        fiscalia: solicitudSeleccionada.fiscalia,
        caratula: solicitudSeleccionada.caratula,
        lugar: solicitudSeleccionada.lugar,
        resumenHecho: solicitudSeleccionada.resumenHecho,
        observacionesGenerales: observacionesGenerales.trim(),
        camaras: camarasParaInforme,
        vecinos: vecinosParaInforme,
        relevadorNombre,
        secretariaNombre: secretariaNombre.trim() || 'Secretaría actuante',
        dependenciaNombre: dependenciaNombre.trim() || 'Dependencia policial',
        dependenciaId: currentUser.dependenciaId ?? null,
      })

      const numero = generateRelevamientoNumber(new Date())
      setSuccessNumero(numero)

      // Limpieza básica del formulario luego de crear el relevamiento.
      setSelectedSolicitudId('')
      setCamaras([])
      setVecinos([])
      setObservacionesGenerales('')
      setSecretariaNombre('Secretaría actuante de prueba')
      setDependenciaNombre('Dependencia policial de prueba')
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <AppLayout title="Nuevo relevamiento">
      <div className="mx-auto max-w-4xl space-y-5">
        {/* Barra de retorno */}
        <button
          type="button"
          onClick={() => navigate('/relevamientos')}
          className="inline-flex items-center gap-1.5 text-xs font-medium text-sky-300 hover:text-sky-200"
        >
          <ArrowLeft className="h-3.5 w-3.5" />
          Volver al listado de relevamientos
        </button>

        {/* Información general */}
        <div className="rounded-xl border border-slate-800 bg-slate-900/70 px-4 py-3 text-xs text-slate-300">
          <p>
            Seleccione una solicitud pendiente y registre las cámaras relevadas
            y vecinos entrevistados. En una versión conectada al backend, al
            guardar el relevamiento la solicitud quedará marcada como{' '}
            <span className="font-semibold text-emerald-300">finalizada</span>.
          </p>
        </div>

        {/* Mensajes de estado */}
        {error && (
          <div className="rounded-md border border-red-500/60 bg-red-950/60 px-3 py-2 text-xs text-red-100">
            {error}
          </div>
        )}
        {successNumero && (
          <div className="rounded-md border border-emerald-500/60 bg-emerald-950/60 px-3 py-2 text-xs text-emerald-100">
            Relevamiento creado correctamente (simulado). Número:{' '}
            <span className="font-mono font-semibold">{successNumero}</span>
          </div>
        )}

        {/* Formulario principal */}
        <form
          onSubmit={handleSubmit}
          className="space-y-6 rounded-xl border border-slate-800 bg-slate-900/70 px-4 py-5"
          noValidate
        >
          {/* Sección 1: Selección de solicitud */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h2 className="text-sm font-semibold text-slate-100">
                1. Selección de solicitud
              </h2>
            </div>

            <div className="grid gap-3 sm:grid-cols-2">
              <div>
                <label
                  htmlFor="solicitud"
                  className="mb-1 block text-xs font-medium text-slate-200"
                >
                  Solicitud a relevar *
                </label>
                <select
                  id="solicitud"
                  value={selectedSolicitudId}
                  onChange={(e) =>
                    setSelectedSolicitudId(
                      e.target.value ? Number(e.target.value) : ''
                    )
                  }
                  className="block w-full rounded-md border border-slate-700 bg-slate-950 px-2 py-1.5 text-xs text-slate-100 focus:border-sky-500 focus:outline-none focus:ring-1 focus:ring-sky-500"
                >
                  <option value="">Seleccione una solicitud…</option>
                  {MOCK_SOLICITUDES_PENDIENTES.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.numeroRegistro} — {s.caratula}
                    </option>
                  ))}
                </select>
              </div>

              {solicitudSeleccionada && (
                <div className="rounded-md border border-slate-700 bg-slate-950 px-3 py-2 text-[11px] text-slate-200">
                  <p className="font-semibold text-slate-100">
                    {solicitudSeleccionada.caratula}
                  </p>
                  <p className="text-slate-300">
                    IPP:{' '}
                    <span className="font-mono">
                      {solicitudSeleccionada.ipp}
                    </span>
                  </p>
                  <p className="text-slate-300">
                    Fiscalía: {solicitudSeleccionada.fiscalia}
                  </p>
                  <p className="text-slate-400">
                    Lugar: {solicitudSeleccionada.lugar}
                  </p>
                  <p className="mt-1 text-[10px] text-slate-400">
                    Resumen del hecho:{' '}
                    <span className="italic">
                      {solicitudSeleccionada.resumenHecho}
                    </span>
                  </p>
                </div>
              )}
            </div>
          </div>

          {/* Sección 2: Cámaras relevadas */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h2 className="flex items-center gap-1 text-sm font-semibold text-slate-100">
                <Video className="h-4 w-4 text-sky-400" />
                2. Cámaras relevadas
              </h2>
              <button
                type="button"
                onClick={handleAddCamara}
                className="inline-flex items-center gap-1 rounded-md border border-slate-700 px-2 py-1 text-[11px] font-medium text-slate-100 hover:bg-slate-800"
              >
                <Plus className="h-3 w-3" />
                Agregar cámara
              </button>
            </div>

            {camaras.length === 0 && (
              <p className="text-[11px] text-slate-400">
                Aún no se han agregado cámaras. Puede continuar con vecinos
                entrevistados si corresponde.
              </p>
            )}

            <div className="space-y-3">
              {camaras.map((cam) => (
                <div
                  key={cam.id}
                  className="space-y-2 rounded-lg border border-slate-800 bg-slate-950 px-3 py-3"
                >
                  <div className="flex items-center justify-between gap-2">
                    <p className="text-[11px] font-semibold text-slate-100">
                      Cámara
                    </p>
                    <button
                      type="button"
                      onClick={() => handleRemoveCamara(cam.id)}
                      className="inline-flex items-center gap-1 rounded-md border border-red-700/70 px-2 py-0.5 text-[10px] font-medium text-red-200 hover:bg-red-900/60"
                    >
                      <Trash2 className="h-3 w-3" />
                      Quitar
                    </button>
                  </div>

                  <div className="grid gap-2 sm:grid-cols-2">
                    <div>
                      <label className="mb-1 block text-[11px] font-medium text-slate-200">
                        Lugar / Dirección
                      </label>
                      <input
                        type="text"
                        value={cam.lugar}
                        onChange={(e) =>
                          handleUpdateCamara(cam.id, {
                            lugar: e.target.value,
                          })
                        }
                        placeholder='Ej: Local "El Sol", esquina 7 y 50'
                        className="block w-full rounded-md border border-slate-700 bg-slate-950 px-2 py-1 text-[11px] text-slate-100 placeholder:text-slate-500 focus:border-sky-500 focus:outline-none focus:ring-1 focus:ring-sky-500"
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <label className="mb-1 block text-[11px] font-medium text-slate-200">
                          Tipo de cámara
                        </label>
                        <select
                          value={cam.tipoCamara}
                          onChange={(e) =>
                            handleUpdateCamara(cam.id, {
                              tipoCamara: e.target
                                .value as CameraEntry['tipoCamara'],
                            })
                          }
                          className="block w-full rounded-md border border-slate-700 bg-slate-950 px-2 py-1 text-[11px] text-slate-100 focus:border-sky-500 focus:outline-none focus:ring-1 focus:ring-sky-500"
                        >
                          <option value="privada">Privada</option>
                          <option value="com">COM / Municipal</option>
                        </select>
                      </div>
                      <div>
                        <label className="mb-1 block text-[11px] font-medium text-slate-200">
                          Acción realizada
                        </label>
                        <select
                          value={cam.accion}
                          onChange={(e) =>
                            handleUpdateCamara(cam.id, {
                              accion: e.target.value as CameraEntry['accion'],
                            })
                          }
                          className="block w-full rounded-md border border-slate-700 bg-slate-950 px-2 py-1 text-[11px] text-slate-100 focus:border-sky-500 focus:outline-none focus:ring-1 focus:ring-sky-500"
                        >
                          <option value="solicito_grabacion">
                            Se solicitó grabación
                          </option>
                          <option value="no_graba">
                            No graba / Sin registros
                          </option>
                          <option value="no_apunta">
                            No apunta al lugar del hecho
                          </option>
                          <option value="negativa">
                            Negativa a entregar grabaciones
                          </option>
                          <option value="entrega_material">
                            Entrega material fílmico en el lugar
                          </option>
                          <option value="otro">Otro</option>
                        </select>
                      </div>
                    </div>
                  </div>

                  <div className="grid gap-2 sm:grid-cols-2">
                    <div>
                      <label className="mb-1 block text-[11px] font-medium text-slate-200">
                        Nombre entrevistado
                      </label>
                      <input
                        type="text"
                        value={cam.entrevistadoNombre}
                        onChange={(e) =>
                          handleUpdateCamara(cam.id, {
                            entrevistadoNombre: e.target.value,
                          })
                        }
                        className="block w-full rounded-md border border-slate-700 bg-slate-950 px-2 py-1 text-[11px] text-slate-100 placeholder:text-slate-500 focus:border-sky-500 focus:outline-none focus:ring-1 focus:ring-sky-500"
                        placeholder="Nombre"
                      />
                    </div>
                    <div>
                      <label className="mb-1 block text-[11px] font-medium text-slate-200">
                        Apellido entrevistado
                      </label>
                      <input
                        type="text"
                        value={cam.entrevistadoApellido}
                        onChange={(e) =>
                          handleUpdateCamara(cam.id, {
                            entrevistadoApellido: e.target.value,
                          })
                        }
                        className="block w-full rounded-md border border-slate-700 bg-slate-950 px-2 py-1 text-[11px] text-slate-100 placeholder:text-slate-500 focus:border-sky-500 focus:outline-none focus:ring-1 focus:ring-sky-500"
                        placeholder="Apellido"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="mb-1 block text-[11px] font-medium text-slate-200">
                      Observaciones
                    </label>
                    <textarea
                      rows={2}
                      value={cam.observaciones}
                      onChange={(e) =>
                        handleUpdateCamara(cam.id, {
                          observaciones: e.target.value,
                        })
                      }
                      className="block w-full rounded-md border border-slate-700 bg-slate-950 px-2 py-1 text-[11px] text-slate-100 placeholder:text-slate-500 focus:border-sky-500 focus:outline-none focus:ring-1 focus:ring-sky-500"
                      placeholder="Describa brevemente el resultado de la gestión con el entrevistado y particularidades de la cámara."
                    />
                  </div>
                </div>
              ))}
            </div>

            <div className="flex items-start gap-2 rounded-md border border-slate-700 bg-slate-950 px-3 py-2 text-[11px] text-slate-300">
              <Info className="mt-0.5 h-3.5 w-3.5 text-sky-400" />
              <p>
                En una próxima iteración se incorporará un mapa interactivo
                (Leaflet + OpenStreetMap) para seleccionar la ubicación precisa
                de cada cámara y almacenar coordenadas de latitud/longitud.
              </p>
            </div>
          </div>

          {/* Sección 3: Vecinos entrevistados */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h2 className="flex items-center gap-1 text-sm font-semibold text-slate-100">
                <Users className="h-4 w-4 text-sky-400" />
                3. Vecinos entrevistados
              </h2>
              <button
                type="button"
                onClick={handleAddVecino}
                className="inline-flex items-center gap-1 rounded-md border border-slate-700 px-2 py-1 text-[11px] font-medium text-slate-100 hover:bg-slate-800"
              >
                <Plus className="h-3 w-3" />
                Agregar vecino
              </button>
            </div>

            {vecinos.length === 0 && (
              <p className="text-[11px] text-slate-400">
                Puede registrar entrevistas a vecinos vinculados al hecho o al
                entorno de la escena.
              </p>
            )}

            <div className="space-y-3">
              {vecinos.map((v) => (
                <div
                  key={v.id}
                  className="space-y-2 rounded-lg border border-slate-800 bg-slate-950 px-3 py-3"
                >
                  <div className="flex items-center justify-between gap-2">
                    <p className="text-[11px] font-semibold text-slate-100">
                      Vecino entrevistado
                    </p>
                    <button
                      type="button"
                      onClick={() => handleRemoveVecino(v.id)}
                      className="inline-flex items-center gap-1 rounded-md border border-red-700/70 px-2 py-0.5 text-[10px] font-medium text-red-200 hover:bg-red-900/60"
                    >
                      <Trash2 className="h-3 w-3" />
                      Quitar
                    </button>
                  </div>

                  <div className="grid gap-2 sm:grid-cols-2">
                    <div>
                      <label className="mb-1 block text-[11px] font-medium text-slate-200">
                        Lugar de entrevista
                      </label>
                      <input
                        type="text"
                        value={v.lugar}
                        onChange={(e) =>
                          handleUpdateVecino(v.id, {
                            lugar: e.target.value,
                          })
                        }
                        className="block w-full rounded-md border border-slate-700 bg-slate-950 px-2 py-1 text-[11px] text-slate-100 placeholder:text-slate-500 focus:border-sky-500 focus:outline-none focus:ring-1 focus:ring-sky-500"
                        placeholder="Ej: Domicilio del vecino, comercio, vía pública"
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <label className="mb-1 block text-[11px] font-medium text-slate-200">
                          Nombre
                        </label>
                        <input
                          type="text"
                          value={v.nombre}
                          onChange={(e) =>
                            handleUpdateVecino(v.id, {
                              nombre: e.target.value,
                            })
                          }
                          className="block w-full rounded-md border border-slate-700 bg-slate-950 px-2 py-1 text-[11px] text-slate-100 placeholder:text-slate-500 focus:border-sky-500 focus:outline-none focus:ring-1 focus:ring-sky-500"
                        />
                      </div>
                      <div>
                        <label className="mb-1 block text-[11px] font-medium text-slate-200">
                          Apellido
                        </label>
                        <input
                          type="text"
                          value={v.apellido}
                          onChange={(e) =>
                            handleUpdateVecino(v.id, {
                              apellido: e.target.value,
                            })
                          }
                          className="block w-full rounded-md border border-slate-700 bg-slate-950 px-2 py-1 text-[11px] text-slate-100 placeholder:text-slate-500 focus:border-sky-500 focus:outline-none focus:ring-1 focus:ring-sky-500"
                        />
                      </div>
                    </div>
                  </div>

                  <div className="grid gap-2 sm:grid-cols-3">
                    <div className="flex items-center gap-2">
                      <input
                        id={`presencio-${v.id}`}
                        type="checkbox"
                        checked={v.presencio}
                        onChange={(e) =>
                          handleUpdateVecino(v.id, {
                            presencio: e.target.checked,
                          })
                        }
                        className="h-3.5 w-3.5 rounded border-slate-600 bg-slate-900 text-sky-500 focus:ring-sky-500"
                      />
                      <label
                        htmlFor={`presencio-${v.id}`}
                        className="text-[11px] text-slate-200"
                      >
                        Presenció el hecho
                      </label>
                    </div>
                    <div className="flex items-center gap-2">
                      <input
                        id={`conocimiento-${v.id}`}
                        type="checkbox"
                        checked={v.conocimiento}
                        onChange={(e) =>
                          handleUpdateVecino(v.id, {
                            conocimiento: e.target.checked,
                          })
                        }
                        className="h-3.5 w-3.5 rounded border-slate-600 bg-slate-900 text-sky-500 focus:ring-sky-500"
                      />
                      <label
                        htmlFor={`conocimiento-${v.id}`}
                        className="text-[11px] text-slate-200"
                      >
                        Tiene conocimiento del hecho
                      </label>
                    </div>
                    <div className="flex items-center gap-2">
                      <input
                        id={`sincamaras-${v.id}`}
                        type="checkbox"
                        checked={v.sinCamaras}
                        onChange={(e) =>
                          handleUpdateVecino(v.id, {
                            sinCamaras: e.target.checked,
                          })
                        }
                        className="h-3.5 w-3.5 rounded border-slate-600 bg-slate-900 text-sky-500 focus:ring-sky-500"
                      />
                      <label
                        htmlFor={`sincamaras-${v.id}`}
                        className="text-[11px] text-slate-200"
                      >
                        No posee cámaras de seguridad
                      </label>
                    </div>
                  </div>

                  <div className="grid gap-2 sm:grid-cols-2">
                    <div className="flex items-center gap-2">
                      <input
                        id={`nograban-${v.id}`}
                        type="checkbox"
                        checked={v.camarasNoGraban}
                        onChange={(e) =>
                          handleUpdateVecino(v.id, {
                            camarasNoGraban: e.target.checked,
                          })
                        }
                        className="h-3.5 w-3.5 rounded border-slate-600 bg-slate-900 text-sky-500 focus:ring-sky-500"
                      />
                      <label
                        htmlFor={`nograban-${v.id}`}
                        className="text-[11px] text-slate-200"
                      >
                        Las cámaras no graban / sin registros
                      </label>
                    </div>
                    <div className="flex items-center gap-2">
                      <input
                        id={`nodanlugar-${v.id}`}
                        type="checkbox"
                        checked={v.camarasNoDanLugar}
                        onChange={(e) =>
                          handleUpdateVecino(v.id, {
                            camarasNoDanLugar: e.target.checked,
                          })
                        }
                        className="h-3.5 w-3.5 rounded border-slate-600 bg-slate-900 text-sky-500 focus:ring-sky-500"
                      />
                      <label
                        htmlFor={`nodanlugar-${v.id}`}
                        className="text-[11px] text-slate-200"
                      >
                        Las cámaras no dan al lugar del hecho
                      </label>
                    </div>
                  </div>

                  <div>
                    <label className="mb-1 block text-[11px] font-medium text-slate-200">
                      Observaciones
                    </label>
                    <textarea
                      rows={2}
                      value={v.observaciones}
                      onChange={(e) =>
                        handleUpdateVecino(v.id, {
                          observaciones: e.target.value,
                        })
                      }
                      className="block w-full rounded-md border border-slate-700 bg-slate-950 px-2 py-1 text-[11px] text-slate-100 placeholder:text-slate-500 focus:border-sky-500 focus:outline-none focus:ring-1 focus:ring-sky-500"
                      placeholder="Si deja vacío este campo, el sistema generará automáticamente un texto básico según las opciones tildadas."
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Sección 4: Observaciones generales */}
          <div className="space-y-3">
            <h2 className="text-sm font-semibold text-slate-100">
              4. Observaciones generales
            </h2>
            <textarea
              rows={4}
              value={observacionesGenerales}
              onChange={(e) => setObservacionesGenerales(e.target.value)}
              className="block w-full rounded-md border border-slate-700 bg-slate-950 px-3 py-1.5 text-xs text-slate-100 placeholder:text-slate-500 focus:border-sky-500 focus:outline-none focus:ring-1 focus:ring-sky-500"
              placeholder="Describa en forma general el recorrido realizado, dificultades, particularidades del entorno, referencias útiles para la fiscalía, etc."
            />
          </div>

          {/* Sección 5: Datos institucionales para el informe */}
          <div className="space-y-3">
            <h2 className="text-sm font-semibold text-slate-100">
              5. Datos institucionales para el informe
            </h2>
            <div className="grid gap-3 sm:grid-cols-2">
              <div>
                <label className="mb-1 block text-xs font-medium text-slate-200">
                  Secretaría actuante (para firma)
                </label>
                <input
                  type="text"
                  value={secretariaNombre}
                  onChange={(e) => setSecretariaNombre(e.target.value)}
                  className="block w-full rounded-md border border-slate-700 bg-slate-950 px-3 py-1.5 text-xs text-slate-100 placeholder:text-slate-500 focus:border-sky-500 focus:outline-none focus:ring-1 focus:ring-sky-500"
                  placeholder="Ej: Pérez, Juan (Secretario)"
                />
              </div>
              <div>
                <label className="mb-1 block text-xs font-medium text-slate-200">
                  Dependencia policial
                </label>
                <input
                  type="text"
                  value={dependenciaNombre}
                  onChange={(e) => setDependenciaNombre(e.target.value)}
                  className="block w-full rounded-md border border-slate-700 bg-slate-950 px-3 py-1.5 text-xs text-slate-100 placeholder:text-slate-500 focus:border-sky-500 focus:outline-none focus:ring-1 focus:ring-sky-500"
                  placeholder="Ej: Comisaría 1ra. La Plata"
                />
              </div>
            </div>
          </div>

          {/* Acciones */}
          <div className="flex flex-col gap-2 border-t border-slate-800 pt-3 sm:flex-row sm:items-center sm:justify-between">
            <p className="text-[11px] text-slate-400">
              Al guardar, el relevamiento quedará en estado{' '}
              <span className="font-semibold text-amber-300">en curso</span> en
              esta versión simulada. En la versión conectada a base de datos,
              podrá marcarse luego como finalizado e imprimir el informe
              correspondiente.
            </p>
            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => navigate('/relevamientos')}
                className="inline-flex items-center justify-center rounded-md border border-slate-700 px-3 py-1.5 text-xs font-medium text-slate-200 hover:bg-slate-800"
              >
                Cancelar
              </button>
              <button
                type="submit"
                disabled={isSubmitting}
                className="inline-flex items-center justify-center rounded-md bg-sky-600 px-4 py-1.5 text-xs font-semibold text-white shadow-sm hover:bg-sky-700 disabled:cursor-not-allowed disabled:opacity-70"
              >
                {isSubmitting ? 'Guardando…' : 'Guardar relevamiento'}
              </button>
            </div>
          </div>
        </form>
      </div>
    </AppLayout>
  )
}
