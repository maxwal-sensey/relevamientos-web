/**
 * @file NuevaSolicitud.tsx
 * @description Formulario para crear una nueva solicitud de relevamiento (frontend simulado).
 */

import { FormEvent, useState } from 'react'
import { ArrowLeft, Info } from 'lucide-react'
import { useNavigate } from 'react-router'
import AppLayout from '../components/layout/AppLayout'
import { useSystemUser } from '../context/SystemUserContext'
import UnauthorizedScreen from '../components/common/UnauthorizedScreen'

/**
 * generateRegistroNumber
 * @description Genera un número de registro simulado con formato SGR-YYYYMMDD-0001.
 */
function generateRegistroNumber(date: Date): string {
  const year = date.getFullYear()
  const month = `${date.getMonth() + 1}`.padStart(2, '0')
  const day = `${date.getDate()}`.padStart(2, '0')
  // En una implementación real, el secuencial se obtiene de la base de datos.
  const sequential = '0001'
  return `SGR-${year}${month}${day}-${sequential}`
}

/**
 * NuevaSolicitudPage
 * @description Vista de alta de nueva solicitud de relevamiento (sin persistencia real).
 */
export default function NuevaSolicitudPage() {
  const { currentUser } = useSystemUser()
  const navigate = useNavigate()

  const [ipp, setIpp] = useState('')
  const [fiscalia, setFiscalia] = useState('')
  const [caratula, setCaratula] = useState('')
  const [lugar, setLugar] = useState('')
  const [resumen, setResumen] = useState('')
  const [otrasCargas, setOtrasCargas] = useState('')
  const [error, setError] = useState<string | null>(null)
  const [successRegistro, setSuccessRegistro] = useState<string | null>(null)
  const [isSubmitting, setIsSubmitting] = useState(false)

  if (!currentUser) {
    return <UnauthorizedScreen />
  }

  /**
   * handleSubmit
   * @description Valida el formulario y simula el alta de una nueva solicitud.
   */
  const handleSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault()
    setError(null)
    setSuccessRegistro(null)

    if (!ipp.trim() || !fiscalia.trim() || !caratula.trim() || !lugar.trim()) {
      setError('Debe completar todos los campos obligatorios.')
      return
    }

    if (resumen.trim().length < 20) {
      setError(
        'El resumen del hecho debe tener al menos 20 caracteres para una descripción mínima.'
      )
      return
    }

    setIsSubmitting(true)

    try {
      // Simulación de llamada a backend.
      await new Promise((resolve) => setTimeout(resolve, 700))

      const registro = generateRegistroNumber(new Date())
      setSuccessRegistro(registro)

      // En un caso real se limpiaría el formulario y/o se redirigiría al detalle.
      setIpp('')
      setFiscalia('')
      setCaratula('')
      setLugar('')
      setResumen('')
      setOtrasCargas('')
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <AppLayout title="Nueva solicitud de relevamiento">
      <div className="mx-auto max-w-3xl space-y-5">
        {/* Barra de retorno */}
        <button
          type="button"
          onClick={() => navigate('/solicitudes')}
          className="inline-flex items-center gap-1.5 text-xs font-medium text-sky-300 hover:text-sky-200"
        >
          <ArrowLeft className="h-3.5 w-3.5" />
          Volver al listado de solicitudes
        </button>

        {/* Información general */}
        <div className="rounded-xl border border-slate-800 bg-slate-900/70 px-4 py-3 text-xs text-slate-300">
          <p>
            Complete los datos de la solicitud proveniente de la fiscalía. El
            número de registro se genera automáticamente con el formato{' '}
            <span className="font-mono text-sky-300">
              SGR-YYYYMMDD-XXXX
            </span>
            .
          </p>
        </div>

        {/* Mensajes de estado */}
        {error && (
          <div className="rounded-md border border-red-500/60 bg-red-950/60 px-3 py-2 text-xs text-red-100">
            {error}
          </div>
        )}
        {successRegistro && (
          <div className="rounded-md border border-emerald-500/60 bg-emerald-950/60 px-3 py-2 text-xs text-emerald-100">
            Solicitud creada correctamente (simulada). Número de registro:{' '}
            <span className="font-mono font-semibold">{successRegistro}</span>
          </div>
        )}

        {/* Formulario principal */}
        <form
          onSubmit={handleSubmit}
          className="space-y-5 rounded-xl border border-slate-800 bg-slate-900/70 px-4 py-5"
          noValidate
        >
          {/* Datos del caso */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h2 className="text-sm font-semibold text-slate-100">
                Datos del caso
              </h2>
              <p className="text-[11px] text-slate-400">
                Campos marcados con * son obligatorios.
              </p>
            </div>

            <div className="grid gap-3 sm:grid-cols-2">
              <div>
                <label
                  htmlFor="ipp"
                  className="mb-1 block text-xs font-medium text-slate-200"
                >
                  Número de IPP *
                </label>
                <input
                  id="ipp"
                  type="text"
                  value={ipp}
                  onChange={(e) => setIpp(e.target.value)}
                  className="block w-full rounded-md border border-slate-700 bg-slate-950 px-3 py-1.5 text-xs text-slate-100 placeholder:text-slate-500 focus:border-sky-500 focus:outline-none focus:ring-1 focus:ring-sky-500"
                  placeholder="Ej: PP-12345-2025"
                />
              </div>

              <div>
                <label
                  htmlFor="fiscalia"
                  className="mb-1 block text-xs font-medium text-slate-200"
                >
                  Fiscalía solicitante *
                </label>
                <input
                  id="fiscalia"
                  type="text"
                  value={fiscalia}
                  onChange={(e) => setFiscalia(e.target.value)}
                  className="block w-full rounded-md border border-slate-700 bg-slate-950 px-3 py-1.5 text-xs text-slate-100 placeholder:text-slate-500 focus:border-sky-500 focus:outline-none focus:ring-1 focus:ring-sky-500"
                  placeholder="Ej: UFIJ N° 3, La Plata"
                />
              </div>
            </div>

            <div>
              <label
                htmlFor="caratula"
                className="mb-1 block text-xs font-medium text-slate-200"
              >
                Carátula del hecho *
              </label>
              <input
                id="caratula"
                type="text"
                value={caratula}
                onChange={(e) => setCaratula(e.target.value)}
                className="block w-full rounded-md border border-slate-700 bg-slate-950 px-3 py-1.5 text-xs text-slate-100 placeholder:text-slate-500 focus:border-sky-500 focus:outline-none focus:ring-1 focus:ring-sky-500"
                placeholder="Ej: Robo agravado por el uso de arma"
              />
            </div>
          </div>

          {/* Lugar del hecho */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h2 className="text-sm font-semibold text-slate-100">
                Lugar del hecho
              </h2>
            </div>

            <div>
              <label
                htmlFor="lugar"
                className="mb-1 block text-xs font-medium text-slate-200"
              >
                Dirección / Referencia geográfica *
              </label>
              <input
                id="lugar"
                type="text"
                value={lugar}
                onChange={(e) => setLugar(e.target.value)}
                className="block w-full rounded-md border border-slate-700 bg-slate-950 px-3 py-1.5 text-xs text-slate-100 placeholder:text-slate-500 focus:border-sky-500 focus:outline-none focus:ring-1 focus:ring-sky-500"
                placeholder="Ej: Calle Falsa 123, entre 4 y 5, La Plata"
              />
            </div>

            <div className="flex items-start gap-2 rounded-md border border-slate-700 bg-slate-950 px-3 py-2 text-[11px] text-slate-300">
              <Info className="mt-0.5 h-3.5 w-3.5 text-sky-400" />
              <p>
                En una próxima iteración se incorporará un mapa interactivo para
                búsqueda y selección precisa de la ubicación (Leaflet +
                OpenStreetMap), guardando coordenadas de latitud/longitud.
              </p>
            </div>
          </div>

          {/* Descripción del hecho */}
          <div className="space-y-3">
            <h2 className="text-sm font-semibold text-slate-100">
              Descripción del hecho
            </h2>

            <div>
              <label
                htmlFor="resumen"
                className="mb-1 block text-xs font-medium text-slate-200"
              >
                Resumen del hecho *
              </label>
              <textarea
                id="resumen"
                value={resumen}
                onChange={(e) => setResumen(e.target.value)}
                rows={4}
                className="block w-full rounded-md border border-slate-700 bg-slate-950 px-3 py-1.5 text-xs text-slate-100 placeholder:text-slate-500 focus:border-sky-500 focus:outline-none focus:ring-1 focus:ring-sky-500"
                placeholder="Describa brevemente los hechos relevantes, fecha aproximada, modalidad, víctimas, etc."
              />
            </div>

            <div>
              <label
                htmlFor="otrasCargas"
                className="mb-1 block text-xs font-medium text-slate-200"
              >
                Otras cargas relevantes (opcional)
              </label>
              <textarea
                id="otrasCargas"
                value={otrasCargas}
                onChange={(e) => setOtrasCargas(e.target.value)}
                rows={3}
                className="block w-full rounded-md border border-slate-700 bg-slate-950 px-3 py-1.5 text-xs text-slate-100 placeholder:text-slate-500 focus:border-sky-500 focus:outline-none focus:ring-1 focus:ring-sky-500"
                placeholder="Información adicional que pueda orientar el relevamiento (cámaras conocidas, domicilios clave, etc.)."
              />
            </div>
          </div>

          {/* Acciones */}
          <div className="flex flex-col gap-2 border-t border-slate-800 pt-3 sm:flex-row sm:items-center sm:justify-between">
            <p className="text-[11px] text-slate-400">
              Al guardar, la solicitud quedará en estado{' '}
              <span className="font-semibold text-amber-300">pendiente</span> y
              se podrá asignar a un relevador desde el backend.
            </p>
            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => navigate('/solicitudes')}
                className="inline-flex items-center justify-center rounded-md border border-slate-700 px-3 py-1.5 text-xs font-medium text-slate-200 hover:bg-slate-800"
              >
                Cancelar
              </button>
              <button
                type="submit"
                disabled={isSubmitting}
                className="inline-flex items-center justify-center rounded-md bg-sky-600 px-4 py-1.5 text-xs font-semibold text-white shadow-sm hover:bg-sky-700 disabled:cursor-not-allowed disabled:opacity-70"
              >
                {isSubmitting ? 'Guardando…' : 'Guardar solicitud'}
              </button>
            </div>
          </div>
        </form>
      </div>
    </AppLayout>
  )
}
