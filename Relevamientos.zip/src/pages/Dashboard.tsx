/**
 * @file Dashboard.tsx
 * @description Panel principal con indicadores clave del Sistema de Gestión de Relevamientos.
 *              Ahora obtiene métricas reales a partir del mock-store de solicitudes e informes.
 */

import React, { useEffect, useState } from 'react'
import { Camera, FileText, UserCheck, Users } from 'lucide-react'
import AppLayout from '../components/layout/AppLayout'
import { useSystemUser } from '../context/SystemUserContext'
import UnauthorizedScreen from '../components/common/UnauthorizedScreen'
import { fetchSolicitudes, Solicitud as SolicitudTipo } from '../mock/solicitudesStore'
import { getInformeById, InformeRelevamientoData } from '../mock/relevamientosStore'

/**
 * SummaryCardProps
 * @description Propiedades para tarjetas de resumen.
 */
interface SummaryCardProps {
  title: string
  value: string
  description: string
  icon: JSX.Element
  accentColorClass: string
}

/**
 * SummaryCard
 * @description Tarjeta individual que muestra un indicador numérico.
 */
function SummaryCard({
  title,
  value,
  description,
  icon,
  accentColorClass,
}: SummaryCardProps) {
  return (
    <div className="relative overflow-hidden rounded-xl border border-slate-800 bg-slate-900/60 px-4 py-4 shadow-sm">
      <div
        className={`absolute inset-x-0 top-0 h-1 ${accentColorClass} opacity-80`}
      />
      <div className="flex items-start justify-between gap-3">
        <div className="space-y-1">
          <p className="text-xs font-medium uppercase tracking-wide text-slate-400">
            {title}
          </p>
          <p className="text-2xl font-semibold text-slate-50">{value}</p>
          <p className="text-xs text-slate-400">{description}</p>
        </div>
        <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-slate-800/80 text-slate-100">
          {icon}
        </div>
      </div>
    </div>
  )
}

/**
 * DashboardPage
 * @description Página de dashboard general con métricas calculadas a partir del mock-store.
 */
export default function DashboardPage() {
  const { currentUser } = useSystemUser()

  const [loading, setLoading] = useState(true)
  const [solicitudes, setSolicitudes] = useState<SolicitudTipo[]>([])
  const [informes, setInformes] = useState<InformeRelevamientoData[]>([])

  useEffect(() => {
    let mounted = true
    async function load() {
      setLoading(true)
      try {
        const sols = await fetchSolicitudes()
        if (!mounted) return
        setSolicitudes(sols)

        // Cargar informes existentes probando ids comunes (1..200).
        // Esto replica la aproximación ya usada en otras partes del mock.
        const items: InformeRelevamientoData[] = []
        for (let i = 1; i <= 200; i++) {
          const inf = getInformeById(i)
          if (inf) items.push(inf)
        }
        if (!mounted) return
        setInformes(items)
      } finally {
        if (!mounted) return
        setLoading(false)
      }
    }
    load()
    return () => {
      mounted = false
    }
  }, [])

  if (!currentUser) {
    return <UnauthorizedScreen />
  }

  // Métricas derivadas
  const totalSolicitudes = solicitudes.length
  const pendientes = solicitudes.filter((s) => s.estado === 'pendiente').length
  const finalizadas = solicitudes.filter((s) => s.estado === 'finalizada').length

  const totalRelevamientos = informes.length
  const totalCamaras = informes.reduce((acc, inf) => acc + (inf.camaras?.length ?? 0), 0)
  const vecinos = informes.reduce((acc, inf) => acc + (inf.vecinos?.length ?? 0), 0)

  return (
    <AppLayout title="Dashboard general">
      <section className="space-y-6">
        {/* Encabezado contextual */}
        <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <p className="text-sm text-slate-300">
              Bienvenido,{' '}
              <span className="font-semibold">
                {currentUser.apellido}, {currentUser.nombre}
              </span>
              .
            </p>
            <p className="mt-1 max-w-xl text-xs text-slate-400">
              Este panel muestra un resumen de las solicitudes, relevamientos y
              actividad general del sistema. Los datos provienen del store mock.
            </p>
          </div>
          <div className="flex flex-wrap gap-2 text-[11px] text-slate-400">
            <span className="inline-flex items-center rounded-full border border-slate-700 px-2 py-1">
              Rol:{' '}
              <span className="ml-1 capitalize text-slate-100">
                {currentUser.rol}
              </span>
            </span>
            <span className="inline-flex items-center rounded-full border border-slate-700 px-2 py-1">
              Dependencia:{' '}
              <span className="ml-1 text-slate-100">
                {currentUser.dependenciaId
                  ? `#${currentUser.dependenciaId}`
                  : 'No asignada'}
              </span>
            </span>
          </div>
        </div>

        {/* Tarjetas principales */}
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          <SummaryCard
            title="Solicitudes pendientes"
            value={loading ? '—' : String(pendientes)}
            description="Solicitudes de relevamiento en estado pendiente."
            accentColorClass="bg-amber-500"
            icon={<FileText className="h-5 w-5" />}
          />
          <SummaryCard
            title="Solicitudes finalizadas"
            value={loading ? '—' : String(finalizadas)}
            description="Solicitudes cerradas con relevamientos cargados."
            accentColorClass="bg-emerald-500"
            icon={<FileText className="h-5 w-5" />}
          />
          <SummaryCard
            title="Total relevamientos"
            value={loading ? '—' : String(totalRelevamientos)}
            description="Relevamientos vecinales y de cámaras registrados."
            accentColorClass="bg-sky-500"
            icon={<Camera className="h-5 w-5" />}
          />
          <SummaryCard
            title="Cámaras registradas"
            value={loading ? '—' : String(totalCamaras)}
            description="Cámaras privadas y COM asociadas a relevamientos."
            accentColorClass="bg-cyan-500"
            icon={<Camera className="h-5 w-5" />}
          />
          <SummaryCard
            title="Vecinos entrevistados"
            value={loading ? '—' : String(vecinos)}
            description="Personas entrevistadas en el marco de relevamientos."
            accentColorClass="bg-violet-500"
            icon={<Users className="h-5 w-5" />}
          />
          <SummaryCard
            title="Relevadores activos"
            value="7"
            description="Personal de campo con actividad en los últimos 30 días."
            accentColorClass="bg-indigo-500"
            icon={<UserCheck className="h-5 w-5" />}
          />
        </div>

        {/* Sección secundaria descriptiva */}
        <div className="grid gap-4 md:grid-cols-2">
          <div className="rounded-xl border border-slate-800 bg-slate-900/60 px-4 py-4">
            <h2 className="mb-2 text-sm font-semibold text-slate-100">
              Próximos pasos
            </h2>
            <p className="mb-3 text-xs text-slate-400">
              A medida que se vayan implementando los módulos, este dashboard
              mostrará estadísticas reales provenientes de la base de datos D1.
            </p>
            <ul className="list-inside list-disc space-y-1.5 text-xs text-slate-400">
              <li>Integrar listado de solicitudes con filtros avanzados.</li>
              <li>Mostrar evolución mensual de relevamientos.</li>
              <li>Incorporar ranking de relevadores y mapas de calor.</li>
            </ul>
          </div>

          <div className="rounded-xl border border-slate-800 bg-slate-900/60 px-4 py-4">
            <h2 className="mb-2 text-sm font-semibold text-slate-100">
              Notas de diseño
            </h2>
            <p className="mb-3 text-xs text-slate-400">
              Esta vista está optimizada para uso diario en escritorio, con buen
              contraste y jerarquía visual clara para entornos institucionales.
            </p>
            <p className="text-xs text-slate-400">
              Los módulos de Solicitudes, Relevamientos, Usuarios y
              Notificaciones se irán conectando progresivamente a este panel,
              manteniendo un diseño consistente y accesible.
            </p>
          </div>
        </div>
      </section>
    </AppLayout>
  )
}