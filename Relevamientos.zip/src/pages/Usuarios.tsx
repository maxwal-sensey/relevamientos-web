/**
 * @file Usuarios.tsx
 * @description Listado y administración de usuarios conectada al backend real (D1) o mocks.
 */

import { useEffect, useMemo, useState } from 'react'
import { KeyRound, Search, Shield, Trash2, Pencil, UserPlus } from 'lucide-react'
import AppLayout from '../components/layout/AppLayout'
import { useSystemUser } from '../context/SystemUserContext'
import UnauthorizedScreen from '../components/common/UnauthorizedScreen'
import {
  UserFormModal,
  type UserFormValues,
  type UserFormMode,
} from '../components/users/UserFormModal'
import { listUsers, createUser, updateUser, deleteUser } from '../lib/apiClient'

/**
 * UsuariosPage
 * @description Vista de administración de usuarios; consume API real si USE_MOCKS = false.
 */
export default function UsuariosPage() {
  const { currentUser } = useSystemUser()
  const [searchTerm, setSearchTerm] = useState('')
  const [roleFilter, setRoleFilter] = useState<'todos' | 'secretario' | 'relevador' | 'administrador'>('todos')
  const [isFormOpen, setIsFormOpen] = useState(false)
  const [formMode, setFormMode] = useState<UserFormMode>('create')
  const [selectedUser, setSelectedUser] = useState<UserFormValues | null>(null)

  const [users, setUsers] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  // Acceso restringido a administradores
  if (!currentUser || currentUser.rol !== 'administrador') {
    return <UnauthorizedScreen />
  }

  /**
   * loadUsers
   * @description Carga usuarios desde API y actualiza estado.
   */
  async function loadUsers() {
    setLoading(true)
    setError(null)
    try {
      const res = await listUsers()
      if (res && res.ok) {
        setUsers(res.users ?? [])
      } else if (res && res.users) {
        setUsers(res.users)
      } else {
        // Fallback: intentar estructura plana
        setUsers(res.users ?? [])
      }
    } catch (err: any) {
      console.error('loadUsers error', err)
      setError(String(err?.message ?? err))
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    loadUsers()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  /**
   * filteredUsers
   */
  const filteredUsers = useMemo(() => {
    const term = searchTerm.trim().toLowerCase()
    return users.filter((user) => {
      const matchesRole = roleFilter === 'todos' || user.rol === roleFilter
      if (!matchesRole) return false
      if (!term) return true
      const fullName = `${user.apellido} ${user.nombre}`.toLowerCase()
      const dependencia = (user.dependenciaNombre ?? '').toLowerCase()
      return user.legajo.toLowerCase().includes(term) || fullName.includes(term) || dependencia.includes(term)
    })
  }, [users, searchTerm, roleFilter])

  /**
   * handleCreate
   */
  async function handleCreate(values: UserFormValues) {
    try {
      const payload = {
        legajo: values.legajo,
        nombre: values.nombre,
        apellido: values.apellido,
        jerarquia: values.jerarquia,
        rol: values.rol,
        dependenciaId: null,
        dependenciaNombre: values.dependenciaNombre,
        telefono: values.telefono,
        email: values.email,
        isActive: values.isActive,
        password: 'changeme', // valor por defecto; se puede mejorar con modal de contraseña
      }
      const res = await createUser(payload)
      if (res && res.ok) {
        await loadUsers()
        setIsFormOpen(false)
      } else {
        alert('Error creando usuario')
      }
    } catch (err: any) {
      alert('Error creando usuario: ' + String(err?.message ?? err))
    }
  }

  /**
   * handleUpdate
   */
  async function handleUpdate(values: UserFormValues) {
    try {
      // buscar id dentro del selectedUser (si existe)
      const id = (selectedUser as any)?.id ?? (values as any)?.id
      const payload: any = {
        nombre: values.nombre,
        apellido: values.apellido,
        jerarquia: values.jerarquia,
        rol: values.rol,
        dependenciaNombre: values.dependenciaNombre,
        telefono: values.telefono,
        email: values.email,
        isActive: values.isActive,
      }
      await updateUser(id, payload)
      await loadUsers()
      setIsFormOpen(false)
      setSelectedUser(null)
    } catch (err: any) {
      alert('Error actualizando usuario: ' + String(err?.message ?? err))
    }
  }

  /**
   * handleDelete
   */
  async function handleDelete(id: number) {
    const ok = confirm('Eliminar usuario?')
    if (!ok) return
    try {
      await deleteUser(id)
      await loadUsers()
    } catch (err: any) {
      alert('Error eliminando usuario: ' + String(err?.message ?? err))
    }
  }

  return (
    <AppLayout title="Usuarios">
      <div className="space-y-4">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <p className="text-sm text-slate-200">
              Administración de usuarios del Sistema de Gestión de Relevamientos.
            </p>
            <p className="text-xs text-slate-400">
              Crear, editar y eliminar usuarios. Los cambios se persisten en la base de datos.
            </p>
          </div>
          <div className="flex flex-col items-stretch gap-2 sm:flex-row sm:items-center">
            <button
              type="button"
              onClick={() => {
                setFormMode('create')
                setSelectedUser(null)
                setIsFormOpen(true)
              }}
              className="inline-flex items-center justify-center gap-1.5 rounded-md bg-sky-600 px-3 py-1.5 text-xs font-semibold text-white shadow-sm hover:bg-sky-700"
            >
              <UserPlus className="h-3.5 w-3.5" />
              Nuevo usuario
            </button>
            <div className="inline-flex items-center gap-1 rounded-full border border-emerald-500/40 bg-emerald-500/10 px-3 py-1 text-[11px] text-emerald-100">
              <Shield className="h-3.5 w-3.5" />
              <span>Acceso sólo administradores</span>
            </div>
          </div>
        </div>

        {error && <div className="rounded-md border border-red-500/60 bg-red-950/60 px-3 py-2 text-xs text-red-100">{error}</div>}

        <div className="grid gap-3 rounded-xl border border-slate-800 bg-slate-900/70 p-3 sm:grid-cols-3">
          <div className="sm:col-span-2">
            <label className="mb-1 block text-xs font-medium text-slate-300">Búsqueda por nombre, legajo o dependencia</label>
            <div className="relative">
              <Search className="pointer-events-none absolute left-2 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-500" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Ej: 1000, Admin, Comisaría 1ra..."
                className="block w-full rounded-md border border-slate-700 bg-slate-900 pl-8 pr-3 text-xs text-slate-100 placeholder:text-slate-500 focus:border-sky-500 focus:outline-none focus:ring-1 focus:ring-sky-500"
              />
            </div>
          </div>
          <div>
            <label className="mb-1 block text-xs font-medium text-slate-300">Rol</label>
            <select
              value={roleFilter}
              onChange={(e) => setRoleFilter(e.target.value as any)}
              className="block w-full rounded-md border border-slate-700 bg-slate-900 px-2 py-1.5 text-xs text-slate-100 focus:border-sky-500 focus:outline-none focus:ring-1 focus:ring-sky-500"
            >
              <option value="todos">Todos</option>
              <option value="secretario">Secretario</option>
              <option value="relevador">Relevador</option>
              <option value="administrador">Administrador</option>
            </select>
          </div>
        </div>

        <div className="overflow-hidden rounded-xl border border-slate-800 bg-slate-900/70">
          <div className="border-b border-slate-800 bg-slate-900/80 px-4 py-2 text-xs text-slate-400">
            {loading ? 'Cargando usuarios...' : `${filteredUsers.length} usuario${filteredUsers.length !== 1 ? 's' : ''} encontrado${filteredUsers.length !== 1 ? 's' : ''}.`}
          </div>
          <div className="overflow-x-auto">
            <table className="min-w-full border-separate border-spacing-0 text-xs">
              <thead>
                <tr className="bg-slate-900">
                  <th className="border-b border-slate-800 px-3 py-2 text-left font-semibold text-slate-300">Legajo</th>
                  <th className="border-b border-slate-800 px-3 py-2 text-left font-semibold text-slate-300">Nombre</th>
                  <th className="border-b border-slate-800 px-3 py-2 text-left font-semibold text-slate-300">Jerarquía</th>
                  <th className="border-b border-slate-800 px-3 py-2 text-left font-semibold text-slate-300">Rol</th>
                  <th className="border-b border-slate-800 px-3 py-2 text-left font-semibold text-slate-300">Dependencia</th>
                  <th className="border-b border-slate-800 px-3 py-2 text-left font-semibold text-slate-300">Teléfono</th>
                  <th className="border-b border-slate-800 px-3 py-2 text-left font-semibold text-slate-300">Estado</th>
                  <th className="border-b border-slate-800 px-3 py-2 text-right font-semibold text-slate-300">Acciones</th>
                </tr>
              </thead>
              <tbody>
                {filteredUsers.map((user) => (
                  <tr key={user.id} className="border-t border-slate-800 odd:bg-slate-900/60 even:bg-slate-900/40">
                    <td className="whitespace-nowrap px-3 py-2 font-mono text-slate-100">{user.legajo}</td>
                    <td className="px-3 py-2 text-slate-100">{user.apellido}, {user.nombre}</td>
                    <td className="px-3 py-2 text-slate-200">{user.jerarquia}</td>
                    <td className="px-3 py-2">
                      <span className={[
                        'inline-flex items-center rounded-full px-2 py-0.5 text-[11px] font-medium capitalize',
                        user.rol === 'administrador'
                          ? 'bg-purple-500/20 text-purple-200 ring-1 ring-purple-400/40'
                          : user.rol === 'relevador'
                          ? 'bg-amber-500/20 text-amber-200 ring-1 ring-amber-400/40'
                          : 'bg-sky-500/20 text-sky-200 ring-1 ring-sky-400/40',
                      ].join(' ')}>
                        {user.rol}
                      </span>
                    </td>
                    <td className="px-3 py-2 text-slate-200">{user.dependenciaNombre ?? '—'}</td>
                    <td className="px-3 py-2 text-slate-200">{user.telefono ?? '—'}</td>
                    <td className="px-3 py-2">
                      <span className={[
                        'inline-flex items-center rounded-full px-2 py-0.5 text-[11px] font-medium',
                        user.isActive ? 'bg-emerald-500/20 text-emerald-200 ring-1 ring-emerald-400/40' : 'bg-red-500/20 text-red-200 ring-1 ring-red-400/40',
                      ].join(' ')}>
                        {user.isActive ? 'Activo' : 'Inactivo'}
                      </span>
                    </td>
                    <td className="px-3 py-2">
                      <div className="flex justify-end gap-1.5">
                        <button
                          type="button"
                          className="inline-flex h-7 w-7 items-center justify-center rounded-md bg-slate-800 text-slate-100 hover:bg-slate-700"
                          onClick={() => {
                            alert('Establecer contraseña: en esta versión se asigna contraseña por defecto al crear usuarios. Para actualizar, use el endpoint correspondiente.')
                          }}
                        >
                          <KeyRound className="h-3.5 w-3.5" />
                          <span className="sr-only">Establecer contraseña</span>
                        </button>
                        <button
                          type="button"
                          className="inline-flex h-7 w-7 items-center justify-center rounded-md bg-slate-800 text-slate-100 hover:bg-slate-700"
                          onClick={() => {
                            setFormMode('edit')
                            setSelectedUser(user)
                            setIsFormOpen(true)
                          }}
                        >
                          <Pencil className="h-3.5 w-3.5" />
                          <span className="sr-only">Editar usuario</span>
                        </button>
                        <button
                          type="button"
                          className="inline-flex h-7 w-7 items-center justify-center rounded-md bg-slate-800 text-slate-100 hover:bg-slate-700"
                          onClick={() => handleDelete(user.id)}
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                          <span className="sr-only">Eliminar usuario</span>
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}

                {filteredUsers.length === 0 && (
                  <tr>
                    <td colSpan={8} className="px-3 py-6 text-center text-xs text-slate-400">
                      {loading ? 'Cargando...' : 'No se encontraron usuarios con los filtros seleccionados.'}
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      <UserFormModal
        open={isFormOpen}
        mode={formMode}
        initialUser={selectedUser ?? undefined}
        onClose={() => {
          setIsFormOpen(false)
          setSelectedUser(null)
        }}
        onSubmit={(vals) => {
          if (formMode === 'create') handleCreate(vals)
          else handleUpdate(vals)
        }}
      />
    </AppLayout>
  )
}