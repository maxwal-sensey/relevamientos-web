/**
 * @file jerarquiasStore.ts
 * @description Mock store para jerarquías (datos demo y operaciones básicas).
 */

export interface DemoJerarquia {
  /** Identificador único */
  id: string
  /** Nombre de la jerarquía (ej: "Of. Principal") */
  nombre: string
  /** Orden para mostrar en dropdowns/listados */
  orden: number
  /** Fecha de creación ISO */
  fechaCreacion: string
}

/**
 * @description Lista interna con jerarquías demo precargadas.
 */
let JERARQUIAS: DemoJerarquia[] = [
  { id: 'j-1', nombre: 'Of. Principal', orden: 1, fechaCreacion: new Date().toISOString() },
  { id: 'j-2', nombre: 'Comisario', orden: 2, fechaCreacion: new Date().toISOString() },
  { id: 'j-3', nombre: 'Subcomisario', orden: 3, fechaCreacion: new Date().toISOString() },
]

/**
 * getJerarquias
 * @description Devuelve una copia ordenada de las jerarquías demo.
 * @returns DemoJerarquia[]
 */
export function getJerarquias(): DemoJerarquia[] {
  return [...JERARQUIAS].sort((a, b) => a.orden - b.orden)
}

/**
 * createJerarquia
 * @description Crea una nueva jerarquía en el store demo.
 * @param nombre Nombre de la jerarquía
 * @param orden Orden numérico (opcional)
 * @returns DemoJerarquia
 */
export function createJerarquia(nombre: string, orden?: number): DemoJerarquia {
  const id = `j-${Math.random().toString(36).slice(2, 9)}`
  const newOrden = typeof orden === 'number' ? orden : JERARQUIAS.length + 1
  const nueva: DemoJerarquia = {
    id,
    nombre,
    orden: newOrden,
    fechaCreacion: new Date().toISOString(),
  }
  JERARQUIAS = [...JERARQUIAS, nueva]
  return nueva
}

/**
 * updateJerarquia
 * @description Actualiza una jerarquía existente por id.
 * @param id Identificador de la jerarquía
 * @param payload Campos a actualizar
 * @returns DemoJerarquia | null
 */
export function updateJerarquia(id: string, payload: Partial<Omit<DemoJerarquia, 'id' | 'fechaCreacion'>>): DemoJerarquia | null {
  let updated: DemoJerarquia | null = null
  JERARQUIAS = JERARQUIAS.map((j) => {
    if (j.id === id) {
      updated = { ...j, ...payload }
      return updated
    }
    return j
  })
  return updated
}

/**
 * deleteJerarquia
 * @description Elimina una jerarquía del store demo por id.
 * @param id Identificador a eliminar
 * @returns boolean Indica si se eliminó correctamente
 */
export function deleteJerarquia(id: string): boolean {
  const prevLen = JERARQUIAS.length
  JERARQUIAS = JERARQUIAS.filter((j) => j.id !== id)
  return JERARQUIAS.length < prevLen
}