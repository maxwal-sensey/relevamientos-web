/**
 * @file demoUsers.ts
 * @description Usuarios demo en memoria para pruebas (servicios de autenticación y listados).
 */

import type { SystemUserRole } from '../context/SystemUserContext'

/**
 * DemoUser
 * @description Representa un usuario demo con datos y contraseña de prueba.
 */
export interface DemoUser {
  id: number
  legajo: string
  nombre: string
  apellido: string
  rol: SystemUserRole
  dependenciaId?: number | null
  dependenciaNombre: string
  jerarquia: string
  telefono?: string
  email?: string
  isActive: boolean
  password: string
}

/**
 * DEMO_USERS
 * @description Lista de usuarios de prueba. Usada por el login demo y componentes administrativos.
 */
export const DEMO_USERS: DemoUser[] = [
  {
    id: 1,
    legajo: '1000',
    nombre: 'Admin',
    apellido: 'Demo',
    rol: 'administrador',
    dependenciaId: null,
    dependenciaNombre: 'Dependencia central',
    jerarquia: 'Crio. Mayor',
    telefono: '221-000-0000',
    email: 'admin.demo@sgr.test',
    isActive: true,
    password: 'admin123',
  },
  {
    id: 2,
    legajo: '2000',
    nombre: 'Ana',
    apellido: 'Secretaria',
    rol: 'secretario',
    dependenciaId: 10,
    dependenciaNombre: 'Comisaría 1ra. La Plata',
    jerarquia: 'Of. Ppal.',
    telefono: '221-111-1111',
    email: 'ana.secretaria@sgr.test',
    isActive: true,
    password: 'sec123',
  },
  {
    id: 3,
    legajo: '3000',
    nombre: 'Carlos',
    apellido: 'Relevador',
    rol: 'relevador',
    dependenciaId: 10,
    dependenciaNombre: 'Comisaría 1ra. La Plata',
    jerarquia: 'Sgto.',
    telefono: '221-222-2222',
    email: 'carlos.relevador@sgr.test',
    isActive: true,
    password: 'rel123',
  },
  {
    id: 4,
    legajo: '9999',
    nombre: 'Usuario',
    apellido: 'Prueba',
    rol: 'administrador',
    dependenciaId: null,
    dependenciaNombre: 'Dependencia de Prueba',
    jerarquia: 'Crio. Mayor',
    telefono: '221-999-9999',
    email: 'usuario.prueba@sgr.test',
    isActive: true,
    password: 'prueba123',
  },
]

/**
 * findDemoUserByCredentials
 * @description Busca un usuario demo por legajo y contraseña (uso en SystemUserProvider).
 * @param legajo Número de legajo como string
 * @param password Contraseña en texto plano (demo)
 * @returns DemoUser | undefined
 */
export function findDemoUserByCredentials(
  legajo: string,
  password: string
): DemoUser | undefined {
  const normalizedLegajo = legajo.trim()
  const normalizedPassword = password.trim()

  return DEMO_USERS.find(
    (user) =>
      user.legajo === normalizedLegajo && user.password === normalizedPassword
  )
}

/**
 * findDemoUserByLegajo
 * @description Busca un usuario demo por legajo sin validar contraseña.
 * @param legajo Número de legajo como string
 * @returns DemoUser | undefined
 */
export function findDemoUserByLegajo(legajo: string): DemoUser | undefined {
  const normalizedLegajo = legajo.trim()
  return DEMO_USERS.find((u) => u.legajo === normalizedLegajo)
}

/**
 * getAllDemoUsers
 * @description Retorna una copia del arreglo de usuarios demo (evita mutaciones externas).
 * @returns DemoUser[]
 */
export function getAllDemoUsers(): DemoUser[] {
  return DEMO_USERS.slice()
}