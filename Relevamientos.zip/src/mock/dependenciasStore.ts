/**
 * @file dependenciasStore.ts
 * @description Fuente de datos de ejemplo para la gestión de dependencias (solo frontend demo).
 */

export interface DemoDependencia {
  /** Identificador único de la dependencia en la demo. */
  id: number
  /** Nombre visible de la dependencia. */
  nombre: string
  /** Descripción breve de la dependencia. */
  descripcion?: string
  /** Cantidad de usuarios asociados (dato ilustrativo). */
  cantidadUsuarios: number
  /** Fecha de creación (ISO string) usada solo para mostrar. */
  fechaCreacion: string
}

/** Conjunto fijo de dependencias de ejemplo. */
const DEMO_DEPENDENCIAS: DemoDependencia[] = [
  {
    id: 1,
    nombre: 'Dependencia central',
    descripcion: 'Sede central administrativa del Sistema de Gestión de Relevamientos.',
    cantidadUsuarios: 8,
    fechaCreacion: '2024-01-15',
  },
  {
    id: 2,
    nombre: 'Comisaría 1ra. La Plata',
    descripcion: 'Unidad policial responsable de la zona céntrica de La Plata.',
    cantidadUsuarios: 12,
    fechaCreacion: '2024-02-01',
  },
  {
    id: 3,
    nombre: 'Comisaría 2da. La Plata',
    descripcion: 'Cobertura de barrios periféricos de la ciudad de La Plata.',
    cantidadUsuarios: 9,
    fechaCreacion: '2024-03-10',
  },
]

/**
 * getDependencias
 * @description Devuelve el listado de dependencias demo ordenado por nombre.
 */
export function getDependencias(): DemoDependencia[] {
  return [...DEMO_DEPENDENCIAS].sort((a, b) =>
    a.nombre.localeCompare(b.nombre, 'es-AR', { sensitivity: 'base' })
  )
}