/**
 * @file migrate-sqlite.js
 * @description Wrapper Node que ejecuta sqlite3 CLI para aplicar migraciones en un archivo SQLite.
 *              Útil cuando prefieres invocar desde npm scripts: node scripts/migrate-sqlite.js ./data/sgr.sqlite
 *
 * Nota: Este script requiere que sqlite3 esté instalado en el sistema y en el PATH.
 */

const { spawn } = require('child_process')
const fs = require('fs')
const path = require('path')

async function run() {
  const args = process.argv.slice(2)
  const dbPath = args[0] || path.join(process.cwd(), 'data', 'sgr.sqlite')
  const sqlFiles = args.length > 1 ? args.slice(1) : [path.join('src', 'worker', 'migrations', '001_init.sql')]

  if (!sqlFiles.every((f) => fs.existsSync(f))) {
    console.error('Error: Uno o más archivos SQL no existen:', sqlFiles)
    process.exit(1)
  }

  // Verificar sqlite3 existe
  const which = process.platform === 'win32' ? 'where' : 'which'
  const whichProc = spawn(which, ['sqlite3'])
  whichProc.on('exit', (code) => {
    if (code !== 0) {
      console.error('Error: sqlite3 no encontrado en PATH. Instálalo antes de continuar.')
      process.exit(2)
    } else {
      applyAll()
    }
  })

  function applyAll() {
    try {
      // Asegurar carpeta
      fs.mkdirSync(path.dirname(dbPath), { recursive: true })
      for (const sql of sqlFiles) {
        console.log(`Aplicando ${sql} -> ${dbPath}`)
        const proc = spawn('sqlite3', [dbPath], { stdio: ['pipe', process.stdout, process.stderr] })
        const sqlContent = fs.readFileSync(sql, 'utf-8')
        proc.stdin.write(sqlContent)
        proc.stdin.end()
        // esperar a que termine
        const exitCode = require('child_process').spawnSync('sqlite3', [dbPath], { input: sqlContent }).status
        if (exitCode !== 0) {
          console.error(`Error ejecutando ${sql} (exit ${exitCode})`)
          process.exit(3)
        }
      }
      // PRAGMA foreign_keys = ON
      require('child_process').spawnSync('sqlite3', [dbPath, "PRAGMA foreign_keys = ON;"])
      console.log('Migración completada:', dbPath)
    } catch (err) {
      console.error('Error de migración:', err)
      process.exit(4)
    }
  }
}

run()