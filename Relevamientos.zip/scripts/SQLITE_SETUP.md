# Configurar SQLite local para SGR

/**
 * @file SQLITE_SETUP.md
 * @description Guía rápida para crear y poblar una base SQLite local usando los scripts provistos.
 */

Requisitos
- sqlite3 CLI instalado en tu máquina (macOS/Homebrew, Linux apt, Windows choco/WSL).
- Node (opcional si usas node wrapper) para ejecutar scripts/migrate-sqlite.js.

Pasos rápidos
1) Ejecutar migraciones (bash):
   ./scripts/migrate-sqlite.sh ./data/sgr.sqlite src/worker/migrations/001_init.sql

2) Aplicar semilla de datos:
   ./scripts/migrate-sqlite.sh ./data/sgr.sqlite scripts/seed_demo.sql

   o en una misma ejecución:
   ./scripts/migrate-sqlite.sh ./data/sgr.sqlite src/worker/migrations/001_init.sql scripts/seed_demo.sql

3) Verificar contenido:
   sqlite3 ./data/sgr.sqlite "SELECT name FROM sqlite_master WHERE type='table';"

Notas sobre autenticación
- El seed inserta usuarios demo con password_hash vacío. Para producción debes:
  - Insertar password_hash con SHA-256 del password o
  - Usar la API administrativa para establecer contraseñas seguras.

Integración con el Worker / backend local
- El Worker original usa bindings D1 y R2. Para desarrollo local con SQLite:
  - Puedes ejecutar la API en un entorno que soporte sqlite3 y adaptar el codepath del backend para abrir el archivo ./data/sgr.sqlite.
  - Alternativa: seguir usando Cloudflare D1 en staging/producción y emplear SQLite sólo en dev local.

Sugerencia
- Si quieres, puedo:
  1) Añadir un adapter en src/worker/index.ts para que, cuando process.env.SQLITE_FILE esté definido, el Worker use ese archivo con sqlite3 (spawn) o con un paquete sqlite3 (requiere instalar dependencia).
  2) Añadir un script npm (package.json) para ejecutar las migraciones con node.

¿Deseas que implemente el adapter automático en el Worker para usar SQLITE_FILE en desarrollo? Responde \"OK\" para que lo implemente.