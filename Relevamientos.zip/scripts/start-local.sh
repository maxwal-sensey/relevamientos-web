#!/usr/bin/env bash
# /**
#  * @file scripts/start-local.sh
#  * @description Script helper para iniciar el Worker de desarrollo usando Wrangler (npx wrangler dev).
#  *              - Evita usar Miniflare CLI (obsoleto en v3).
#  *              - Exporta SGR_SQLITE_PATH apuntando al archivo SQLite provisto.
#  *              - Uso: ./scripts/start-local.sh [PATH_TO_DB] [PORT]
#  */

set -euo pipefail

DB_PATH="${1:-./data/sgr.sqlite}"
PORT="${2:-8787}"

# Resolución absoluta de la ruta de DB
if [ -f "$DB_PATH" ]; then
  DB_ABS="$(cd "$(dirname "$DB_PATH")" && pwd)/$(basename "$DB_PATH")"
else
  echo "Error: no se encontró la base de datos en: $DB_PATH"
  echo "Crea la DB con: chmod +x scripts/create-and-seed-db.sh && ./scripts/create-and-seed-db.sh $DB_PATH"
  exit 1
fi

export SGR_SQLITE_PATH="$DB_ABS"
echo "SGR_SQLITE_PATH = $SGR_SQLITE_PATH"

# Comprobar disponibilidad de npx
if ! command -v npx >/dev/null 2>&1; then
  echo "Error: npx no está disponible. Instala Node.js (que incluye npx) o usa tu gestor de paquetes."
  exit 2
fi

# Lanzar wrangler dev mediante npx (permite usar tanto wrangler instalado globalmente como la versión remota)
echo "Iniciando Worker con: npx wrangler dev src/worker/index.ts --port $PORT"
echo "Si no tienes Wrangler instalado globalmente, npx lo descargará temporalmente."
echo

# Ejecutar wrangler dev; mantener env var exportada para el proceso
npx wrangler dev src/worker/index.ts --port "$PORT"
