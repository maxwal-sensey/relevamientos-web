#!/usr/bin/env bash
# /**
#  * @file migrate-sqlite.sh
#  * @description Script sencillo para aplicar migraciones SQL en un archivo SQLite local.
#  *              Uso:
#  *                ./scripts/migrate-sqlite.sh ./data/sgr.sqlite src/worker/migrations/001_init.sql scripts/seed_demo.sql
#  *              Requisitos: sqlite3 CLI disponible en el sistema.
#  */

set -e

DB_PATH="${1:-./data/sgr.sqlite}"
shift

# Si no se pasan archivos SQL, usar la migración principal
if [ "$#" -eq 0 ]; then
  SQL_FILES="src/worker/migrations/001_init.sql"
else
  SQL_FILES="$@"
fi

# Verificar sqlite3
if ! command -v sqlite3 >/dev/null 2>&1; then
  echo "Error: sqlite3 CLI no encontrado. Instala sqlite3 en tu sistema para usar este script."
  echo "En macOS: brew install sqlite"
  echo "En Debian/Ubuntu: sudo apt-get install sqlite3"
  exit 2
fi

# Crear carpeta del DB si es necesario
mkdir -p "$(dirname "$DB_PATH")"

echo "Aplicando migraciones en: $DB_PATH"
for sql in $SQL_FILES; do
  if [ ! -f "$sql" ]; then
    echo "Archivo SQL no encontrado: $sql"
    exit 3
  fi
  echo "-> Ejecutando $sql"
  sqlite3 "$DB_PATH" < "$sql"
done

# Asegurar foreign_keys = ON
sqlite3 "$DB_PATH" "PRAGMA foreign_keys = ON;"

echo "Migración completada. Archivo SQLite: $DB_PATH"