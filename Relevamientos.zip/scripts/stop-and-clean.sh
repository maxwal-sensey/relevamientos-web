#!/usr/bin/env bash
# /**
#  * @file scripts/stop-and-clean.sh
#  * @description Script seguro para detener la instancia en ejecución, crear backup de la DB
#  *              y eliminar artefactos locales (node_modules, logs, build, etc.) para un arranque limpio.
#  *              Uso: chmod +x scripts/stop-and-clean.sh && ./scripts/stop-and-clean.sh [RUTA_A_DB]
#  */

set -euo pipefail

# /** @description Ruta al archivo SQLite (por defecto ./data/sgr.sqlite) */
DB_PATH="${1:-./data/sgr.sqlite}"

# /** @description Directorio donde se guardarán backups (se crea automáticamente) */
BACKUP_DIR="./data/backups"

# /** @description Timestamp para el nombre del backup */
TIMESTAMP="$(date +%Y%m%d%H%M%S)"

# /** @description Archivos/carpetas a limpiar */
ARTIFACTS=(node_modules logs dist .cache build .turbo)

# /** @description Archivos PID que el repo usa para gestionar procesos */
PID_FILES=(logs/frontend.pid logs/wrangler.pid)

# /** @description Mensaje informativo */
info() { echo -e "\n[INFO] $*"; }

# /** @description Mensaje de error y salida */
fatal() { echo -e "\n[ERROR] $*" >&2; exit 1; }

# /** @description Comprueba si un comando existe en PATH */
command_exists() { command -v "$1" >/dev/null 2>&1; }

# /**
#  * @description Intenta detener procesos listados en los PID files y procesos comunes por nombre.
#  *              Elimina también los PID files si están presentes.
#  */
stop_processes() {
  info "Deteniendo procesos usando PID files si existen..."
  for pidfile in "${PID_FILES[@]}"; do
    if [ -f "$pidfile" ]; then
      pid="$(cat "$pidfile" 2>/dev/null || echo "")"
      if [ -n "$pid" ]; then
        if kill -0 "$pid" >/dev/null 2>&1; then
          info "Deteniendo PID $pid (archivo: $pidfile)"
          kill "$pid" || true
          sleep 1
        else
          info "PID $pid no está en ejecución"
        fi
      fi
      rm -f "$pidfile" || true
    fi
  done

  info "Intentando matar procesos por nombre (wrangler, vite, node) si quedan..."
  pkill -f "wrangler dev" >/dev/null 2>&1 || true
  pkill -f "vite" >/dev/null 2>&1 || true
  pkill -f "node" >/dev/null 2>&1 || true

  info "Detención de procesos finalizada."
}

# /**
#  * @description Crea un backup seguro de la base de datos SQLite si existe.
#  * @returns 0 si el backup fue exitoso o no era necesario, 1 si falló.
#  */
backup_db() {
  if [ -f "$DB_PATH" ]; then
    mkdir -p "$BACKUP_DIR"
    local dest="$BACKUP_DIR/$(basename "$DB_PATH").$TIMESTAMP.bak"
    info "Creando backup de la DB: $DB_PATH -> $dest"
    if cp "$DB_PATH" "$dest"; then
      info "Backup creado en: $dest"
      return 0
    else
      echo "[ERROR] Falló la copia de backup." >&2
      return 1
    fi
  else
    info "No se encontró la base de datos en: $DB_PATH (se omite backup)"
    return 0
  fi
}

# /**
#  * @description Elimina los artefactos comunes del repositorio (node_modules, logs, build, etc.)
#  */
clean_artifacts() {
  info "Limpiando artefactos locales..."
  for a in "${ARTIFACTS[@]}"; do
    if [ -e "$a" ]; then
      info "Eliminando: $a"
      rm -rf "$a"
    else
      info "No existe: $a"
    fi
  done
  info "Limpieza de artefactos finalizada."
}

# /**
#  * @description Flujo principal del script: confirmación, parada, backup y limpieza.
#  */
main() {
  echo
  echo "Resumen de acciones que realizará este script:"
  echo " - Detener procesos (frontend, worker)"
  echo " - Crear backup de la DB (si existe) en: $BACKUP_DIR"
  echo " - Eliminar: ${ARTIFACTS[*]}"
  echo " - Eliminar el archivo de DB original (si existe) después del backup"
  echo
  read -r -p "¿Deseas continuar? [y/N]: " confirm
  if [[ ! "$confirm" =~ ^[Yy]$ ]]; then
    info "Operación abortada por el usuario."
    exit 0
  fi

  stop_processes

  if ! backup_db; then
    fatal "No se pudo crear el backup de la DB. Abortando para evitar pérdida de datos."
  fi

  clean_artifacts

  if [ -f "$DB_PATH" ]; then
    info "Eliminando archivo de base de datos original: $DB_PATH"
    rm -f "$DB_PATH" || fatal "No se pudo eliminar $DB_PATH"
  else
    info "No hay archivo de DB para eliminar."
  fi

  info "Operación completada. Ahora puedes ejecutar ./scripts/setup-and-run.sh para reinstalar y arrancar."
}

main