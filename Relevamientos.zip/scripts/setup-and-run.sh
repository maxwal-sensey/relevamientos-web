#!/usr/bin/env bash
# /**
#  * @file scripts/setup-and-run.sh
#  * @description Script todo-en-uno para preparar y arrancar el entorno de desarrollo.
#  *              - Comprueba e instala (si procede) node/npm y sqlite3
#  *              - Instala dependencias npm del repo (npm ci)
#  *              - Crea y semilla la base de datos SQLite (scripts/create-and-seed-db.sh)
#  *              - Hace ejecutables los helpers (scripts/*)
#  *              - Arranca el Worker (npx wrangler dev) y el frontend (npm run dev) en background
#  *              - Registra logs y PIDs en logs/
#  *
#  * Nota: El script intenta instalar paquetes usando apt (Debian/Ubuntu) o brew (macOS) cuando es posible.
#  *       Requiere privilegios sudo para instalaciones por apt. Usa SKIP_INSTALL=1 para evitar instalaciones.
#  */

set -euo pipefail

# /**
#  * @description Variables por defecto; se pueden sobrescribir desde la línea de comandos.
#  */
DB_PATH="${1:-./data/sgr.sqlite}"
PORT="${2:-8787}"
SKIP_INSTALL="${SKIP_INSTALL:-0}"   # si 1, no intenta instalar paquetes système automáticamente
REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
LOG_DIR="$REPO_ROOT/logs"
WRANGLER_LOG="$LOG_DIR/wrangler.log"
FRONTEND_LOG="$LOG_DIR/frontend.log"

# /**
#  * @description Imprime un título informativo.
#  */
info() { echo -e "\n[INFO] $*"; }

# /**
#  * @description Imprime un error y sale.
#  */
fatal() { echo -e "\n[ERROR] $*" >&2; exit 1; }

# /**
#  * @description Comprueba si un comando existe.
#  * @param cmd Nombre del comando
#  * @returns 0 si existe, 1 si no
#  */
command_exists() {
  command -v "$1" >/dev/null 2>&1
}

# /**
#  * @description Intenta instalar paquetes usando apt o brew.
#  * @param package Nombre del paquete sistema (sqlite3|node)
#  */
try_install_system_package() {
  local pkg="$1"
  if [[ "$SKIP_INSTALL" == "1" ]]; then
    info "SKIP_INSTALL=1 -> no se intentará instalar $pkg automáticamente"
    return 1
  fi

  if command_exists apt-get; then
    info "Intentando instalar $pkg con apt (requiere sudo)"
    sudo apt-get update -y
    case "$pkg" in
      node)
        curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash - && sudo apt-get install -y nodejs
        ;;
      sqlite3)
        sudo apt-get install -y sqlite3
        ;;
      *)
        sudo apt-get install -y "$pkg"
        ;;
    esac
    return $?
  fi

  if command_exists brew; then
    info "Intentando instalar $pkg con brew"
    case "$pkg" in
      node) brew install node ;;
      sqlite3) brew install sqlite ;;
      *) brew install "$pkg" ;;
    esac
    return $?
  fi

  return 1
}

# /**
#  * @description Verifica requisitos: node, npx, sqlite3, git, curl.
#  */
check_prereqs() {
  info "Comprobando requisitos básicos..."

  if ! command_exists node; then
    info "node no encontrado."
    try_install_system_package node || fatal "Node.js no instalado. Instálalo manualmente (https://nodejs.org/) o exporta SKIP_INSTALL=1 para evitar la instalación automática."
  fi

  if ! command_exists npx; then
    fatal "npx no encontrado aunque node está presente. Asegúrate de tener npm/npx en PATH."
  fi

  if ! command_exists sqlite3; then
    info "sqlite3 no encontrado."
    try_install_system_package sqlite3 || fatal "sqlite3 no instalado. Instálalo manualmente (apt/brew) y vuelve a ejecutar."
  fi

  for cmd in git curl; do
    if ! command_exists "$cmd"; then
      fatal "Requerido: $cmd no encontrado. Instálalo y vuelve a ejecutar."
    fi
  done

  # /**
  #  * @description Mostrar versiones detectadas (informativo).
  #  */
  info "Requisitos verificados: node $(node -v), npx $(npx -v 2>/dev/null || echo 'npx?'), sqlite3 $(sqlite3 --version | awk '{print $1}')"
}

# /**
#  * @description Crea carpetas necesarias y ajusta permisos.
#  */
prepare_dirs() {
  mkdir -p "$LOG_DIR"
  mkdir -p "$(dirname "$DB_PATH")"
  chmod +x "$REPO_ROOT/scripts/"*.sh || true
}

# /**
#  * @description Instala dependencias npm del repo (npm ci preferido).
#  */
install_node_deps() {
  info "Instalando dependencias npm (npm ci)..."
  if [ -f "$REPO_ROOT/package-lock.json" ] || [ -f "$REPO_ROOT/yarn.lock" ]; then
    (cd "$REPO_ROOT" && npm ci) || {
      info "npm ci falló; intentando npm install..."
      (cd "$REPO_ROOT" && npm install)
    }
  else
    (cd "$REPO_ROOT" && npm install)
  fi
  info "Dependencias npm instaladas."
}

# /**
#  * @description Crea y popula la base de datos usando el script repo (si existe).
#  */
create_and_seed_db() {
  info "Creando y poblando la base de datos en: $DB_PATH"
  if [ -x "$REPO_ROOT/scripts/create-and-seed-db.sh" ]; then
    (cd "$REPO_ROOT" && chmod +x scripts/create-and-seed-db.sh && ./scripts/create-and-seed-db.sh "$DB_PATH")
  else
    # Fallback: aplicar migraciones manualmente si el script no existe
    if [ -f "$REPO_ROOT/src/worker/migrations/001_init.sql" ]; then
      sqlite3 "$DB_PATH" < "$REPO_ROOT/src/worker/migrations/001_init.sql"
      if [ -f "$REPO_ROOT/scripts/seed_demo.sql" ]; then
        sqlite3 "$DB_PATH" < "$REPO_ROOT/scripts/seed_demo.sql"
      fi
    else
      fatal "No se encontró script de migración (src/worker/migrations/001_init.sql)."
    fi
  fi
  info "Base de datos creada/semillada."
}

# /**
#  * @description Arranca wrangler dev en background y registra PID en archivo.
#  */
start_wrangler() {
  local abs_db
  abs_db="$(cd "$(dirname "$DB_PATH")" && pwd)/$(basename "$DB_PATH")"
  info "Arrancando Worker con npx wrangler dev (PUERTO=$PORT). Logs: $WRANGLER_LOG"
  # Exportar variable requerida por el worker
  env SGR_SQLITE_PATH="$abs_db" npx --yes wrangler@latest dev src/worker/index.ts --port "$PORT" &> "$WRANGLER_LOG" &
  local pid=$!
  echo "$pid" > "$LOG_DIR/wrangler.pid"
  info "Worker arrancado (PID $pid)."
}

# /**
#  * @description Arranca el frontend en background (npm run dev) y registra PID.
#  */
start_frontend() {
  info "Arrancando frontend (npm run dev). Logs: $FRONTEND_LOG"
  (cd "$REPO_ROOT" && npm run dev &> "$FRONTEND_LOG" &)
  local pid=$!
  echo "$pid" > "$LOG_DIR/frontend.pid"
  info "Frontend arrancado (PID $pid)."
}

# /**
#  * @description Comprueba si los servicios empezaron correctamente (logs básicos).
#  */
health_check_services() {
  info "Esperando unos segundos para comprobación inicial..."
  sleep 4
  if [ -f "$LOG_DIR/wrangler.pid" ]; then
    local pid
    pid=$(cat "$LOG_DIR/wrangler.pid")
    if kill -0 "$pid" >/dev/null 2>&1; then
      info "Worker (PID $pid) parece en ejecución."
    else
      info "Worker no está corriendo. Revisa $WRANGLER_LOG"
    fi
  fi

  if [ -f "$LOG_DIR/frontend.pid" ]; then
    local pidf
    pidf=$(cat "$LOG_DIR/frontend.pid")
    if kill -0 "$pidf" >/dev/null 2>&1; then
      info "Frontend (PID $pidf) parece en ejecución."
    else
      info "Frontend no está corriendo. Revisa $FRONTEND_LOG"
    fi
  fi
}

# /**
#  * @description Punto de entrada principal.
#  */
main() {
  info "Inicio del script de setup y arranque (repo: $REPO_ROOT)"
  check_prereqs
  prepare_dirs

  # Instalar deps node
  install_node_deps

  # Crear DB
  create_and_seed_db

  # Arrancar servicios
  start_wrangler
  start_frontend

  health_check_services

  cat <<EOF

LISTO: El entorno debería estar funcional.

- Worker: revisa $WRANGLER_LOG (PID en $LOG_DIR/wrangler.pid)
- Frontend: revisa $FRONTEND_LOG (PID en $LOG_DIR/frontend.pid)
- DB: $DB_PATH

Comandos útiles:
- Ver logs en tiempo real:
  tail -f $WRANGLER_LOG
  tail -f $FRONTEND_LOG

- Parar servicios:
  kill \$(cat $LOG_DIR/wrangler.pid) || true
  kill \$(cat $LOG_DIR/frontend.pid) || true

Si algo falla, revisa los logs y ejecuta manualmente:
  export SGR_SQLITE_PATH="$(cd "$(dirname "$DB_PATH")" && pwd)/$(basename "$DB_PATH")"
  npx wrangler dev src/worker/index.ts --port $PORT
  npm run dev

EOF
}

# Ejecutar main
main
