#!/usr/bin/env bash
# /**
#  * @file open-db.sh
#  * @description Helper para abrir/verificar la base SQLite del proyecto.
#  *              Detecta errores comunes (DB inexistente, intento de ejecutar el archivo,
#  *              falta del cliente sqlite3 o incompatibilidad del binario).
#  *
#  * Usage:
#  *   chmod +x scripts/open-db.sh
#  *   ./scripts/open-db.sh [path/to/sgr.sqlite]
#  */
set -e

DB_PATH="${1:-./data/sgr.sqlite}"

# Comprobar existencia del archivo
if [ ! -f "$DB_PATH" ]; then
  echo "ERROR: No se encontró la base de datos en: $DB_PATH"
  echo "-> Para crearla y semearla, ejecuta: chmod +x scripts/create-and-seed-db.sh && ./scripts/create-and-seed-db.sh $DB_PATH"
  exit 1
fi

# Aviso si intentaron ejecutar el archivo en lugar de abrirlo
if [ -x "$DB_PATH" ]; then
  echo "AVISO: El archivo $DB_PATH tiene permiso de ejecución. No ejecutes la DB como un binario."
  echo "Usa el cliente sqlite3 para abrirla: sqlite3 $DB_PATH"
fi

# Verificar sqlite3 CLI
if ! command -v sqlite3 >/dev/null 2>&1; then
  echo "ERROR: No se encontró sqlite3 en PATH."
  echo "Instálalo con tu gestor de paquetes (ej.: sudo apt install sqlite3) o usa la imagen/docker correspondiente."
  exit 2
fi

# Intentar listar tablas; capturar fallos y detectar exec format en el binario sqlite3
set +e
OUTPUT=$(sqlite3 "$DB_PATH" ".tables" 2>&1)
RET=$?
set -e

if [ $RET -ne 0 ]; then
  echo "ERROR: sqlite3 no pudo abrir la base de datos."
  echo "Mensaje de sqlite3:"
  echo "$OUTPUT"
  # Sugerencia para exec format del binario sqlite3
  if echo "$OUTPUT" | grep -qi "exec format" || ! file "$(command -v sqlite3)" >/dev/null 2>&1; then
    echo ""
    echo "Posible causa: el binario sqlite3 instalado es incompatible con esta arquitectura (Exec format error)."
    echo "Revisa el binario con: file $(command -v sqlite3)"
    echo "Soluciones:"
    echo " - Instala sqlite3 nativo para tu arquitectura"
    echo " - Usa Docker / chroot con una imagen compatible"
    echo " - Usa el script scripts/create-and-seed-db.sh en una máquina donde sqlite3 funcione"
  fi
  exit 3
fi

# Mostrar tablas y tamaño del archivo
echo "Éxito: tablas en $DB_PATH:"
echo "$OUTPUT"
echo ""
ls -lh "$DB_PATH"
