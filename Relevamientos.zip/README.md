# SGR - Desarrollo local

## Resumen rápido
Este repo contiene el frontend React y el Worker (backend). Para ejecutar el Worker localmente ahora debe usarse `wrangler dev` (Miniflare CLI ya no se distribuye con miniflare v3).

## Preparar la base de datos SQLite
1. Crear y popular la base de datos local:
   chmod +x scripts/create-and-seed-db.sh
   ./scripts/create-and-seed-db.sh ./data/sgr.sqlite

2. Si necesitas inspeccionar la DB sin ejecutarla:
   chmod +x scripts/open-db.sh
   ./scripts/open-db.sh ./data/sgr.sqlite

> Nota: no ejecutes `./data/sgr.sqlite` — es un archivo de datos, no un ejecutable. El error `Exec format error` aparece si intentas ejecutarlo.

## Iniciar el Worker local (desarrollo)
Se añadió un helper que exporta `SGR_SQLITE_PATH` y arranca Wrangler:

1. Hacer ejecutable el script:
   chmod +x scripts/start-local.sh

2. Ejecutar (ruta a DB y puerto opcionales):
   ./scripts/start-local.sh ./data/sgr.sqlite 8787

Alternativa manual:
export SGR_SQLITE_PATH="$(pwd)/data/sgr.sqlite"
npx wrangler dev src/worker/index.ts --port 8787

### Requisitos
- Node.js (incluye `npx`)
- Wrangler (no es obligatorio instalar globalmente; `npx wrangler` funciona). Si prefieres instalarlo:
  npm install -g @cloudflare/wrangler

## Problemas comunes
- Error: `npx: command not found` → instala Node.js.
- Error: `sqlite3` faltante (si necesitas usar cliente sqlite3 localmente) → instala sqlite3 nativo o usa Docker.
- Si el binario `sqlite3` que tienes provoca `Exec format error`, instala uno compatible con tu arquitectura o usa Docker.

## Siguientes pasos recomendados
- Opcional: crear un Dockerfile + docker-compose para aislar entorno (Worker + sqlite + frontend).
- Opcional: añadir unidad systemd para ejecutar el Worker en producción.

Si quieres que genere el Dockerfile + docker-compose para ejecutar Worker + DB + frontend, responde: `docker`. Si prefieres que cree una unidad systemd, responde: `service`.